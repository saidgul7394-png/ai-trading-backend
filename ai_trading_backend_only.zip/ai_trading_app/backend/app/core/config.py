"""Central settings, loaded from environment / .env. Nothing here is
ever sent to the Flutter client verbatim — the client only receives the
public base URL via its own .env at build time.

CREDENTIAL ARCHITECTURE (Phase 4.2): this backend NEVER accepts, holds,
stores, or has any code path capable of receiving a Binance API key or
secret. Binance API keys/secrets are entered and stored ONLY on the
user's own device (Flutter `flutter_secure_storage`, OS Keystore/
Keychain-backed) and are never transmitted to this server. This
backend only ever calls Binance's UNAUTHENTICATED public market-data
endpoints (klines, exchange info) — see `services/market_data/`. A
future authenticated-order-placement path would need to be signed and
issued FROM the device, not routed through or held by this server; see
`services/binance_service.py` and `services/trading_orchestrator.py`
for the (deliberately unimplemented, disabled-by-default) extension
points reserved for that.

Prefers `pydantic-settings` (the real production path, declared in
requirements.txt) but falls back to a plain-dataclass reader when it
isn't installed, so `risk_engine`, `paper_trading`, and everything that
transitively imports this module stays importable and unit-testable in
minimal environments (e.g. CI runners or sandboxes without network
egress to pip-install). Both paths expose the identical `Settings`
attribute surface and the same `get_settings()` entrypoint, so nothing
downstream needs to know which one is active.
"""

from __future__ import annotations

import os
from functools import lru_cache

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict

    class Settings(BaseSettings):
        model_config = SettingsConfigDict(env_file=".env", extra="ignore")

        environment: str = "development"

        database_url: str = "postgresql+asyncpg://ai_trading:password@localhost:5432/ai_trading"
        redis_url: str = "redis://localhost:6379/0"

        jwt_secret: str = "changeme"
        jwt_algorithm: str = "HS256"
        access_token_expire_minutes: int = 30

        secrets_encryption_key: str = "changeme"

        # Comma-separated list of allowed CORS origins in production
        # (e.g. "https://app.example.com,https://staging.example.com").
        # Empty by default: the Android app talks to this API directly
        # over HTTPS (not from a browser origin), so CORS normally has
        # nothing to allow in production. Only set this if you actually
        # add a browser-based client. In development, localhost origins
        # are allowed automatically regardless of this setting (see
        # main.py) so local web-based tooling keeps working.
        cors_allowed_origins: str = ""

        # HARD KILL SWITCH for live (real-money) order execution.
        # Defaults to False and is read ONLY from the server operator's
        # own environment/.env at process startup — there is no HTTP
        # endpoint, request body, or client-supplied value anywhere in
        # this codebase that can set this to True. `trading_orchestrator`
        # refuses to execute any order while this is False (see its
        # `__init__`). This is intentionally separate from
        # `auto_trading_enabled` (which only ever controls the SIMULATED
        # paper-trading worker) so a operator cannot accidentally enable
        # real trading by toggling the paper-trading switch.
        live_trading_enabled: bool = False

        binance_api_base_url: str = "https://api.binance.com"
        binance_testnet_base_url: str = "https://testnet.binance.vision"
        binance_use_testnet: bool = True

        news_api_key: str | None = None
        sentiment_model_api_key: str | None = None
        ai_provider_api_key: str | None = None

        hard_max_daily_loss_percent: float = 10.0
        hard_max_risk_per_trade_percent: float = 5.0
        hard_max_open_trades: int = 10
        hard_max_trade_amount_usd: float = 10_000.0

        paper_trading_db_path: str = "paper_trading.sqlite3"

    _BACKEND = "pydantic-settings"

except ModuleNotFoundError:
    from dataclasses import dataclass, field

    def _env(name: str, default):
        raw = os.environ.get(name)
        if raw is None:
            return default
        if isinstance(default, bool):
            return raw.lower() in ("1", "true", "yes")
        if isinstance(default, float):
            return float(raw)
        if isinstance(default, int):
            return int(raw)
        return raw

    @dataclass
    class Settings:  # type: ignore[no-redef]
        environment: str = field(default_factory=lambda: _env("ENVIRONMENT", "development"))

        database_url: str = field(
            default_factory=lambda: _env(
                "DATABASE_URL", "postgresql+asyncpg://ai_trading:password@localhost:5432/ai_trading"
            )
        )
        redis_url: str = field(default_factory=lambda: _env("REDIS_URL", "redis://localhost:6379/0"))

        jwt_secret: str = field(default_factory=lambda: _env("JWT_SECRET", "changeme"))
        jwt_algorithm: str = field(default_factory=lambda: _env("JWT_ALGORITHM", "HS256"))
        access_token_expire_minutes: int = field(
            default_factory=lambda: _env("ACCESS_TOKEN_EXPIRE_MINUTES", 30)
        )

        secrets_encryption_key: str = field(
            default_factory=lambda: _env("SECRETS_ENCRYPTION_KEY", "changeme")
        )

        # See docstring on the pydantic-settings variant above.
        cors_allowed_origins: str = field(default_factory=lambda: _env("CORS_ALLOWED_ORIGINS", ""))

        # See docstring on the pydantic-settings variant above — same
        # hard kill switch, same guarantee: no code path in this
        # codebase can set this to True except the server operator's
        # own environment at process startup.
        live_trading_enabled: bool = field(default_factory=lambda: _env("LIVE_TRADING_ENABLED", False))

        binance_api_base_url: str = field(
            default_factory=lambda: _env("BINANCE_API_BASE_URL", "https://api.binance.com")
        )
        binance_testnet_base_url: str = field(
            default_factory=lambda: _env("BINANCE_TESTNET_BASE_URL", "https://testnet.binance.vision")
        )
        binance_use_testnet: bool = field(default_factory=lambda: _env("BINANCE_USE_TESTNET", True))

        news_api_key: str | None = field(default_factory=lambda: os.environ.get("NEWS_API_KEY"))
        sentiment_model_api_key: str | None = field(
            default_factory=lambda: os.environ.get("SENTIMENT_MODEL_API_KEY")
        )
        ai_provider_api_key: str | None = field(default_factory=lambda: os.environ.get("AI_PROVIDER_API_KEY"))

        hard_max_daily_loss_percent: float = field(
            default_factory=lambda: _env("HARD_MAX_DAILY_LOSS_PERCENT", 10.0)
        )
        hard_max_risk_per_trade_percent: float = field(
            default_factory=lambda: _env("HARD_MAX_RISK_PER_TRADE_PERCENT", 5.0)
        )
        hard_max_open_trades: int = field(default_factory=lambda: _env("HARD_MAX_OPEN_TRADES", 10))
        hard_max_trade_amount_usd: float = field(
            default_factory=lambda: _env("HARD_MAX_TRADE_AMOUNT_USD", 10_000.0)
        )

        paper_trading_db_path: str = field(
            default_factory=lambda: _env("PAPER_TRADING_DB_PATH", "paper_trading.sqlite3")
        )

    _BACKEND = "dataclass-fallback (pydantic-settings not installed)"


@lru_cache
def get_settings() -> Settings:
    return Settings()


def cors_origins_list() -> list[str]:
    """Parses `cors_allowed_origins` (comma-separated) into a clean
    list, dropping empty entries from stray commas/whitespace. Kept as
    a free function (not a Settings method) so it behaves identically
    whether the active backend is pydantic-settings or the dataclass
    fallback."""
    raw = get_settings().cors_allowed_origins
    return [origin.strip() for origin in raw.split(",") if origin.strip()]


def is_production() -> bool:
    return get_settings().environment.lower() in ("production", "prod")


def settings_backend() -> str:
    """Which implementation is active — surfaced on /health for
    visibility rather than left as a silent behavioral difference."""
    return _BACKEND
