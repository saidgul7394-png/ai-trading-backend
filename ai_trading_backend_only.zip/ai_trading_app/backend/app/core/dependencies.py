"""FastAPI dependency wiring for the Phase 2 market-data + signal-engine
services, and the Phase 3 paper-trading stack. All are created once at
app startup (see main.py's lifespan) and stored on `app.state` —
routers pull them via `Depends`, so there's exactly one CandleStore /
MarketDataService / PaperTradingRepository per running process."""

from __future__ import annotations

from fastapi import Request

from ..paper_trading.pipeline import TradingPipeline
from ..paper_trading.repository import PaperTradingRepository
from ..paper_trading.worker import BackgroundWorker
from ..services.market_data.service import MarketDataService
from ..signal_engine.service import SignalGenerationService


def get_market_data_service(request: Request) -> MarketDataService:
    service = getattr(request.app.state, "market_data_service", None)
    if service is None:
        raise RuntimeError(
            "MarketDataService not initialized — check the app lifespan startup hook."
        )
    return service


def get_signal_service(request: Request) -> SignalGenerationService:
    service = getattr(request.app.state, "signal_service", None)
    if service is None:
        raise RuntimeError(
            "SignalGenerationService not initialized — check the app lifespan startup hook."
        )
    return service


def get_paper_repository(request: Request) -> PaperTradingRepository:
    repo = getattr(request.app.state, "paper_repository", None)
    if repo is None:
        raise RuntimeError("PaperTradingRepository not initialized — check the app lifespan startup hook.")
    return repo


def get_trading_pipeline(request: Request) -> TradingPipeline:
    pipeline = getattr(request.app.state, "trading_pipeline", None)
    if pipeline is None:
        raise RuntimeError("TradingPipeline not initialized — check the app lifespan startup hook.")
    return pipeline


def get_background_worker(request: Request) -> BackgroundWorker:
    worker = getattr(request.app.state, "background_worker", None)
    if worker is None:
        raise RuntimeError("BackgroundWorker not initialized — check the app lifespan startup hook.")
    return worker
