"""In-memory repository for backtesting — a duck-typed stand-in for
`paper_trading.repository.PaperTradingRepository` that implements the
exact same async method surface `paper_trading.engine.PaperExecutionEngine`,
`paper_trading.position_manager.PositionManager`, and
`paper_trading.pipeline.TradingPipeline` call, so ALL THREE run
completely unmodified during a backtest — the same signal -> risk ->
execution -> position-management code path Phase 3 uses for paper
trading, just backed by this repository instead of SQLite.

The one deliberate behavioral difference from the SQLite repository:
every "what time is it" and "what happened today" computation here is
judged against an injected `SimulatedClock`, never the real wall
clock. This is not a shortcut — it is the correctness requirement.
`PaperTradingRepository` calls `datetime.now(timezone.utc)` internally
in several places (`finalize_close_position`, `set_cooldown`,
`count_trades_opened_today`, `realized_loss_today_percent`); reusing
it unmodified against historical dates would make every cooldown and
daily-loss/daily-trade check compare historical timestamps against
today's real date, corrupting exactly the risk gates this backtest
exists to validate. See `clock.py` for the injected clock itself.

No SQL, no disk I/O — one backtest run's state lives entirely in
memory and is discarded (or exported by the caller) when the run ends.
"""

from __future__ import annotations

import uuid
from dataclasses import replace
from datetime import datetime

from ..paper_trading.models import (
    ExitReason,
    PaperAccount,
    PaperOrder,
    PaperPosition,
    PositionStatus,
    SignalLogEntry,
    TradeStats,
)
from .clock import SimulatedClock

DEFAULT_ACCOUNT_ID = "backtest"


class BacktestRepository:
    def __init__(self, *, clock: SimulatedClock, account_id: str = DEFAULT_ACCOUNT_ID):
        self._clock = clock
        self._account_id = account_id
        self._accounts: dict[str, PaperAccount] = {}
        self._positions: dict[str, PaperPosition] = {}
        self._orders_by_position: dict[str, list[PaperOrder]] = {}
        self._client_order_ids: set[str] = set()
        self._flags: dict[str, bool] = {}
        self._texts: dict[str, str] = {}
        self._cooldowns: dict[str, tuple[str, datetime]] = {}
        self.signal_log: list[SignalLogEntry] = []
        self.risk_events: list[dict] = []
        self._heartbeat = {"last_run_at": None, "last_error": None, "consecutive_failures": 0, "total_cycles": 0}

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------

    async def get_or_create_account(self, *, starting_balance: float, account_id: str | None = None) -> PaperAccount:
        account_id = account_id or self._account_id
        if account_id not in self._accounts:
            self._accounts[account_id] = PaperAccount(
                id=account_id,
                starting_balance=starting_balance,
                current_balance=starting_balance,
                created_at=self._clock.now(),
            )
        return self._accounts[account_id]

    async def get_account(self, account_id: str | None = None) -> PaperAccount | None:
        return self._accounts.get(account_id or self._account_id)

    async def adjust_balance(self, delta: float, account_id: str | None = None) -> PaperAccount:
        account_id = account_id or self._account_id
        account = self._accounts[account_id]
        self._accounts[account_id] = replace(account, current_balance=account.current_balance + delta)
        return self._accounts[account_id]

    async def reset_account(self, starting_balance: float, account_id: str | None = None) -> PaperAccount:
        account_id = account_id or self._account_id
        self._accounts[account_id] = PaperAccount(
            id=account_id, starting_balance=starting_balance, current_balance=starting_balance,
            created_at=self._clock.now(),
        )
        return self._accounts[account_id]

    # ------------------------------------------------------------------
    # Positions
    # ------------------------------------------------------------------

    async def open_position(self, position: PaperPosition) -> PaperPosition | None:
        if position.client_order_id in self._client_order_ids:
            return None  # idempotent duplicate-trade guard, same contract as the SQLite repo
        self._client_order_ids.add(position.client_order_id)
        self._positions[position.id] = position
        return position

    async def begin_close_position(self, position_id: str) -> bool:
        position = self._positions.get(position_id)
        if position is None or position.status != PositionStatus.OPEN:
            return False
        self._positions[position_id] = replace(position, status=PositionStatus.CLOSING)
        return True

    async def finalize_close_position(
        self,
        position_id: str,
        *,
        exit_price: float,
        exit_reason: ExitReason,
        realized_pnl: float,
        exit_fee: float,
    ) -> PaperPosition:
        position = self._positions[position_id]
        closed = replace(
            position,
            status=PositionStatus.CLOSED,
            exit_price=exit_price,
            exit_reason=exit_reason,
            realized_pnl=realized_pnl,
            exit_fee=exit_fee,
            closed_at=self._clock.now(),
        )
        self._positions[position_id] = closed
        return closed

    async def revert_closing(self, position_id: str) -> None:
        position = self._positions.get(position_id)
        if position is not None and position.status == PositionStatus.CLOSING:
            self._positions[position_id] = replace(position, status=PositionStatus.OPEN)

    async def update_trailing_stop(self, position_id: str, *, price: float, active: bool) -> None:
        position = self._positions.get(position_id)
        if position is not None and position.status == PositionStatus.OPEN:
            self._positions[position_id] = replace(position, trailing_stop_price=price, trailing_stop_active=active)

    async def get_open_positions(self, account_id: str | None = None) -> list[PaperPosition]:
        account_id = account_id or self._account_id
        return sorted(
            (p for p in self._positions.values() if p.account_id == account_id and p.status == PositionStatus.OPEN),
            key=lambda p: p.opened_at,
        )

    async def get_open_position_for_symbol(self, symbol: str, account_id: str | None = None) -> PaperPosition | None:
        account_id = account_id or self._account_id
        for p in self._positions.values():
            if p.account_id == account_id and p.symbol == symbol and p.status in (
                PositionStatus.OPEN, PositionStatus.CLOSING,
            ):
                return p
        return None

    async def get_position(self, position_id: str) -> PaperPosition | None:
        return self._positions.get(position_id)

    async def get_trade_history(self, account_id: str | None = None, *, limit: int = 100) -> list[PaperPosition]:
        account_id = account_id or self._account_id
        closed = [
            p for p in self._positions.values() if p.account_id == account_id and p.status == PositionStatus.CLOSED
        ]
        closed.sort(key=lambda p: p.closed_at or p.opened_at, reverse=True)
        return closed[:limit]

    async def get_trade_stats(self, account_id: str | None = None) -> TradeStats:
        account_id = account_id or self._account_id
        pnls = [
            p.realized_pnl
            for p in self._positions.values()
            if p.account_id == account_id and p.status == PositionStatus.CLOSED and p.realized_pnl is not None
        ]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]
        total = len(pnls)
        return TradeStats(
            total_trades=total,
            winning_trades=len(wins),
            losing_trades=len(losses),
            win_rate_percent=(len(wins) / total * 100.0) if total else 0.0,
            total_realized_pnl=sum(pnls),
            avg_win=(sum(wins) / len(wins)) if wins else 0.0,
            avg_loss=(sum(losses) / len(losses)) if losses else 0.0,
            largest_win=max(wins) if wins else 0.0,
            largest_loss=min(losses) if losses else 0.0,
        )

    async def count_trades_opened_today(self, account_id: str | None = None) -> int:
        account_id = account_id or self._account_id
        today = self._clock.now().date()
        return sum(
            1 for p in self._positions.values() if p.account_id == account_id and p.opened_at.date() == today
        )

    async def realized_loss_today_percent(self, account_id: str | None = None) -> float:
        account_id = account_id or self._account_id
        account = self._accounts.get(account_id)
        if account is None or account.starting_balance <= 0:
            return 0.0
        today = self._clock.now().date()
        total_loss = -sum(
            p.realized_pnl
            for p in self._positions.values()
            if p.account_id == account_id
            and p.status == PositionStatus.CLOSED
            and p.realized_pnl is not None
            and p.realized_pnl < 0
            and p.closed_at is not None
            and p.closed_at.date() == today
        )
        return (total_loss / account.starting_balance) * 100.0

    # ------------------------------------------------------------------
    # Orders (fill audit trail)
    # ------------------------------------------------------------------

    async def record_order(self, order: PaperOrder) -> None:
        self._orders_by_position.setdefault(order.position_id, []).append(order)

    async def get_orders_for_position(self, position_id: str) -> list[PaperOrder]:
        return list(self._orders_by_position.get(position_id, []))

    # ------------------------------------------------------------------
    # Signal log
    # ------------------------------------------------------------------

    async def log_signal(self, entry: SignalLogEntry) -> None:
        self.signal_log.append(entry)

    async def get_last_signal_action(self, symbol: str) -> str | None:
        for entry in reversed(self.signal_log):
            if entry.symbol == symbol:
                return entry.action
        return None

    # ------------------------------------------------------------------
    # Risk events (audit trail)
    # ------------------------------------------------------------------

    async def log_risk_event(self, event_type: str, *, symbol: str | None, payload: dict) -> None:
        self.risk_events.append(
            {
                "id": str(uuid.uuid4()),
                "event_type": event_type,
                "symbol": symbol,
                "payload": dict(payload),
                "created_at": self._clock.now().isoformat(),
            }
        )

    async def get_recent_risk_events(self, limit: int = 50) -> list[dict]:
        return list(reversed(self.risk_events[-limit:]))

    # ------------------------------------------------------------------
    # Risk state: emergency stop / circuit breaker
    # ------------------------------------------------------------------

    async def set_flag(self, key: str, value: bool) -> None:
        self._flags[key] = value

    async def get_flag(self, key: str) -> bool:
        return self._flags.get(key, False)

    async def set_text(self, key: str, value: str | None) -> None:
        if value is None:
            self._texts.pop(key, None)
        else:
            self._texts[key] = value

    async def get_text(self, key: str) -> str | None:
        return self._texts.get(key)

    # ------------------------------------------------------------------
    # Per-symbol cooldown
    # ------------------------------------------------------------------

    async def set_cooldown(self, symbol: str, *, action: str, until: datetime) -> None:
        self._cooldowns[symbol] = (action, until)

    async def get_cooldown_until(self, symbol: str) -> datetime | None:
        entry = self._cooldowns.get(symbol)
        return entry[1] if entry else None

    # ------------------------------------------------------------------
    # Worker heartbeat (unused by the replay engine directly, but kept
    # for interface parity so any shared helper that touches it works
    # unmodified against this repository too)
    # ------------------------------------------------------------------

    async def record_worker_success(self) -> None:
        self._heartbeat["last_run_at"] = self._clock.now().isoformat()
        self._heartbeat["last_error"] = None
        self._heartbeat["consecutive_failures"] = 0
        self._heartbeat["total_cycles"] += 1

    async def record_worker_failure(self, error: str) -> None:
        self._heartbeat["last_run_at"] = self._clock.now().isoformat()
        self._heartbeat["last_error"] = error
        self._heartbeat["consecutive_failures"] += 1
        self._heartbeat["total_cycles"] += 1

    async def get_worker_heartbeat(self) -> dict:
        return dict(self._heartbeat)

    # ------------------------------------------------------------------
    # Backtest-only helpers (not part of PaperTradingRepository's
    # interface — used by replay_engine/reports to pull the complete
    # closed-trade ledger without an artificial `limit`)
    # ------------------------------------------------------------------

    def all_closed_positions(self, account_id: str | None = None) -> list[PaperPosition]:
        account_id = account_id or self._account_id
        closed = [
            p for p in self._positions.values() if p.account_id == account_id and p.status == PositionStatus.CLOSED
        ]
        closed.sort(key=lambda p: p.opened_at)
        return closed
