"""Walk-Forward Validation and Out-of-Sample (OOS) isolation (Phase 4
spec item 2, overfitting protection item 6).

Hard rules enforced here, not just documented:
  - windows are built strictly chronologically and never shuffled
    (`build_walk_forward_windows` slices a single chronologically
    sorted candle list; there is no code path that reorders it)
  - a window's TEST segment always starts strictly after its TRAIN and
    VALIDATION segments end — no overlap, no leakage
  - `WalkForwardReport.oos_result` is populated exactly once, from the
    single reserved OOS window carved off the tail of the full dataset
    BEFORE any walk-forward window is built from the remainder — see
    `split_oos_holdout`. Nothing in this module ever re-touches that
    slice while walk-forward windows are being evaluated.
  - `ParameterSet` is versioned (a content hash + explicit label) so
    every report can state exactly which configuration produced it,
    and a caller who tunes parameters between runs can never silently
    present a later run's OOS result as if it were still untouched by
    that tuning — `mark_parameters_tuned` flips `oos_still_untouched`
    to False the moment parameters are adjusted based on ANY
    validation/test-window result, and that flag is surfaced verbatim
    in the final report.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime

from ..paper_trading.config import PaperTradingConfig
from ..services.market_data.models import Candle
from ..signal_engine.config import SignalEngineConfig
from .replay_engine import ReplayResult


@dataclass(frozen=True)
class ParameterSet:
    """Everything about a backtest run that could affect its result,
    bundled so it can be hashed/versioned. Two runs with identical
    `content_hash` are guaranteed to have used identical signal/risk/
    paper-trading configuration — a prerequisite for meaningfully
    comparing train/validation/test/OOS results against each other.
    """

    label: str
    signal_config: SignalEngineConfig
    risk_limits_kwargs: dict  # the kwargs RiskLimits(**this) was constructed with
    paper_config: PaperTradingConfig

    @property
    def content_hash(self) -> str:
        payload = {
            "signal_config": asdict(self.signal_config),
            "risk_limits": self.risk_limits_kwargs,
            "paper_config": asdict(self.paper_config),
        }
        blob = json.dumps(payload, sort_keys=True, default=str)
        return hashlib.sha256(blob.encode()).hexdigest()[:16]


@dataclass(frozen=True)
class WalkForwardWindow:
    index: int
    train: tuple[datetime, datetime]  # [start, end)
    validation: tuple[datetime, datetime]
    test: tuple[datetime, datetime]


def _slice_by_time(candles: list[Candle], start: datetime, end: datetime) -> list[Candle]:
    return [c for c in candles if start <= c.open_time < end]


def build_walk_forward_windows(
    candles: list[Candle],
    *,
    train_candles: int,
    validation_candles: int,
    test_candles: int,
    step_candles: int | None = None,
) -> list[WalkForwardWindow]:
    """Builds chronologically ROLLING train -> validation -> test
    windows over `candles` (already assumed chronologically sorted —
    this function never sorts or reorders its input). `step_candles`
    defaults to `test_candles` (i.e. windows roll forward exactly one
    test-period at a time, the conventional walk-forward scheme); a
    smaller step produces overlapping test windows, a larger step
    skips data — both are valid choices left to the caller, but this
    function never invents a default that silently reorders data.
    """
    if train_candles <= 0 or validation_candles <= 0 or test_candles <= 0:
        raise ValueError("train/validation/test candle counts must all be positive")
    step = step_candles or test_candles
    if step <= 0:
        raise ValueError("step_candles must be positive")

    window_size = train_candles + validation_candles + test_candles
    windows: list[WalkForwardWindow] = []

    start_idx = 0
    idx = 0
    while start_idx + window_size <= len(candles):
        train_start = candles[start_idx].open_time
        train_end = candles[start_idx + train_candles].open_time
        val_start = train_end
        val_end = candles[start_idx + train_candles + validation_candles].open_time
        test_start = val_end
        test_end_idx = start_idx + window_size
        test_end = (
            candles[test_end_idx].open_time
            if test_end_idx < len(candles)
            else candles[-1].close_time
        )

        windows.append(
            WalkForwardWindow(
                index=idx,
                train=(train_start, train_end),
                validation=(val_start, val_end),
                test=(test_start, test_end),
            )
        )
        idx += 1
        start_idx += step

    return windows


def split_oos_holdout(
    candles: list[Candle], *, oos_fraction: float = 0.2
) -> tuple[list[Candle], list[Candle]]:
    """Carves a final, untouched Out-of-Sample holdout off the
    chronological TAIL of `candles` — the most recent `oos_fraction` of
    the series. Returns (development_candles, oos_candles).
    `development_candles` (everything BEFORE the OOS slice) is the only
    data walk-forward windows may be built from; `oos_candles` must
    never be touched by any parameter-tuning decision. This ordering
    (tail = OOS, not a random slice) is what "never shuffled" and
    "chronological" require — an OOS set from the middle or drawn
    randomly could leak future information into development via
    indicator lookback windows that straddle the boundary.
    """
    if not (0.0 < oos_fraction < 1.0):
        raise ValueError("oos_fraction must be between 0 and 1 (exclusive)")
    if len(candles) < 10:
        raise ValueError("Not enough candles to carve out a meaningful OOS holdout")

    oos_count = max(1, int(len(candles) * oos_fraction))
    split_idx = len(candles) - oos_count
    return candles[:split_idx], candles[split_idx:]


@dataclass
class WindowResult:
    window: WalkForwardWindow
    train_result: ReplayResult | None
    validation_result: ReplayResult | None
    test_result: ReplayResult


@dataclass
class WalkForwardReport:
    parameter_set: ParameterSet
    windows: list[WindowResult] = field(default_factory=list)
    oos_result: ReplayResult | None = None
    oos_still_untouched: bool = True
    tuning_log: list[str] = field(default_factory=list)

    def mark_parameters_tuned(self, reason: str) -> None:
        """Call this the moment ANY parameter is adjusted based on a
        train/validation/test-window result. Once called, this
        report's `oos_result` (if later populated) must be treated as
        informational only, never as a claim of untouched OOS
        validation — `oos_still_untouched` stays False for the rest of
        this report's lifetime; there is no method to set it back to
        True."""
        self.oos_still_untouched = False
        self.tuning_log.append(reason)


def detect_suspicious_overfitting(
    report: WalkForwardReport, *, degradation_threshold_percent: float = 50.0
) -> list[str]:
    """Best-effort, heuristic overfitting flags — never a proof of
    overfitting or its absence, only things worth a human's attention.
    Returns a list of plain-English warnings; an empty list means "no
    flag was raised", NOT "this strategy does not overfit".

    Flags raised:
      - a window where validation profit factor materially exceeds
        train and then collapses in test (>degradation_threshold_percent
        drop from validation to test) — a classic overfitting signature
      - OOS net P&L sign disagrees with the average walk-forward test
        window's net P&L sign, while `oos_still_untouched` is True
        (if parameters were tuned, a sign disagreement is expected and
        not flagged as suspicious — that's exactly the situation
        walk-forward testing exists to catch, not evidence of a bug)
      - any window with fewer than 5 test trades — too few to draw a
        per-window conclusion from at all
    """
    from .metrics import compute_performance_metrics

    warnings: list[str] = []

    for wr in report.windows:
        test_metrics = compute_performance_metrics(wr.test_result.trades)
        if test_metrics.total_trades < 5:
            warnings.append(
                f"Window {wr.window.index}: only {test_metrics.total_trades} test trades — "
                "too few to draw a reliable per-window conclusion."
            )
            continue

        if wr.validation_result is not None:
            val_metrics = compute_performance_metrics(wr.validation_result.trades)
            val_pf = val_metrics.profit_factor
            test_pf = test_metrics.profit_factor
            if val_pf is not None and test_pf is not None and val_pf > 0:
                degradation = ((val_pf - test_pf) / val_pf) * 100.0
                if val_pf >= 2.0 and degradation >= degradation_threshold_percent:
                    warnings.append(
                        f"Window {wr.window.index}: validation profit factor "
                        f"({val_pf:.2f}) collapsed by {degradation:.0f}% in the test segment "
                        f"({test_pf:.2f}) — a classic overfitting signature (fit the validation "
                        "noise, fail to generalize)."
                    )

    if report.oos_result is not None and report.oos_still_untouched and report.windows:
        oos_metrics = compute_performance_metrics(report.oos_result.trades)
        test_net_pnls = [
            compute_performance_metrics(wr.test_result.trades).net_pnl for wr in report.windows
        ]
        if test_net_pnls:
            avg_test_sign = sum(1 if p > 0 else (-1 if p < 0 else 0) for p in test_net_pnls)
            oos_sign = 1 if oos_metrics.net_pnl > 0 else (-1 if oos_metrics.net_pnl < 0 else 0)
            if avg_test_sign != 0 and oos_sign != 0 and (avg_test_sign > 0) != (oos_sign > 0):
                warnings.append(
                    "The untouched OOS result's net P&L sign disagrees with the average "
                    "walk-forward test-window sign — the strategy's edge (if any) may not "
                    "generalize beyond the development period."
                )

    if not report.oos_still_untouched:
        warnings.append(
            "Parameters were tuned during this report's lifetime "
            f"({len(report.tuning_log)} tuning event(s) logged) — any OOS result attached to "
            "this report is informational only and must NOT be presented as an untouched "
            "validation result."
        )

    return warnings


async def run_walk_forward_backtest(
    *,
    primary_timeframe: str,
    candles_by_symbol_tf: dict[str, dict[str, list[Candle]]],
    parameter_set: ParameterSet,
    risk_limits,
    train_candles: int,
    validation_candles: int,
    test_candles: int,
    step_candles: int | None = None,
    oos_fraction: float = 0.2,
    btc_symbol: str = "BTCUSDT",
    real_data_used: bool = False,
) -> WalkForwardReport:
    """Orchestrates the full item-2 requirement end to end for one
    symbol universe: carve off an untouched OOS tail, build rolling
    train/validation/test windows over everything BEFORE it, run a
    full (unmodified) backtest replay for every segment of every
    window, then run one final replay over the OOS slice.

    Each segment is an INDEPENDENT replay (its own fresh
    `BacktestRepository`/`SimulatedClock`/account) — a window's test
    segment never inherits open positions, cooldowns, or balance state
    from its own train/validation segments, which is what keeps this a
    genuine chronological validation rather than one continuous run
    that happens to be sliced up after the fact for reporting.

    Windows are built from the PRIMARY symbol's timeframe (the first
    key in `candles_by_symbol_tf`, sorted) — every symbol's candles are
    then sliced to each window's time boundaries independently, so a
    multi-symbol universe still walks forward on one consistent
    calendar.
    """
    from .replay_engine import run_multi_symbol_backtest

    symbols = sorted(candles_by_symbol_tf.keys())
    if not symbols:
        raise ValueError("candles_by_symbol_tf must contain at least one symbol")

    reference_symbol = symbols[0]
    reference_candles = candles_by_symbol_tf[reference_symbol].get(primary_timeframe, [])
    if not reference_candles:
        raise ValueError(f"No {primary_timeframe} candles for reference symbol {reference_symbol}")

    dev_reference, oos_reference = split_oos_holdout(reference_candles, oos_fraction=oos_fraction)
    oos_start, oos_end = oos_reference[0].open_time, oos_reference[-1].close_time

    def _slice_universe(start: datetime, end: datetime) -> dict[str, dict[str, list[Candle]]]:
        sliced: dict[str, dict[str, list[Candle]]] = {}
        for symbol in symbols:
            sliced[symbol] = {
                tf: [c for c in series if start <= c.open_time < end]
                for tf, series in candles_by_symbol_tf[symbol].items()
            }
        return sliced

    windows = build_walk_forward_windows(
        dev_reference,
        train_candles=train_candles,
        validation_candles=validation_candles,
        test_candles=test_candles,
        step_candles=step_candles,
    )

    report = WalkForwardReport(parameter_set=parameter_set)

    for w in windows:
        train_universe = _slice_universe(*w.train)
        val_universe = _slice_universe(*w.validation)
        test_universe = _slice_universe(*w.test)

        train_results = await run_multi_symbol_backtest(
            primary_timeframe=primary_timeframe, candles_by_symbol_tf=train_universe,
            paper_config=parameter_set.paper_config, risk_limits=risk_limits,
            signal_config=parameter_set.signal_config, btc_symbol=btc_symbol, real_data_used=real_data_used,
        )
        val_results = await run_multi_symbol_backtest(
            primary_timeframe=primary_timeframe, candles_by_symbol_tf=val_universe,
            paper_config=parameter_set.paper_config, risk_limits=risk_limits,
            signal_config=parameter_set.signal_config, btc_symbol=btc_symbol, real_data_used=real_data_used,
        )
        test_results = await run_multi_symbol_backtest(
            primary_timeframe=primary_timeframe, candles_by_symbol_tf=test_universe,
            paper_config=parameter_set.paper_config, risk_limits=risk_limits,
            signal_config=parameter_set.signal_config, btc_symbol=btc_symbol, real_data_used=real_data_used,
        )

        report.windows.append(
            WindowResult(
                window=w,
                train_result=_merge_results(train_results, primary_timeframe, real_data_used),
                validation_result=_merge_results(val_results, primary_timeframe, real_data_used),
                test_result=_merge_results(test_results, primary_timeframe, real_data_used),
            )
        )

    oos_universe = {
        symbol: {
            tf: [c for c in series if oos_start <= c.open_time <= oos_end]
            for tf, series in candles_by_symbol_tf[symbol].items()
        }
        for symbol in symbols
    }
    oos_results = await run_multi_symbol_backtest(
        primary_timeframe=primary_timeframe, candles_by_symbol_tf=oos_universe,
        paper_config=parameter_set.paper_config, risk_limits=risk_limits,
        signal_config=parameter_set.signal_config, btc_symbol=btc_symbol, real_data_used=real_data_used,
    )
    report.oos_result = _merge_results(oos_results, primary_timeframe, real_data_used)

    return report


def _merge_results(
    results: dict[str, ReplayResult], primary_timeframe: str, real_data_used: bool
) -> ReplayResult:
    """Flattens a multi-symbol `{symbol: ReplayResult}` map into one
    combined `ReplayResult` for reporting at the window/OOS level —
    trades, signal log, and risk events concatenated; balances summed
    across symbols (each symbol replay starts from the same
    configured starting balance in `run_multi_symbol_backtest`'s shared
    account, so summing would double count — instead we report the
    shared account's actual start/end balance, identical across every
    per-symbol result since they share one account)."""
    merged = ReplayResult(symbol="ALL", timeframe=primary_timeframe, real_data_used=real_data_used)
    if not results:
        return merged
    any_result = next(iter(results.values()))
    merged.starting_balance = any_result.starting_balance
    merged.ending_balance = any_result.ending_balance
    for res in results.values():
        merged.trades.extend(res.trades)
        merged.signal_log.extend(res.signal_log)
        merged.risk_events.extend(res.risk_events)
        merged.candles_evaluated += res.candles_evaluated
    merged.trades.sort(key=lambda t: t.position.opened_at)
    return merged
