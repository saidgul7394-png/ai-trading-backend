"""Deterministic synthetic OHLCV fixtures — UNIT TESTS ONLY.

Every series here is generated from a closed-form formula (no
`random`), matching the convention already established in
`app/tests/deterministic_dataset.py` for Phase 1-3. These fixtures
exist ONLY to exercise the backtesting engine's mechanics (chronology,
no-look-ahead, fee/slippage math, WFO window splitting, OOS isolation,
metrics arithmetic) in the automated test suite.

NEVER present results from these fixtures as real historical
performance, real profitability, or evidence the strategy works on
real markets. Anything built from this module must be labeled
synthetic wherever it surfaces (report fields, test names, docstrings).
See `historical_data.py` for the real-data path, and `README`/final
verification output for the explicit "REAL HISTORICAL VALIDATION
BLOCKED" disclosure this environment requires.
"""

from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone

from ..services.market_data.models import Candle, INTERVAL_SECONDS

FIXTURE_EPOCH = datetime(2024, 1, 1, tzinfo=timezone.utc)


def _candle_from_close(
    symbol: str, interval: str, index: int, prev_close: float, close: float, volume: float, *, epoch: datetime,
) -> Candle:
    open_time = epoch + timedelta(seconds=INTERVAL_SECONDS[interval] * index)
    close_time = open_time + timedelta(seconds=INTERVAL_SECONDS[interval])
    open_price = prev_close
    wick = abs(close - open_price) * 0.3 + 0.01
    high = max(open_price, close) + wick
    low = min(open_price, close) - wick
    return Candle(
        symbol=symbol, interval=interval, open_time=open_time, close_time=close_time,
        open=open_price, high=high, low=low, close=close, volume=volume, is_closed=True,
    )


def make_regime_series(
    *,
    symbol: str,
    interval: str = "1h",
    count: int,
    base_price: float,
    trend_per_candle: float,
    wave_amplitude: float,
    wave_period: int,
    base_volume: float = 100.0,
    epoch: datetime = FIXTURE_EPOCH,
    start_index: int = 0,
) -> list[Candle]:
    """General-purpose closed-form generator: linear trend + sine wave,
    same construction `deterministic_dataset.make_trend_candles` uses.
    `start_index` lets callers stitch multiple regime segments into one
    continuous chronological series without timestamp overlap.
    """
    closes = []
    for i in range(count):
        wave = wave_amplitude * math.sin(2 * math.pi * i / max(wave_period, 1))
        closes.append(base_price + trend_per_candle * i + wave)

    candles = []
    prev_close = closes[0] - trend_per_candle
    for i, close in enumerate(closes):
        volume = base_volume + 10 * math.sin(2 * math.pi * i / 7)
        candles.append(
            _candle_from_close(
                symbol, interval, start_index + i, prev_close, close, max(volume, 1.0), epoch=epoch,
            )
        )
        prev_close = close
    return candles


def make_multi_regime_symbol_series(
    *,
    symbol: str = "BTCUSDT",
    interval: str = "1h",
    base_price: float = 40_000.0,
    epoch: datetime = FIXTURE_EPOCH,
    segment_length: int = 150,
) -> list[Candle]:
    """One continuous chronological series that walks through several
    distinct regimes back to back: bull trend -> sideways/range -> bear
    trend -> high-volatility chop -> low-volatility drift. Long enough
    per segment (150 candles) for the 60-candle minimum the signal
    engine requires and the 30/60-candle lookbacks regime
    classification uses to each get a stable reading well before the
    segment ends — used by walk-forward and per-regime backtest tests.
    """
    segments: list[list[Candle]] = []
    price = base_price
    idx = 0

    # Parameters below were empirically verified (see Phase 4 dev notes)
    # to produce a STABLE `signal_engine.indicators.market_structure`
    # reading across the whole segment length used here — i.e. evaluated
    # at every cutoff from candle 60 through the end of the segment, not
    # just once at the very end. A trend/wave ratio that only classifies
    # correctly at one particular cutoff would make regime labels
    # (and therefore per-regime backtest slicing) unstable depending on
    # exactly where in the segment a trade happened to open.

    # 1) Bull trend — steady upward drift, oscillation subordinate to trend.
    seg = make_regime_series(
        symbol=symbol, interval=interval, count=segment_length, base_price=price,
        trend_per_candle=25.0, wave_amplitude=80.0, wave_period=10, epoch=epoch, start_index=idx,
    )
    segments.append(seg)
    price = seg[-1].close
    idx += segment_length

    # 2) Sideways / range — no net drift, oscillation dominates.
    seg = make_regime_series(
        symbol=symbol, interval=interval, count=segment_length, base_price=price,
        trend_per_candle=0.0, wave_amplitude=200.0, wave_period=10, epoch=epoch, start_index=idx,
    )
    segments.append(seg)
    price = seg[-1].close
    idx += segment_length

    # 3) Bear trend — steady downward drift, oscillation subordinate to trend.
    seg = make_regime_series(
        symbol=symbol, interval=interval, count=segment_length, base_price=price,
        trend_per_candle=-25.0, wave_amplitude=80.0, wave_period=10, epoch=epoch, start_index=idx,
    )
    segments.append(seg)
    price = seg[-1].close
    idx += segment_length

    # 4) High volatility — large, fast oscillation (ATR% roughly 2%),
    # mild net drift so it isn't also just a stronger version of (1).
    seg = make_regime_series(
        symbol=symbol, interval=interval, count=segment_length, base_price=price,
        trend_per_candle=5.0, wave_amplitude=900.0, wave_period=6, epoch=epoch, start_index=idx,
    )
    segments.append(seg)
    price = seg[-1].close
    idx += segment_length

    # 5) Low volatility — small, slow oscillation (ATR% roughly 0.03%,
    # far below segment 4's), near-flat drift.
    seg = make_regime_series(
        symbol=symbol, interval=interval, count=segment_length, base_price=price,
        trend_per_candle=1.0, wave_amplitude=40.0, wave_period=20, epoch=epoch, start_index=idx,
    )
    segments.append(seg)

    return [c for seg in segments for c in seg]


def make_multi_timeframe_fixture(
    *,
    symbol: str = "BTCUSDT",
    base_price: float = 40_000.0,
    confirmation_timeframes: tuple[str, ...] = ("15m", "1h", "4h"),
    primary_timeframe: str = "1h",
    segment_length: int = 150,
) -> dict[str, list[Candle]]:
    """The same multi-regime walk rendered consistently across every
    timeframe the signal engine's multi-timeframe-confirmation factor
    needs, so that factor can actually compute during backtests instead
    of being omitted for lack of data on the confirmation timeframes.
    """
    out: dict[str, list[Candle]] = {}
    all_tfs = set(confirmation_timeframes) | {primary_timeframe}
    for tf in all_tfs:
        out[tf] = make_multi_regime_symbol_series(
            symbol=symbol, interval=tf, base_price=base_price, segment_length=segment_length,
        )
    return out


def make_btc_trend_series(
    *, interval: str = "1h", base_price: float = 40_000.0, segment_length: int = 150,
) -> list[Candle]:
    """BTC's own series, used as the market-wide trend-confirmation
    input — walks through the same regime shape so "strong/weak BTC
    trend" backtests have something meaningful to slice against."""
    return make_multi_regime_symbol_series(
        symbol="BTCUSDT", interval=interval, base_price=base_price, segment_length=segment_length,
    )


def make_simple_uptrend(
    *, symbol: str = "BTCUSDT", interval: str = "1h", count: int = 300, base_price: float = 40_000.0,
) -> list[Candle]:
    """A single clean uptrend — used for the most basic mechanical
    tests (chronology, no-look-ahead, fee/slippage arithmetic) where
    regime variety would only add noise."""
    return make_regime_series(
        symbol=symbol, interval=interval, count=count, base_price=base_price,
        trend_per_candle=20.0, wave_amplitude=150.0, wave_period=12,
    )
