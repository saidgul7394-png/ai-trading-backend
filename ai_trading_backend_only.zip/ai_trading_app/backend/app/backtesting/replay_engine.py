"""Chronological, candle-by-candle backtest replay.

Drives the EXACT SAME Phase 3 components paper trading uses:
  `signal_engine.service.SignalGenerationService` (unmodified)
    -> `signal_engine.composite.build_composite_signal` (unmodified)
    -> `paper_trading.pipeline.TradingPipeline.evaluate_symbol` (unmodified)
       -> `risk_engine.engine.evaluate_trade_proposal` (unmodified logic;
          now accepts an optional `now` — see risk_engine/engine.py)
       -> `paper_trading.engine.PaperExecutionEngine` (unmodified)
    -> `paper_trading.pipeline.TradingPipeline.manage_all_open_positions`
       -> `paper_trading.position_manager.PositionManager` (unmodified)

No look-ahead: at candle index `i`, the replay only ever exposes
`candles[0 : i+1]` to the signal engine via `ReplayMarketData` below —
never a future candle. `SimulatedClock` is advanced to the CURRENT
candle's close time before that candle is evaluated, so every
timestamped decision (cooldowns, daily-loss window, max-holding-time,
signal `generated_at`) is judged against simulated historical time,
never the real wall clock.

Realism modeled here, per the Phase 4 spec:
  - fees + slippage:        `paper_trading.engine.PaperExecutionEngine` (unmodified)
  - TP / SL / trailing:     `paper_trading.position_manager` (unmodified)
  - early exit on reversal: `paper_trading.position_manager` (unmodified)
  - max holding time:       `paper_trading.position_manager` (unmodified)
  - intrabar stop-touch:    THIS module additionally checks each closed
                             candle's high/low against the open position's
                             stop-loss/take-profit/trailing-stop *within*
                             the candle, not only against its close. The
                             live paper-trading loop only ever sees the
                             latest tick/close price, so it cannot do
                             this — a backtest replaying full OHLC bars
                               can and should, or it would systematically
                             UNDER-count stop-outs that happened
                             intra-candle and reversed by the close,
                             making the backtest look artificially better
                             than real execution would have been. See
                             `_check_intrabar_exit` below.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import timedelta

from ..paper_trading.config import PaperTradingConfig
from ..paper_trading.engine import PaperExecutionEngine, PaperExecutionError
from ..paper_trading.models import ExitReason, PaperPosition, PositionSide
from ..paper_trading.pipeline import DEFAULT_RISK_LIMITS, RiskLimits, TradingPipeline
from ..paper_trading.position_manager import PositionManager
from ..services.market_data.models import Candle
from ..signal_engine.config import DEFAULT_CONFIG, SignalEngineConfig
from ..signal_engine.service import SignalGenerationService
from .backtest_repository import BacktestRepository, DEFAULT_ACCOUNT_ID
from .clock import SimulatedClock
from .regimes import RegimeLabel, label_regimes

logger = logging.getLogger("backtesting.replay_engine")


class ReplayMarketData:
    """Duck-typed stand-in for `services.market_data.service.MarketDataService`,
    used ONLY by `SignalGenerationService` during replay. The critical
    property that makes this a valid backtest (not a leaky one): every
    read method is bounded by `self._cursor`, an index into the primary
    timeframe's candle series that the replay engine advances one step
    at a time. Nothing this class returns can ever include a candle
    whose close_time is after the primary-timeframe candle currently
    being evaluated — see `_bounded` and `_cursor_time`.
    """

    def __init__(
        self,
        *,
        primary_timeframe: str,
        candles_by_symbol_tf: dict[str, dict[str, list[Candle]]],
        btc_symbol: str = "BTCUSDT",
    ):
        self._primary_tf = primary_timeframe
        self._data = candles_by_symbol_tf
        self._btc_symbol = btc_symbol
        self.symbols = tuple(candles_by_symbol_tf.keys())
        # Per-symbol cursor: index into that symbol's PRIMARY-timeframe
        # series. Confirmation timeframes and BTC are bounded by
        # matching close_time <= the primary candle's close_time,
        # since their own indices may not line up 1:1.
        self._cursor: dict[str, int] = {s: -1 for s in candles_by_symbol_tf}

    def advance(self, symbol: str, primary_index: int) -> None:
        self._cursor[symbol] = primary_index

    def _cursor_time(self, symbol: str):
        idx = self._cursor.get(symbol, -1)
        series = self._data.get(symbol, {}).get(self._primary_tf, [])
        if idx < 0 or idx >= len(series):
            return None
        return series[idx].close_time

    def _bounded(self, symbol: str, interval: str) -> list[Candle]:
        cutoff = self._cursor_time(symbol)
        series = self._data.get(symbol, {}).get(interval, [])
        if cutoff is None:
            return []
        # strictly <= cutoff: a confirmation-timeframe candle that
        # closes at exactly the same instant as the primary candle is
        # legitimately "known" at that instant; nothing after it is.
        return [c for c in series if c.close_time <= cutoff]

    async def ensure_fresh_or_backfill(self, symbol: str, interval: str) -> None:
        return None  # replay data is already "backfilled" — nothing to fetch

    async def get_candles_multi_timeframe(self, symbol: str, intervals: tuple[str, ...]) -> dict[str, list[Candle]]:
        return {tf: self._bounded(symbol, tf) for tf in intervals}

    async def get_candles(self, symbol: str, interval: str, limit: int | None = None) -> list[Candle]:
        bounded = self._bounded(symbol, interval)
        return bounded[-limit:] if limit else bounded

    async def get_order_book(self, symbol: str, depth: int = 20):
        # No historical order-book depth exists for this backtest —
        # the composite signal engine already treats a missing order
        # book as "factor omitted", never a fabricated reading.
        raise RuntimeError("order book history not available in backtest replay")

    async def freshness_seconds(self, symbol: str, interval: str) -> int | None:
        return 0  # replay data is always "fresh" relative to itself — staleness is a live-only concern

    async def get_price(self, symbol: str) -> float:
        """Used by `TradingPipeline.manage_all_open_positions` and
        emergency-stop close-all. Returns the CURRENT candle's close —
        the replay engine calls position management once per candle
        after advancing the cursor, so this is never a future price."""
        cutoff_idx = self._cursor.get(symbol, -1)
        series = self._data.get(symbol, {}).get(self._primary_tf, [])
        if cutoff_idx < 0 or cutoff_idx >= len(series):
            raise ValueError(f"No current price available for {symbol} in replay")
        return series[cutoff_idx].close


@dataclass
class TradeRecord:
    """One closed trade, enriched with replay-only context (regime
    labels, MFE/MAE) beyond what `PaperPosition` itself carries —
    kept as a separate record rather than mutating `PaperPosition` so
    the paper-trading domain model stays untouched by backtest-only
    concerns."""

    position: PaperPosition
    regime_keys_at_entry: list[str]
    mfe_percent: float  # maximum favorable excursion while open, % of entry notional
    mae_percent: float  # maximum adverse excursion while open, % of entry notional


@dataclass
class ReplayResult:
    symbol: str
    timeframe: str
    trades: list[TradeRecord] = field(default_factory=list)
    signal_log: list = field(default_factory=list)
    risk_events: list = field(default_factory=list)
    equity_curve: list[tuple] = field(default_factory=list)  # (timestamp, equity)
    starting_balance: float = 0.0
    ending_balance: float = 0.0
    candles_evaluated: int = 0
    real_data_used: bool = False


def _direction(side: PositionSide) -> float:
    return 1.0 if side == PositionSide.LONG else -1.0


def _check_intrabar_exit(
    position: PaperPosition, candle: Candle, config: PaperTradingConfig
) -> ExitReason | None:
    """Checks whether this candle's high/low (not just its close) would
    have triggered stop-loss / take-profit / trailing-stop intrabar.
    Priority mirrors `position_manager.evaluate_exit`: protective exits
    (stop loss, trailing stop) before profit-taking. When BOTH a stop
    and a target are touched within the same candle, the stop is
    assumed to have been hit first — a deliberately conservative,
    pessimistic assumption (a backtest that assumed the more favorable
    ordering whenever ambiguous would overstate performance).
    """
    direction = _direction(position.side)

    if position.side == PositionSide.LONG:
        stop_hit = candle.low <= position.stop_loss
    else:
        stop_hit = candle.high >= position.stop_loss
    if stop_hit:
        return ExitReason.STOP_LOSS

    if position.trailing_stop_active and position.trailing_stop_price is not None:
        if position.side == PositionSide.LONG:
            trail_hit = candle.low <= position.trailing_stop_price
        else:
            trail_hit = candle.high >= position.trailing_stop_price
        if trail_hit:
            return ExitReason.TRAILING_STOP

    if position.side == PositionSide.LONG:
        tp_hit = candle.high >= position.take_profit
    else:
        tp_hit = candle.low <= position.take_profit
    if tp_hit:
        return ExitReason.TAKE_PROFIT

    return None


class BacktestRunner:
    """Runs one chronological replay for one symbol over one candle
    series, producing a `ReplayResult`. A multi-symbol backtest runs
    one `BacktestRunner` per symbol against a SHARED clock/repository
    (see `run_multi_symbol_backtest` below) so cross-symbol risk gates
    (max open trades, daily loss, daily trade count) are enforced
    correctly across the whole portfolio, exactly as they would be
    live.
    """

    def __init__(
        self,
        *,
        symbol: str,
        primary_timeframe: str,
        candles_by_tf: dict[str, list[Candle]],
        btc_candles: list[Candle] | None,
        repository: BacktestRepository,
        clock: SimulatedClock,
        paper_config: PaperTradingConfig,
        risk_limits: RiskLimits = DEFAULT_RISK_LIMITS,
        signal_config: SignalEngineConfig = DEFAULT_CONFIG,
        market_data: ReplayMarketData | None = None,
        real_data_used: bool = False,
    ):
        self.symbol = symbol
        self.primary_timeframe = primary_timeframe
        self.candles = candles_by_tf.get(primary_timeframe, [])
        self.btc_candles = btc_candles
        self.repo = repository
        self.clock = clock
        self.paper_config = paper_config
        self.risk_limits = risk_limits
        self.real_data_used = real_data_used

        self.market_data = market_data or ReplayMarketData(
            primary_timeframe=primary_timeframe,
            candles_by_symbol_tf={symbol: candles_by_tf, **({"BTCUSDT": {primary_timeframe: btc_candles}} if btc_candles else {})},
        )
        self.signal_service = SignalGenerationService(market_data=self.market_data, config=signal_config)
        self.execution = PaperExecutionEngine(repository=repository, config=paper_config, now_fn=clock.now)
        self.position_manager = PositionManager(repository=repository, engine=self.execution, config=paper_config)
        self.pipeline = TradingPipeline(
            signal_service=self.signal_service,
            market_data=self.market_data,
            repository=repository,
            execution_engine=self.execution,
            position_manager=self.position_manager,
            paper_config=paper_config,
            risk_limits=risk_limits,
            account_id=DEFAULT_ACCOUNT_ID,
            now_fn=clock.now,
        )

        self.regime_labels: list[RegimeLabel] = label_regimes(self.candles, btc_candles=btc_candles)
        self._mfe_mae: dict[str, tuple[float, float]] = {}  # position_id -> (max_favorable_pct, max_adverse_pct)

    async def run(self) -> ReplayResult:
        result = ReplayResult(
            symbol=self.symbol, timeframe=self.primary_timeframe, real_data_used=self.real_data_used,
        )
        account = await self.repo.get_or_create_account(
            starting_balance=self.paper_config.starting_balance_usd, account_id=DEFAULT_ACCOUNT_ID
        )
        result.starting_balance = account.starting_balance

        for i, candle in enumerate(self.candles):
            self.clock.advance_to(candle.close_time)
            self.market_data.advance(self.symbol, i)

            # --- Intrabar protective-exit check BEFORE the pipeline's
            # own (close-price-only) evaluate_symbol call, so a stop/TP
            # that was touched inside this candle is honored even if
            # price closed back on the "safe" side by the candle's
            # close. This is a backtest-only realism addition (see
            # module docstring); the exit itself is executed through
            # the real `PaperExecutionEngine.close_position`, never a
            # fabricated fill outside that engine. ---
            await self._check_and_apply_intrabar_exit(candle)

            try:
                await self.pipeline.evaluate_symbol(self.symbol, self.primary_timeframe)
            except Exception as e:  # noqa: BLE001 — one bad candle must not abort the whole replay
                logger.error("Replay error for %s at %s: %s", self.symbol, candle.open_time, e)

            self._update_mfe_mae(candle)

            account = await self.repo.get_account(DEFAULT_ACCOUNT_ID)
            open_positions = await self.repo.get_open_positions(DEFAULT_ACCOUNT_ID)
            unrealized = sum(p.unrealized_pnl(candle.close) for p in open_positions if p.symbol == self.symbol)
            equity = account.current_balance + unrealized if account else 0.0
            result.equity_curve.append((candle.close_time, equity))
            result.candles_evaluated += 1

        account = await self.repo.get_account(DEFAULT_ACCOUNT_ID)
        result.ending_balance = account.current_balance if account else result.starting_balance

        for closed in self.repo.all_closed_positions(DEFAULT_ACCOUNT_ID):
            if closed.symbol != self.symbol:
                continue
            regime_keys = self._regime_keys_at(closed.opened_at)
            mfe, mae = self._mfe_mae.get(closed.id, (0.0, 0.0))
            result.trades.append(
                TradeRecord(position=closed, regime_keys_at_entry=regime_keys, mfe_percent=mfe, mae_percent=mae)
            )

        result.signal_log = [s for s in self.repo.signal_log if s.symbol == self.symbol]
        result.risk_events = [e for e in self.repo.risk_events if e.get("symbol") == self.symbol]
        return result

    async def _check_and_apply_intrabar_exit(self, candle: Candle) -> None:
        position = await self.repo.get_open_position_for_symbol(self.symbol, DEFAULT_ACCOUNT_ID)
        if position is None or position.status.value != "OPEN":
            return

        # Trailing stop must be updated to reflect this candle's
        # favorable excursion BEFORE checking whether it was hit —
        # mirrors `PositionManager.manage_position`'s own ordering.
        from ..paper_trading.position_manager import compute_trailing_stop

        favorable_extreme = candle.high if position.side == PositionSide.LONG else candle.low
        new_stop, active = compute_trailing_stop(
            position, favorable_extreme, self.paper_config
        )
        if active and new_stop != position.trailing_stop_price:
            await self.repo.update_trailing_stop(position.id, price=new_stop, active=True)
            position = await self.repo.get_position(position.id)

        reason = _check_intrabar_exit(position, candle, self.paper_config)
        if reason is None:
            return

        exit_price = {
            ExitReason.STOP_LOSS: position.stop_loss,
            ExitReason.TRAILING_STOP: position.trailing_stop_price,
            ExitReason.TAKE_PROFIT: position.take_profit,
        }.get(reason)
        if exit_price is None:
            return

        try:
            closed = await self.execution.close_position(position, reference_price=exit_price, exit_reason=reason)
        except PaperExecutionError as e:  # noqa: BLE001 — never let a fill error abort the replay
            logger.error("Intrabar close failed for %s: %s", self.symbol, e)
            return

        if closed:
            await self.repo.log_risk_event(
                "TRADE_CLOSED",
                symbol=self.symbol,
                payload={
                    "position_id": position.id, "exit_reason": reason.value,
                    "realized_pnl": closed.realized_pnl, "exit_price": closed.exit_price, "intrabar": True,
                },
            )

    def _update_mfe_mae(self, candle: Candle) -> None:
        open_position = None
        # There is at most one open position per symbol at a time
        # (pipeline/repository enforce this) — recompute cheaply.
        for pos in self.repo._positions.values():  # noqa: SLF001 — same-module internal, backtest-only
            if pos.symbol == self.symbol and pos.status.value in ("OPEN", "CLOSING"):
                open_position = pos
                break
        if open_position is None:
            return

        direction = _direction(open_position.side)
        notional = open_position.entry_price * open_position.quantity or 1.0
        favorable_extreme = candle.high if open_position.side == PositionSide.LONG else candle.low
        adverse_extreme = candle.low if open_position.side == PositionSide.LONG else candle.high

        favorable_pnl_pct = ((favorable_extreme - open_position.entry_price) * direction * open_position.quantity / notional) * 100.0
        adverse_pnl_pct = ((adverse_extreme - open_position.entry_price) * direction * open_position.quantity / notional) * 100.0

        prev_mfe, prev_mae = self._mfe_mae.get(open_position.id, (0.0, 0.0))
        self._mfe_mae[open_position.id] = (
            max(prev_mfe, favorable_pnl_pct),
            min(prev_mae, adverse_pnl_pct),
        )

    def _regime_keys_at(self, opened_at) -> list[str]:
        from .regimes import regime_keys_for_label

        for i, candle in enumerate(self.candles):
            if candle.open_time <= opened_at <= candle.close_time:
                return regime_keys_for_label(self.regime_labels[i])
        # Fall back to nearest candle before opened_at.
        idx = max((i for i, c in enumerate(self.candles) if c.close_time <= opened_at), default=None)
        if idx is None:
            return []
        return regime_keys_for_label(self.regime_labels[idx])


async def run_multi_symbol_backtest(
    *,
    primary_timeframe: str,
    candles_by_symbol_tf: dict[str, dict[str, list[Candle]]],
    paper_config: PaperTradingConfig,
    risk_limits: RiskLimits = DEFAULT_RISK_LIMITS,
    signal_config: SignalEngineConfig = DEFAULT_CONFIG,
    btc_symbol: str = "BTCUSDT",
    real_data_used: bool = False,
) -> dict[str, ReplayResult]:
    """Runs a chronological, interleaved replay across MULTIPLE symbols
    sharing one account/repository/clock — required for portfolio-level
    risk gates (max open trades across the whole account, daily loss as
    a % of the shared account balance, daily trade count) to be
    enforced the same way they would be live, rather than each symbol
    pretending it has the whole account to itself.

    Symbols are advanced in lock-step by TIMESTAMP (not by index): at
    each unique primary-timeframe close_time across the whole
    universe, every symbol whose candle closes at that instant is
    evaluated, in a fixed (sorted) symbol order for determinism, before
    the clock advances further. This keeps the multi-symbol replay
    genuinely chronological — a symbol with a data gap never gets
    evaluated \"ahead\" of another symbol's earlier-in-time candle.
    """
    symbols = sorted(candles_by_symbol_tf.keys())
    btc_candles = candles_by_symbol_tf.get(btc_symbol, {}).get(primary_timeframe)

    clock = SimulatedClock()
    repository = BacktestRepository(clock=clock, account_id=DEFAULT_ACCOUNT_ID)
    market_data = ReplayMarketData(
        primary_timeframe=primary_timeframe, candles_by_symbol_tf=candles_by_symbol_tf, btc_symbol=btc_symbol,
    )

    runners: dict[str, BacktestRunner] = {}
    for symbol in symbols:
        runners[symbol] = BacktestRunner(
            symbol=symbol,
            primary_timeframe=primary_timeframe,
            candles_by_tf=candles_by_symbol_tf[symbol],
            btc_candles=btc_candles,
            repository=repository,
            clock=clock,
            paper_config=paper_config,
            risk_limits=risk_limits,
            signal_config=signal_config,
            market_data=market_data,
            real_data_used=real_data_used,
        )

    # Build a single global, chronologically sorted timeline of
    # (close_time, symbol, index) across every symbol's primary series.
    timeline: list[tuple] = []
    for symbol in symbols:
        series = candles_by_symbol_tf[symbol].get(primary_timeframe, [])
        for i, c in enumerate(series):
            timeline.append((c.close_time, symbol, i, c))
    timeline.sort(key=lambda t: (t[0], t[1]))  # stable, deterministic tie-break by symbol name

    results: dict[str, ReplayResult] = {
        symbol: ReplayResult(symbol=symbol, timeframe=primary_timeframe, real_data_used=real_data_used)
        for symbol in symbols
    }
    for symbol in symbols:
        account = await repository.get_or_create_account(
            starting_balance=paper_config.starting_balance_usd, account_id=DEFAULT_ACCOUNT_ID
        )
        results[symbol].starting_balance = account.starting_balance

    for close_time, symbol, index, candle in timeline:
        clock.advance_to(close_time)
        market_data.advance(symbol, index)
        runner = runners[symbol]

        await runner._check_and_apply_intrabar_exit(candle)  # noqa: SLF001 — same-package orchestration
        try:
            await runner.pipeline.evaluate_symbol(symbol, primary_timeframe)
        except Exception as e:  # noqa: BLE001
            logger.error("Replay error for %s at %s: %s", symbol, candle.open_time, e)
        runner._update_mfe_mae(candle)  # noqa: SLF001

        account = await repository.get_account(DEFAULT_ACCOUNT_ID)
        open_positions = await repository.get_open_positions(DEFAULT_ACCOUNT_ID)
        unrealized = sum(p.unrealized_pnl(candle.close) for p in open_positions if p.symbol == symbol)
        equity = account.current_balance + unrealized if account else 0.0
        results[symbol].equity_curve.append((close_time, equity))
        results[symbol].candles_evaluated += 1

    account = await repository.get_account(DEFAULT_ACCOUNT_ID)
    for symbol in symbols:
        results[symbol].ending_balance = account.current_balance if account else results[symbol].starting_balance
        for closed in repository.all_closed_positions(DEFAULT_ACCOUNT_ID):
            if closed.symbol != symbol:
                continue
            runner = runners[symbol]
            regime_keys = runner._regime_keys_at(closed.opened_at)  # noqa: SLF001
            mfe, mae = runner._mfe_mae.get(closed.id, (0.0, 0.0))  # noqa: SLF001
            results[symbol].trades.append(
                TradeRecord(position=closed, regime_keys_at_entry=regime_keys, mfe_percent=mfe, mae_percent=mae)
            )
        results[symbol].signal_log = [s for s in repository.signal_log if s.symbol == symbol]
        results[symbol].risk_events = [e for e in repository.risk_events if e.get("symbol") == symbol]

    return results
