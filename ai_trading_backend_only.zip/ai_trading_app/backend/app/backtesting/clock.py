"""A simulated clock the replay engine advances candle-by-candle.

Every timestamped decision in a backtest (cooldowns, daily-loss/daily-
trade windows, max-holding-time, signal `generated_at`) must be judged
against the *simulated* point in historical time the replay has
reached — never the real wall clock. Passing a `SimulatedClock` into
`BacktestRepository` and `replay_engine` is what makes that guarantee
hold; nothing in this package calls `datetime.now()` for a trading
decision.
"""

from __future__ import annotations

from datetime import datetime, timezone


class SimulatedClock:
    """Mutable holder of "now" for one backtest run. `replay_engine`
    advances it to each candle's close time before evaluating that
    candle — so a look-ahead bug (e.g. accidentally reading real wall
    time) is structurally avoided rather than just avoided by
    convention."""

    def __init__(self, start: datetime | None = None):
        self._now = start or datetime(1970, 1, 1, tzinfo=timezone.utc)

    def now(self) -> datetime:
        return self._now

    def advance_to(self, ts: datetime) -> None:
        if ts.tzinfo is None:
            raise ValueError("SimulatedClock requires timezone-aware datetimes")
        if ts < self._now:
            raise ValueError(
                f"SimulatedClock cannot move backwards: {ts.isoformat()} < {self._now.isoformat()} "
                "(this would indicate a chronological-ordering bug in the replay)"
            )
        self._now = ts
