"""Top-level entry point that ties data acquisition (real Binance
historical data, honestly falling back to a clearly-labeled synthetic
run only for automated tests), the replay engine, walk-forward/OOS
validation, and report assembly together into the single call the API
router (and, transitively, the Flutter Backtesting screen) uses.

This module NEVER silently substitutes synthetic data for a real-data
request. If real historical data cannot be fetched, `run_backtest`
returns a result with `data_provenance="real_data_blocked"` and a
populated `blocked_reasons` list — it does not proceed with fixtures
unless the caller explicitly passes `allow_synthetic_fallback=True`
(used ONLY by the test suite), and even then the returned report is
labeled synthetic in every disclaimer (see `reports.py`).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ..paper_trading.config import PaperTradingConfig
from ..paper_trading.pipeline import DEFAULT_RISK_LIMITS, RiskLimits
from ..services.market_data.models import Candle
from ..signal_engine.config import DEFAULT_CONFIG, SignalEngineConfig
from .historical_data import HistoricalDataCache, try_fetch_real_historical_data
from .reports import FinalOosReport, OverallBacktestReport, build_final_oos_report, build_overall_report
from .replay_engine import ReplayResult, run_multi_symbol_backtest
from .walk_forward import ParameterSet, WalkForwardReport, run_walk_forward_backtest

DATA_PROVENANCE_REAL = "real_binance_historical_data"
DATA_PROVENANCE_BLOCKED = "real_data_blocked"
DATA_PROVENANCE_SYNTHETIC_TEST_ONLY = "synthetic_fixture_test_only"


@dataclass
class BacktestRunOutcome:
    data_provenance: str
    real_data_used: bool
    blocked_reasons: list[str] = field(default_factory=list)
    overall_report: OverallBacktestReport | None = None
    walk_forward_report: WalkForwardReport | None = None
    final_oos_report: FinalOosReport | None = None
    per_symbol_results: dict[str, ReplayResult] = field(default_factory=dict)


async def run_backtest(
    *,
    symbols: tuple[str, ...],
    primary_timeframe: str = "1h",
    confirmation_timeframes: tuple[str, ...] = ("15m", "1h", "4h"),
    start: datetime,
    end: datetime,
    signal_config: SignalEngineConfig = DEFAULT_CONFIG,
    risk_limits: RiskLimits = DEFAULT_RISK_LIMITS,
    paper_config: PaperTradingConfig = None,  # type: ignore[assignment]
    run_walk_forward: bool = True,
    train_candles: int = 400,
    validation_candles: int = 150,
    test_candles: int = 150,
    oos_fraction: float = 0.2,
    cache: HistoricalDataCache | None = None,
    binance_base_url: str = "https://api.binance.com",
    allow_synthetic_fallback: bool = False,
    synthetic_candles_by_symbol_tf: dict[str, dict[str, list[Candle]]] | None = None,
    parameter_label: str = "default",
) -> BacktestRunOutcome:
    """The one function the API layer calls. Always attempts real
    Binance historical data first. Only uses synthetic data when
    `allow_synthetic_fallback=True` AND `synthetic_candles_by_symbol_tf`
    is supplied by the caller — production API callers must never set
    this; it exists for the automated test suite only (see
    `test_backtest_*` files, which construct fixtures via
    `fixtures.py` and pass them in explicitly rather than relying on
    an implicit fallback path that could accidentally fire in
    production).
    """
    paper_config = paper_config or PaperTradingConfig()
    all_timeframes = tuple(sorted(set(confirmation_timeframes) | {primary_timeframe}))

    real_data, errors = await try_fetch_real_historical_data(
        symbols=symbols, intervals=all_timeframes, start=start, end=end, cache=cache, base_url=binance_base_url,
    )
    has_complete_real_data = all(
        real_data.get(s, {}).get(tf) for s in symbols for tf in all_timeframes
    )

    if has_complete_real_data:
        candles_by_symbol_tf = real_data
        provenance = DATA_PROVENANCE_REAL
        real_data_used = True
        blocked_reasons: list[str] = []
    elif allow_synthetic_fallback and synthetic_candles_by_symbol_tf:
        candles_by_symbol_tf = synthetic_candles_by_symbol_tf
        provenance = DATA_PROVENANCE_SYNTHETIC_TEST_ONLY
        real_data_used = False
        blocked_reasons = errors
    else:
        return BacktestRunOutcome(
            data_provenance=DATA_PROVENANCE_BLOCKED, real_data_used=False, blocked_reasons=errors,
        )

    parameter_set = ParameterSet(
        label=parameter_label,
        signal_config=signal_config,
        risk_limits_kwargs={
            "min_confidence": risk_limits.min_confidence,
            "max_daily_loss_percent": risk_limits.max_daily_loss_percent,
            "max_risk_per_trade_percent": risk_limits.max_risk_per_trade_percent,
            "max_open_trades": risk_limits.max_open_trades,
            "max_trades_per_day": risk_limits.max_trades_per_day,
            "cooldown_seconds": risk_limits.cooldown_seconds,
            "max_data_staleness_seconds": risk_limits.max_data_staleness_seconds,
        },
        paper_config=paper_config,
    )

    per_symbol_results = await run_multi_symbol_backtest(
        primary_timeframe=primary_timeframe, candles_by_symbol_tf=candles_by_symbol_tf,
        paper_config=paper_config, risk_limits=risk_limits, signal_config=signal_config,
        real_data_used=real_data_used,
    )
    from .walk_forward import _merge_results

    merged = _merge_results(per_symbol_results, primary_timeframe, real_data_used)
    overall_report = build_overall_report(
        merged_result=merged, per_symbol_results=per_symbol_results, data_provenance=provenance,
    )

    walk_forward_report = None
    final_oos_report = None
    if run_walk_forward:
        try:
            walk_forward_report = await run_walk_forward_backtest(
                primary_timeframe=primary_timeframe, candles_by_symbol_tf=candles_by_symbol_tf,
                parameter_set=parameter_set, risk_limits=risk_limits,
                train_candles=train_candles, validation_candles=validation_candles, test_candles=test_candles,
                oos_fraction=oos_fraction, real_data_used=real_data_used,
            )
            final_oos_report = build_final_oos_report(walk_forward_report)
        except ValueError as e:
            # Not enough candles for the requested window sizes — report
            # this honestly rather than silently skipping walk-forward.
            blocked_reasons.append(f"Walk-forward validation skipped: {e}")

    return BacktestRunOutcome(
        data_provenance=provenance,
        real_data_used=real_data_used,
        blocked_reasons=blocked_reasons,
        overall_report=overall_report,
        walk_forward_report=walk_forward_report,
        final_oos_report=final_oos_report,
        per_symbol_results=per_symbol_results,
    )
