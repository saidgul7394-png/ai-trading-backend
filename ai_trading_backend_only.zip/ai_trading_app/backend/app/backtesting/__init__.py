"""Phase 4 — Backtesting, Walk-Forward Validation, and Out-of-Sample
(OOS) validation for the Signal Fusion + Quality Gate + Risk Engine +
Position Management stack built in Phases 1-3.

No live Binance order execution happens anywhere in this package.
Every trade produced here is a simulated fill against historical
candle data, using the exact same pure decision functions Phase 3's
paper-trading pipeline uses (`signal_engine.composite.build_composite_signal`,
`risk_engine.engine.evaluate_trade_proposal`,
`paper_trading.position_manager.evaluate_exit` /
`compute_trailing_stop`, `paper_trading.engine`'s fee/slippage fill
math) — nothing here re-implements or approximates that logic.

Sub-modules:
  - `clock.py`              — injectable simulated time source
  - `historical_data.py`    — real Binance historical klines fetcher
                               (network) + local CSV cache; clearly
                               separated from anything synthetic
  - `backtest_repository.py`— in-memory, simulated-clock-aware stand-in
                               for `paper_trading.repository.PaperTradingRepository`
  - `replay_engine.py`      — chronological, no-look-ahead candle-by-candle
                               replay driving signal -> risk -> execution ->
                               position management
  - `regimes.py`            — market regime classification/labeling
  - `metrics.py`            — performance + signal-quality metrics
  - `walk_forward.py`       — train/validation/test window splitting,
                               OOS isolation, parameter versioning
  - `reports.py`            — report assembly (equity curve, drawdown,
                               per-symbol, per-regime, trade journal, etc.)
  - `fixtures.py`           — deterministic synthetic OHLCV fixtures,
                               UNIT TESTS ONLY — never presented as real
                               market history or real profitability
"""
