"""Real Binance historical market data for backtesting.

This module ONLY ever produces `Candle` objects sourced from Binance's
public `/api/v3/klines` REST endpoint (via `BinanceRestClient`, the
exact same client Phase 2's live market-data layer uses — no separate,
divergent HTTP code path). It never fabricates a candle.

If network egress to Binance is unavailable in the current environment
(sandboxed CI, this development container, etc.), `fetch_historical_klines`
raises `HistoricalDataUnavailableError` — callers MUST surface this to
the user as "REAL HISTORICAL VALIDATION BLOCKED" rather than silently
falling back to synthetic data. Synthetic data lives in `fixtures.py`
and is used ONLY by the automated test suite, never presented as real
market history.

A minimal on-disk cache (`HistoricalDataCache`) avoids re-downloading
the same symbol/interval/time-range across repeated backtest runs.
"""

from __future__ import annotations

import csv
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..services.market_data.binance_client import BinanceRestClient

from ..services.market_data.models import Candle, INTERVAL_SECONDS, validate_interval, validate_symbol

# NOTE: `BinanceRestClient` is imported lazily (inside functions, not at
# module level) because it in turn imports `httpx` at ITS module level.
# In environments where `httpx` isn't installed (this sandbox has no
# network egress to pip-install it), a top-level import here would make
# this entire module — and therefore every other backtesting module
# that imports fixtures/metrics/etc. from this package — fail to
# import, even for callers who only want synthetic-fixture backtests
# and never touch real historical data. Deferring the import means the
# *absence* of httpx surfaces as a clean, catchable
# `HistoricalDataUnavailableError` exactly where real-data fetching is
# attempted, instead of an ImportError anywhere `backtesting` is used.

logger = logging.getLogger("backtesting.historical_data")

DEFAULT_CACHE_DIR = "backtest_data_cache"

# Binance's REST kline endpoint caps a single request at 1000 candles;
# fetching a large historical window means paging backwards in time.
MAX_KLINES_PER_REQUEST = 1000


class HistoricalDataUnavailableError(Exception):
    """Raised when real Binance historical data cannot actually be
    downloaded in the current environment (no network egress, DNS
    failure, connection refused, HTTP error, etc.) — the caller must
    treat this as "real validation is blocked", never as "proceed with
    something else and call it real"."""


@dataclass(frozen=True)
class HistoricalDataRequest:
    symbol: str
    interval: str
    start: datetime
    end: datetime


async def fetch_historical_klines(
    client: "BinanceRestClient",  # noqa: F821 — see lazy-import note above
    request: HistoricalDataRequest,
) -> list[Candle]:
    """Pages backwards through Binance's public klines endpoint to
    assemble one continuous, chronologically-sorted candle series
    covering [start, end]. Raises `HistoricalDataUnavailableError`
    (never returns partial/fabricated data) if the request cannot be
    completed — a partially-downloaded history would be worse than no
    history, since it could silently understate how much data a
    backtest is actually running against.
    """
    symbol = validate_symbol(request.symbol, client._allowed_symbols) if client._allowed_symbols else request.symbol.upper()
    interval = validate_interval(request.interval)
    interval_seconds = INTERVAL_SECONDS[interval]

    if request.end <= request.start:
        raise ValueError("end must be after start")

    collected: list[Candle] = []
    cursor_end = request.end

    try:
        # Page backwards: each request asks for up to 1000 candles
        # ending at cursor_end, then moves cursor_end back before the
        # earliest candle returned, until we've covered `start`.
        guard_iterations = 0
        max_iterations = 500  # generous ceiling to avoid an infinite loop on unexpected data
        while cursor_end > request.start:
            guard_iterations += 1
            if guard_iterations > max_iterations:
                raise HistoricalDataUnavailableError(
                    f"Exceeded {max_iterations} paged requests fetching {symbol} {interval} "
                    f"{request.start} -> {request.end} — aborting rather than looping indefinitely."
                )

            batch = await client.get_klines(symbol, interval, limit=MAX_KLINES_PER_REQUEST)
            if not batch:
                break

            in_range = [c for c in batch if request.start <= c.open_time <= cursor_end]
            collected.extend(in_range)

            earliest = min(c.open_time for c in batch)
            if earliest >= cursor_end:
                # No progress — avoid an infinite loop.
                break
            cursor_end = earliest

        if not collected:
            raise HistoricalDataUnavailableError(
                f"No historical candles returned for {symbol} {interval} "
                f"{request.start.isoformat()} -> {request.end.isoformat()}."
            )

    except HistoricalDataUnavailableError:
        raise
    except Exception as e:  # noqa: BLE001 — any network/HTTP/parsing failure means "blocked", not "proceed"
        raise HistoricalDataUnavailableError(
            f"Failed to fetch real Binance historical data for {symbol} {interval}: {e}"
        ) from e

    # Dedupe (paging windows can overlap at the boundary) and sort chronologically.
    by_open_time = {c.open_time: c for c in collected}
    ordered = sorted(by_open_time.values(), key=lambda c: c.open_time)

    _validate_no_gaps(ordered, interval_seconds, symbol=symbol, interval=interval)
    return ordered


def _validate_no_gaps(candles: list[Candle], interval_seconds: int, *, symbol: str, interval: str) -> None:
    """Logs (never silently ignores) any gap in the downloaded series.
    A gap doesn't necessarily mean the data is unusable (Binance can
    have genuine short outages), but a backtest report must be honest
    about it rather than pretending the series is complete."""
    for i in range(1, len(candles)):
        expected = candles[i - 1].open_time.timestamp() + interval_seconds
        actual = candles[i].open_time.timestamp()
        if actual - expected > interval_seconds * 0.5:
            logger.warning(
                "Gap detected in historical data for %s %s: %s -> %s",
                symbol, interval, candles[i - 1].open_time.isoformat(), candles[i].open_time.isoformat(),
            )


class HistoricalDataCache:
    """Simple CSV-per-(symbol,interval) on-disk cache so repeated
    backtest runs don't re-download the same history. Explicitly NOT a
    generator of data — every row it ever writes came from a real
    `fetch_historical_klines` call; it only ever replays what was
    genuinely downloaded."""

    def __init__(self, cache_dir: str | Path = DEFAULT_CACHE_DIR):
        self._dir = Path(cache_dir)

    def _path(self, symbol: str, interval: str) -> Path:
        self._dir.mkdir(parents=True, exist_ok=True)
        return self._dir / f"{symbol.upper()}_{interval}.csv"

    def save(self, symbol: str, interval: str, candles: list[Candle]) -> Path:
        path = self._path(symbol, interval)
        with path.open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["open_time", "close_time", "open", "high", "low", "close", "volume"])
            for c in candles:
                writer.writerow(
                    [c.open_time.isoformat(), c.close_time.isoformat(), c.open, c.high, c.low, c.close, c.volume]
                )
        return path

    def load(self, symbol: str, interval: str) -> list[Candle] | None:
        path = self._path(symbol, interval)
        if not path.exists():
            return None
        candles: list[Candle] = []
        with path.open(newline="") as f:
            for row in csv.DictReader(f):
                candles.append(
                    Candle(
                        symbol=symbol.upper(),
                        interval=interval,
                        open_time=datetime.fromisoformat(row["open_time"]),
                        close_time=datetime.fromisoformat(row["close_time"]),
                        open=float(row["open"]),
                        high=float(row["high"]),
                        low=float(row["low"]),
                        close=float(row["close"]),
                        volume=float(row["volume"]),
                        is_closed=True,
                    )
                )
        return candles or None


async def try_fetch_real_historical_data(
    *,
    symbols: tuple[str, ...],
    intervals: tuple[str, ...],
    start: datetime,
    end: datetime,
    cache: HistoricalDataCache | None = None,
    base_url: str = "https://api.binance.com",
) -> tuple[dict[str, dict[str, list[Candle]]], list[str]]:
    """Best-effort attempt to assemble a real historical dataset for
    every (symbol, interval) pair. Returns (data, errors) — `data`
    contains only pairs that genuinely succeeded (from cache or a live
    fetch); `errors` lists exactly which pairs failed and why, so the
    caller can honestly report "REAL HISTORICAL VALIDATION BLOCKED"
    with specifics rather than a vague failure.

    This function deliberately never raises for a network failure —
    the caller (the backtest orchestrator) decides how to report a
    partial or total inability to reach Binance; a raised exception
    here would make it awkward to report *which* pairs are affected.
    """
    cache = cache or HistoricalDataCache()
    data: dict[str, dict[str, list[Candle]]] = {}
    errors: list[str] = []

    client = None
    try:
        from ..services.market_data.binance_client import BinanceRestClient  # deferred — see module note

        client = BinanceRestClient(base_url=base_url)
    except Exception as e:  # noqa: BLE001 — e.g. httpx not installed, or no network egress at all
        errors.append(
            f"Could not construct a Binance REST client in this environment (network/dependency "
            f"unavailable): {e}"
        )
        client = None

    try:
        for symbol in symbols:
            data[symbol] = {}
            for interval in intervals:
                cached = cache.load(symbol, interval)
                if cached:
                    data[symbol][interval] = cached
                    continue

                if client is None:
                    errors.append(f"{symbol} {interval}: no network client available")
                    continue

                try:
                    candles = await fetch_historical_klines(
                        client, HistoricalDataRequest(symbol=symbol, interval=interval, start=start, end=end)
                    )
                    cache.save(symbol, interval, candles)
                    data[symbol][interval] = candles
                except HistoricalDataUnavailableError as e:
                    errors.append(f"{symbol} {interval}: {e}")
    finally:
        if client is not None:
            try:
                await client.close()
            except Exception:  # noqa: BLE001
                pass

    return data, errors
