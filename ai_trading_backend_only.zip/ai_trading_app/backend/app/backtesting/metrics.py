"""Performance and signal-quality metrics (Phase 4 spec items 4 and 5).

Every function here is a pure computation over already-produced
`replay_engine.ReplayResult` / `TradeRecord` / signal-log data — no
side effects, no I/O, deterministic given the same input. This is what
makes metrics independently unit-testable against hand-computed
expected values (see `test_backtest_metrics.py`).

Confidence-calibration note (explicit anti-overconfidence requirement
from the spec): `confidence_calibration` below reports the OBSERVED
win rate within each confidence bucket, precisely so it can be
compared against the bucket's confidence range — and a mismatch is the
expected, useful outcome to see, not a bug. Nothing in this module
converts "confidence" into a promised win probability; every report
that surfaces calibration output must keep it framed as descriptive
history, never as forward-looking odds. See `reports.py`'s disclaimer
text for the user-facing wording.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ..paper_trading.models import PaperPosition, PositionSide
from .replay_engine import ReplayResult, TradeRecord


@dataclass
class PerformanceMetrics:
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    breakeven_trades: int = 0
    win_rate_percent: float = 0.0
    profit_factor: float | None = None  # gross_profit / gross_loss; None if no losses to divide by
    expectancy: float = 0.0  # average realized P&L per trade
    net_pnl: float = 0.0
    gross_profit: float = 0.0
    gross_loss: float = 0.0  # positive number (magnitude)
    average_win: float = 0.0
    average_loss: float = 0.0  # negative or zero
    average_r_multiple: float | None = None  # avg (realized_pnl / initial $ risk) across trades where risk is known
    max_drawdown_percent: float = 0.0
    max_drawdown_absolute: float = 0.0
    max_consecutive_wins: int = 0
    max_consecutive_losses: int = 0
    total_fees: float = 0.0
    total_slippage: float = 0.0
    long_trades: int = 0
    short_trades: int = 0
    long_win_rate_percent: float = 0.0
    short_win_rate_percent: float = 0.0
    long_net_pnl: float = 0.0
    short_net_pnl: float = 0.0
    average_mfe_percent: float = 0.0
    average_mae_percent: float = 0.0


def _is_win(pnl: float | None) -> bool:
    return pnl is not None and pnl > 0


def _is_loss(pnl: float | None) -> bool:
    return pnl is not None and pnl < 0


def compute_performance_metrics(trades: list[TradeRecord]) -> PerformanceMetrics:
    """Computes every metric in item 4 of the Phase 4 spec from a flat
    list of closed trades. Order of `trades` matters for drawdown and
    consecutive win/loss streaks — callers MUST pass trades in
    chronological (open-time) order, which is what `ReplayResult.trades`
    already guarantees (see `replay_engine.BacktestRunner.run`)."""
    m = PerformanceMetrics()
    m.total_trades = len(trades)
    if not trades:
        return m

    pnls = [t.position.realized_pnl or 0.0 for t in trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]
    breakeven = [p for p in pnls if p == 0]

    m.winning_trades = len(wins)
    m.losing_trades = len(losses)
    m.breakeven_trades = len(breakeven)
    m.win_rate_percent = (len(wins) / m.total_trades) * 100.0

    m.gross_profit = sum(wins)
    m.gross_loss = abs(sum(losses))
    m.net_pnl = sum(pnls)
    m.profit_factor = (m.gross_profit / m.gross_loss) if m.gross_loss > 0 else None
    m.expectancy = m.net_pnl / m.total_trades

    m.average_win = (m.gross_profit / len(wins)) if wins else 0.0
    m.average_loss = (sum(losses) / len(losses)) if losses else 0.0

    r_multiples = []
    for t in trades:
        p = t.position
        initial_risk = abs(p.entry_price - p.stop_loss) * p.quantity
        if initial_risk > 0 and p.realized_pnl is not None:
            r_multiples.append(p.realized_pnl / initial_risk)
    m.average_r_multiple = (sum(r_multiples) / len(r_multiples)) if r_multiples else None

    m.total_fees = sum((t.position.entry_fee or 0.0) + (t.position.exit_fee or 0.0) for t in trades)

    equity = 0.0
    peak = 0.0
    max_dd_abs = 0.0
    max_dd_pct = 0.0
    running_wins = running_losses = 0
    max_run_wins = max_run_losses = 0
    for pnl in pnls:
        equity += pnl
        peak = max(peak, equity)
        drawdown = peak - equity
        max_dd_abs = max(max_dd_abs, drawdown)
        if peak > 0:
            max_dd_pct = max(max_dd_pct, (drawdown / peak) * 100.0)

        if pnl > 0:
            running_wins += 1
            running_losses = 0
        elif pnl < 0:
            running_losses += 1
            running_wins = 0
        else:
            running_wins = running_losses = 0
        max_run_wins = max(max_run_wins, running_wins)
        max_run_losses = max(max_run_losses, running_losses)

    m.max_drawdown_absolute = max_dd_abs
    m.max_drawdown_percent = max_dd_pct
    m.max_consecutive_wins = max_run_wins
    m.max_consecutive_losses = max_run_losses

    longs = [t for t in trades if t.position.side == PositionSide.LONG]
    shorts = [t for t in trades if t.position.side == PositionSide.SHORT]
    m.long_trades = len(longs)
    m.short_trades = len(shorts)
    long_pnls = [t.position.realized_pnl or 0.0 for t in longs]
    short_pnls = [t.position.realized_pnl or 0.0 for t in shorts]
    m.long_net_pnl = sum(long_pnls)
    m.short_net_pnl = sum(short_pnls)
    m.long_win_rate_percent = (sum(1 for p in long_pnls if p > 0) / len(longs) * 100.0) if longs else 0.0
    m.short_win_rate_percent = (sum(1 for p in short_pnls if p > 0) / len(shorts) * 100.0) if shorts else 0.0

    m.average_mfe_percent = sum(t.mfe_percent for t in trades) / len(trades)
    m.average_mae_percent = sum(t.mae_percent for t in trades) / len(trades)

    return m


@dataclass
class SymbolBreakdown:
    symbol: str
    metrics: PerformanceMetrics


def compute_per_symbol_metrics(results: dict[str, ReplayResult]) -> list[SymbolBreakdown]:
    return [SymbolBreakdown(symbol=sym, metrics=compute_performance_metrics(res.trades)) for sym, res in results.items()]


@dataclass
class RegimeBreakdown:
    regime: str
    metrics: PerformanceMetrics


def compute_per_regime_metrics(results: dict[str, ReplayResult]) -> list[RegimeBreakdown]:
    """Buckets every trade across every symbol by each regime key it
    was tagged with at entry (a trade can appear in more than one
    regime bucket, e.g. both "bull" and "low_volatility" — see
    `regimes.regime_keys_for_label`). Item 3 of the spec requires
    exactly these seven buckets; a bucket with zero trades still
    appears with `total_trades=0` rather than being silently omitted,
    so the report is explicit about which regimes this run had no
    coverage for.
    """
    from .regimes import ALL_REGIME_KEYS

    by_regime: dict[str, list[TradeRecord]] = {k: [] for k in ALL_REGIME_KEYS}
    for res in results.values():
        for trade in res.trades:
            for key in trade.regime_keys_at_entry:
                by_regime.setdefault(key, []).append(trade)

    return [RegimeBreakdown(regime=k, metrics=compute_performance_metrics(v)) for k, v in by_regime.items()]


# ---------------------------------------------------------------------------
# Signal quality (spec item 5)
# ---------------------------------------------------------------------------


@dataclass
class SignalQualityReport:
    total_signals: int = 0
    buy_signals: int = 0
    sell_signals: int = 0
    hold_signals: int = 0
    eligible_signals: int = 0
    executed_signals: int = 0  # eligible AND actually resulted in a trade
    false_signals: int = 0  # eligible, executed, and closed at a net loss
    risk_rejections: int = 0
    risk_rejection_reasons: dict[str, int] = field(default_factory=dict)


def compute_signal_quality(
    *, signal_log: list, risk_events: list, trades: list[TradeRecord]
) -> SignalQualityReport:
    """`false_signals` here means "the composite engine called a
    direction with enough conviction to be eligible for auto-trade, the
    trade was actually taken, and it closed at a net loss" — a concrete,
    falsifiable definition tied to real outcomes, not a vague notion of
    'signal was wrong'. WATCH/NO-TRADE (i.e. HOLD or non-eligible)
    signals are intentionally excluded from the false-signal count:
    they never made a claim to evaluate.
    """
    report = SignalQualityReport()
    report.total_signals = len(signal_log)
    for s in signal_log:
        if s.action == "BUY":
            report.buy_signals += 1
        elif s.action == "SELL":
            report.sell_signals += 1
        else:
            report.hold_signals += 1
        if s.eligible_for_auto_trade:
            report.eligible_signals += 1

    executed_signal_ids = {t.position.signal_id for t in trades}
    report.executed_signals = len(executed_signal_ids)

    losing_trades = [t for t in trades if (t.position.realized_pnl or 0.0) < 0]
    report.false_signals = len(losing_trades)

    for e in risk_events:
        if e.get("event_type") == "RISK_BLOCK":
            report.risk_rejections += 1
            for reason in e.get("payload", {}).get("reasons", []):
                report.risk_rejection_reasons[reason] = report.risk_rejection_reasons.get(reason, 0) + 1

    return report


@dataclass
class ConfidenceBucket:
    label: str  # e.g. "60-70%"
    low: float
    high: float
    trade_count: int
    observed_win_rate_percent: float | None  # None if trade_count == 0
    average_pnl: float


def confidence_calibration(trades: list[TradeRecord], *, bucket_width: float = 0.1) -> list[ConfidenceBucket]:
    """Buckets closed trades by the signal's confidence AT ENTRY
    (`signal_confidence_at_entry`, already recorded on the position by
    the unmodified paper-trading engine) and reports the OBSERVED win
    rate per bucket. This is deliberately a look-BACK comparison
    (confidence vs what actually happened), never a forward-looking
    probability — see module docstring and `reports.py`'s disclaimer.
    """
    buckets: list[ConfidenceBucket] = []
    edges = []
    edge = 0.0
    while edge < 1.0:
        edges.append((edge, min(edge + bucket_width, 1.0)))
        edge += bucket_width

    for low, high in edges:
        in_bucket = [
            t for t in trades
            if low <= t.position.signal_confidence_at_entry < high
            or (high >= 1.0 and t.position.signal_confidence_at_entry == 1.0)
        ]
        if not in_bucket:
            buckets.append(
                ConfidenceBucket(
                    label=f"{int(low*100)}-{int(high*100)}%", low=low, high=high,
                    trade_count=0, observed_win_rate_percent=None, average_pnl=0.0,
                )
            )
            continue
        wins = sum(1 for t in in_bucket if (t.position.realized_pnl or 0.0) > 0)
        pnls = [t.position.realized_pnl or 0.0 for t in in_bucket]
        buckets.append(
            ConfidenceBucket(
                label=f"{int(low*100)}-{int(high*100)}%", low=low, high=high,
                trade_count=len(in_bucket),
                observed_win_rate_percent=(wins / len(in_bucket)) * 100.0,
                average_pnl=sum(pnls) / len(pnls),
            )
        )
    return buckets


@dataclass
class FactorContribution:
    factor_name: str
    appearances: int
    average_leaning_when_directional: float  # avg |leaning| across signals where this factor was present and action != HOLD
    appearances_in_winning_trades: int
    appearances_in_losing_trades: int


def compute_factor_contribution(signal_log: list, trades: list[TradeRecord]) -> list[FactorContribution]:
    """For each factor name, how often it appeared, how strongly it
    leaned when the composite signal went directional, and — by joining
    against executed trades via `signal_id`/timestamp proximity — how
    often that factor was present in signals that became winning vs
    losing trades. This is a descriptive breakdown for understanding
    which factors correlate with outcomes in THIS backtest run, not a
    causal attribution and not a promise the same pattern repeats.
    """
    totals: dict[str, list[float]] = {}
    for s in signal_log:
        if s.action == "HOLD":
            continue
        for f in s.factors:
            totals.setdefault(f["name"], []).append(abs(f["leaning"]))

    # Map signal_id -> win/loss via trades that reference it.
    win_signal_ids = {t.position.signal_id for t in trades if (t.position.realized_pnl or 0.0) > 0}
    loss_signal_ids = {t.position.signal_id for t in trades if (t.position.realized_pnl or 0.0) < 0}

    factor_in_trade: dict[str, dict[str, int]] = {}
    signal_by_symbol_time: dict = {}
    for s in signal_log:
        key = (s.symbol, s.timeframe, s.generated_at)
        signal_by_symbol_time[key] = s

    for t in trades:
        matching = None
        for s in signal_log:
            if s.symbol == t.position.symbol and s.action != "HOLD":
                sid = f"{s.symbol}-{s.timeframe}-{int(s.generated_at.timestamp())}"
                if sid == t.position.signal_id:
                    matching = s
                    break
        if matching is None:
            continue
        outcome = "win" if (t.position.realized_pnl or 0.0) > 0 else ("loss" if (t.position.realized_pnl or 0.0) < 0 else None)
        if outcome is None:
            continue
        for f in matching.factors:
            bucket = factor_in_trade.setdefault(f["name"], {"win": 0, "loss": 0})
            bucket[outcome] += 1

    results = []
    for name, leanings in totals.items():
        wl = factor_in_trade.get(name, {"win": 0, "loss": 0})
        results.append(
            FactorContribution(
                factor_name=name,
                appearances=len(leanings),
                average_leaning_when_directional=sum(leanings) / len(leanings) if leanings else 0.0,
                appearances_in_winning_trades=wl["win"],
                appearances_in_losing_trades=wl["loss"],
            )
        )
    results.sort(key=lambda r: r.factor_name)
    return results
