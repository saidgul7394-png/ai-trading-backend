"""Market regime classification.

Labels each point in a candle series with the regime(s) it belongs to,
so backtest results can be sliced per-regime (item 3 of the Phase 4
spec: bull trend, bear trend, sideways/range, high volatility, low
volatility, strong BTC trend, weak BTC trend).

Classification reuses the exact same deterministic indicator functions
the signal engine itself uses (`signal_engine.indicators.market_structure`,
`.atr`) — a regime label is never a separate, invented heuristic that
could disagree with what the signal engine "sees" at that same candle.

Two independent axes are labeled per candle:
  - trend regime:      bull | bear | sideways   (own-symbol market structure)
  - volatility regime:  high | low               (ATR% relative to its own
                                                    trailing distribution)
Plus, when BTC candles are supplied, a market-wide axis:
  - btc regime:         strong_trend | weak_trend (BTC's own trend strength)

A candle can therefore carry labels like ("bull", "low", "strong_btc_trend")
simultaneously — regimes are not mutually exclusive across axes, only
within an axis.
"""

from __future__ import annotations

from dataclasses import dataclass
from statistics import median

from ..services.market_data.models import Candle
from ..signal_engine import indicators as ind

TREND_LOOKBACK = 30
VOLATILITY_ATR_PERIOD = 14
VOLATILITY_LOOKBACK = 60  # candles of trailing ATR% history used to judge "high" vs "low" for THIS symbol


@dataclass(frozen=True)
class RegimeLabel:
    trend: str  # "bull" | "bear" | "sideways" | "unknown" (unknown = not enough history yet)
    volatility: str  # "high" | "low" | "unknown"
    btc_trend: str | None  # "strong_btc_trend" | "weak_btc_trend" | None (no BTC series supplied)


def _trend_regime(candles: list[Candle], index: int) -> str:
    if index + 1 < TREND_LOOKBACK:
        return "unknown"
    window = candles[max(0, index + 1 - TREND_LOOKBACK) : index + 1]
    try:
        structure = ind.market_structure(window, lookback=min(TREND_LOOKBACK, len(window)))
    except ind.InsufficientDataError:
        return "unknown"
    return {"uptrend": "bull", "downtrend": "bear", "range": "sideways"}[structure]


def _atr_percent_series(candles: list[Candle], index: int) -> float | None:
    """ATR% at `index`, computed only from candles up to and including
    `index` — never from future candles (no look-ahead)."""
    if index + 1 < VOLATILITY_ATR_PERIOD + 1:
        return None
    window = candles[: index + 1]
    try:
        return ind.volatility_percent(window, period=VOLATILITY_ATR_PERIOD)
    except ind.InsufficientDataError:
        return None


def _volatility_regime(candles: list[Candle], index: int, *, trailing_atr_pcts: list[float]) -> str:
    current = _atr_percent_series(candles, index)
    if current is None:
        return "unknown"
    history = trailing_atr_pcts[-VOLATILITY_LOOKBACK:] if trailing_atr_pcts else []
    if len(history) < 10:
        # Not enough trailing distribution yet to judge relative
        # high/low — never fabricate a threshold from nothing.
        return "unknown"
    baseline = median(history)
    if baseline <= 0:
        return "unknown"
    return "high" if current >= baseline * 1.25 else "low"


def _btc_trend_regime(
    btc_candles: list[Candle], btc_index: int, *, trailing_btc_atr_pcts: list[float]
) -> str:
    """"Strong" vs "weak" BTC trend is judged RELATIVE to BTC's own
    trailing volatility distribution (the same relative-threshold
    approach `_volatility_regime` uses for the traded symbol), never an
    absolute ATR% cutoff — an absolute cutoff would silently miscalibrate
    across symbols/eras with very different baseline volatility (e.g. a
    quiet-BTC-era backtest could never register "strong" at all). A
    non-trending ("range") structure is always "weak" regardless of
    volatility, since a strong TREND requires directional structure, not
    just movement.
    """
    if btc_index + 1 < TREND_LOOKBACK:
        return "unknown"
    window = btc_candles[max(0, btc_index + 1 - TREND_LOOKBACK) : btc_index + 1]
    try:
        structure = ind.market_structure(window, lookback=min(TREND_LOOKBACK, len(window)))
    except ind.InsufficientDataError:
        return "unknown"

    if structure == "range":
        return "weak_btc_trend"

    atr_pct = _atr_percent_series(btc_candles, btc_index)
    if atr_pct is None:
        return "weak_btc_trend"

    history = trailing_btc_atr_pcts[-VOLATILITY_LOOKBACK:] if trailing_btc_atr_pcts else []
    if len(history) < 10:
        # Not enough trailing distribution to judge "strong" relative
        # to BTC's own baseline yet — directional structure alone,
        # without a volatility baseline to compare against, is treated
        # as weak rather than guessing.
        return "weak_btc_trend"

    baseline = median(history)
    if baseline <= 0:
        return "weak_btc_trend"
    return "strong_btc_trend" if atr_pct >= baseline * 0.9 else "weak_btc_trend"


def label_regimes(
    candles: list[Candle],
    *,
    btc_candles: list[Candle] | None = None,
) -> list[RegimeLabel]:
    """Returns one `RegimeLabel` per candle in `candles`, aligned by
    index. Every label at index `i` is computed using ONLY
    `candles[0:i+1]` (and, for the BTC axis, `btc_candles[0:i+1]`
    assuming aligned timestamps) — this is what guarantees regime
    slicing in reports can never leak future information into a
    backtest's per-regime breakdown.
    """
    labels: list[RegimeLabel] = []
    trailing_atr_pcts: list[float] = []
    trailing_btc_atr_pcts: list[float] = []

    # Build a lookup from candle open_time -> index for the BTC series
    # so we can align by timestamp rather than assume identical indexing
    # (BTC and an altcoin series can have gaps at different points).
    btc_index_by_time: dict = {}
    if btc_candles:
        btc_index_by_time = {c.open_time: i for i, c in enumerate(btc_candles)}

    # Pre-compute BTC's trailing ATR% at every index up front (BTC's
    # own series doesn't depend on `candles`' indexing/length), so each
    # loop iteration below can hand `_btc_trend_regime` the correct
    # BTC-relative trailing history regardless of gaps in `candles`.
    btc_atr_pct_by_index: dict[int, float] = {}
    if btc_candles:
        running: list[float] = []
        for j in range(len(btc_candles)):
            v = _atr_percent_series(btc_candles, j)
            if v is not None:
                btc_atr_pct_by_index[j] = v

    for i, candle in enumerate(candles):
        trend = _trend_regime(candles, i)
        volatility = _volatility_regime(candles, i, trailing_atr_pcts=trailing_atr_pcts)

        atr_pct = _atr_percent_series(candles, i)
        if atr_pct is not None:
            trailing_atr_pcts.append(atr_pct)

        btc_trend = None
        if btc_candles:
            btc_idx = btc_index_by_time.get(candle.open_time)
            if btc_idx is not None:
                # Trailing history strictly BEFORE btc_idx — no look-ahead.
                history = [btc_atr_pct_by_index[j] for j in range(btc_idx) if j in btc_atr_pct_by_index]
                btc_trend = _btc_trend_regime(btc_candles, btc_idx, trailing_btc_atr_pcts=history)

        labels.append(RegimeLabel(trend=trend, volatility=volatility, btc_trend=btc_trend))

    return labels


ALL_REGIME_KEYS = (
    "bull",
    "bear",
    "sideways",
    "high_volatility",
    "low_volatility",
    "strong_btc_trend",
    "weak_btc_trend",
)


def regime_keys_for_label(label: RegimeLabel) -> list[str]:
    """Flattens a RegimeLabel into the set of report bucket keys
    (item 3's seven required regimes) that this candle belongs to."""
    keys: list[str] = []
    if label.trend == "bull":
        keys.append("bull")
    elif label.trend == "bear":
        keys.append("bear")
    elif label.trend == "sideways":
        keys.append("sideways")

    if label.volatility == "high":
        keys.append("high_volatility")
    elif label.volatility == "low":
        keys.append("low_volatility")

    if label.btc_trend == "strong_btc_trend":
        keys.append("strong_btc_trend")
    elif label.btc_trend == "weak_btc_trend":
        keys.append("weak_btc_trend")

    return keys
