"""Report assembly (Phase 4 spec item 7).

Every report function here is a pure transformation from already-
computed replay/metrics data into a plain-dict/dataclass shape ready
to serialize as JSON (for the API layer) or hand to a template. No
report in this module computes a new number that isn't already backed
by `metrics.py`/`replay_engine.py` — reports format and organize,
they never invent.

CONFIDENCE DISCLAIMER (explicit spec requirement): every report that
surfaces `signal_confidence_at_entry` or `confidence_calibration`
output carries `CONFIDENCE_DISCLAIMER` verbatim, unabridged, wherever
that data is shown — see `build_signal_quality_report`. This is not
optional boilerplate; it is the mechanism by which this codebase
satisfies "confidence must NOT be presented as guaranteed win
probability."
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime

from ..paper_trading.models import PaperPosition
from .metrics import (
    ConfidenceBucket,
    FactorContribution,
    PerformanceMetrics,
    RegimeBreakdown,
    SignalQualityReport,
    SymbolBreakdown,
    compute_factor_contribution,
    compute_per_regime_metrics,
    compute_per_symbol_metrics,
    compute_performance_metrics,
    compute_signal_quality,
    confidence_calibration,
)
from .regimes import ALL_REGIME_KEYS
from .replay_engine import ReplayResult, TradeRecord
from .walk_forward import WalkForwardReport, detect_suspicious_overfitting

CONFIDENCE_DISCLAIMER = (
    "Confidence is a measure of how strongly the signal engine's factors agreed at "
    "the moment a signal was generated — NOT a probability of winning, and NOT a "
    "guarantee of any future outcome. The win rates shown per confidence bucket "
    "below are purely descriptive: what happened to trades that had that confidence "
    "level IN THIS BACKTEST RUN, on the data this run used. They are not a forecast."
)

REAL_DATA_DISCLAIMER = (
    "REAL HISTORICAL VALIDATION BLOCKED: this run used deterministic synthetic "
    "fixture data, not real Binance market history, because real historical data "
    "could not be downloaded in the current environment (see the run's "
    "`data_provenance` field for the specific reason). Nothing in this report "
    "should be read as a claim about real-market profitability."
)

NO_LIVE_TRADING_DISCLAIMER = (
    "This is a backtest of simulated trades against historical (or, when flagged, "
    "synthetic) price data. No live Binance orders were placed. Past performance — "
    "real or simulated — is not indicative of future results."
)


def _position_to_journal_row(trade: TradeRecord) -> dict:
    p = trade.position
    return {
        "position_id": p.id,
        "symbol": p.symbol,
        "side": p.side.value,
        "opened_at": p.opened_at.isoformat(),
        "closed_at": p.closed_at.isoformat() if p.closed_at else None,
        "entry_price": p.entry_price,
        "exit_price": p.exit_price,
        "quantity": p.quantity,
        "stop_loss": p.stop_loss,
        "take_profit": p.take_profit,
        "exit_reason": p.exit_reason.value if p.exit_reason else None,
        "realized_pnl": p.realized_pnl,
        "entry_fee": p.entry_fee,
        "exit_fee": p.exit_fee,
        "signal_confidence_at_entry": p.signal_confidence_at_entry,
        "mfe_percent": trade.mfe_percent,
        "mae_percent": trade.mae_percent,
        "regimes_at_entry": trade.regime_keys_at_entry,
    }


def build_trade_journal(trades: list[TradeRecord]) -> list[dict]:
    """Item 7: trade-by-trade journal. One row per closed trade,
    chronologically ordered (callers must pass trades already in that
    order — `ReplayResult.trades` guarantees it)."""
    return [_position_to_journal_row(t) for t in trades]


def build_equity_curve_report(result: ReplayResult) -> dict:
    return {
        "starting_balance": result.starting_balance,
        "ending_balance": result.ending_balance,
        "points": [{"timestamp": ts.isoformat(), "equity": eq} for ts, eq in result.equity_curve],
    }


def build_drawdown_report(result: ReplayResult) -> dict:
    """Derives a running drawdown series directly from the equity
    curve already produced by the replay — no separate computation
    path that could disagree with `metrics.max_drawdown_*`."""
    points = []
    peak = result.starting_balance
    for ts, equity in result.equity_curve:
        peak = max(peak, equity)
        drawdown_abs = peak - equity
        drawdown_pct = (drawdown_abs / peak * 100.0) if peak > 0 else 0.0
        points.append({"timestamp": ts.isoformat(), "drawdown_absolute": drawdown_abs, "drawdown_percent": drawdown_pct})
    return {"points": points}


def _period_key(ts: datetime, *, monthly: bool) -> str:
    return ts.strftime("%Y-%m") if monthly else f"{ts.isocalendar().year}-W{ts.isocalendar().week:02d}"


def build_periodic_performance_report(trades: list[TradeRecord], *, monthly: bool) -> list[dict]:
    """Item 7: weekly/monthly performance. Buckets CLOSED trades by
    their close time into calendar weeks (ISO week) or months."""
    buckets: dict[str, list[TradeRecord]] = {}
    for t in trades:
        if t.position.closed_at is None:
            continue
        key = _period_key(t.position.closed_at, monthly=monthly)
        buckets.setdefault(key, []).append(t)

    rows = []
    for key in sorted(buckets.keys()):
        m = compute_performance_metrics(buckets[key])
        rows.append({"period": key, **asdict(m)})
    return rows


def build_symbol_performance_report(results: dict[str, ReplayResult]) -> list[dict]:
    return [{"symbol": b.symbol, **asdict(b.metrics)} for b in compute_per_symbol_metrics(results)]


def build_regime_performance_report(results: dict[str, ReplayResult]) -> list[dict]:
    """Item 3 + item 7: guarantees all seven required regime buckets
    appear even with zero trades (see `metrics.compute_per_regime_metrics`),
    so the report is explicit about coverage gaps rather than omitting
    regimes this run happened not to encounter."""
    rows = [{"regime": b.regime, **asdict(b.metrics)} for b in compute_per_regime_metrics(results)]
    rows.sort(key=lambda r: ALL_REGIME_KEYS.index(r["regime"]) if r["regime"] in ALL_REGIME_KEYS else 999)
    return rows


def build_signal_quality_report(
    *, signal_log: list, risk_events: list, trades: list[TradeRecord]
) -> dict:
    quality = compute_signal_quality(signal_log=signal_log, risk_events=risk_events, trades=trades)
    calibration = confidence_calibration(trades)
    factors = compute_factor_contribution(signal_log, trades)
    return {
        "confidence_disclaimer": CONFIDENCE_DISCLAIMER,
        "summary": asdict(quality),
        "confidence_calibration": [asdict(b) for b in calibration],
        "factor_contribution": [asdict(f) for f in factors],
    }


def build_risk_rejections_report(risk_events: list) -> dict:
    rejections = [e for e in risk_events if e.get("event_type") == "RISK_BLOCK"]
    by_reason: dict[str, int] = {}
    for e in rejections:
        for reason in e.get("payload", {}).get("reasons", []):
            by_reason[reason] = by_reason.get(reason, 0) + 1
    return {
        "total_rejections": len(rejections),
        "by_reason": by_reason,
        "events": [
            {"symbol": e.get("symbol"), "reasons": e.get("payload", {}).get("reasons", []), "at": e.get("created_at")}
            for e in rejections
        ],
    }


@dataclass
class OverallBacktestReport:
    """The single top-level report object the API layer serializes —
    everything item 7 asks for, assembled from one `ReplayResult` (or
    the merged multi-symbol equivalent)."""

    performance: PerformanceMetrics
    equity_curve: dict
    drawdown: dict
    weekly_performance: list[dict]
    monthly_performance: list[dict]
    symbol_performance: list[dict]
    regime_performance: list[dict]
    signal_quality: dict
    risk_rejections: dict
    trade_journal: list[dict]
    real_data_used: bool
    data_provenance: str
    disclaimers: list[str] = field(default_factory=list)


def build_overall_report(
    *,
    merged_result: ReplayResult,
    per_symbol_results: dict[str, ReplayResult],
    data_provenance: str,
) -> OverallBacktestReport:
    disclaimers = [NO_LIVE_TRADING_DISCLAIMER, CONFIDENCE_DISCLAIMER]
    if not merged_result.real_data_used:
        disclaimers.insert(0, REAL_DATA_DISCLAIMER)

    return OverallBacktestReport(
        performance=compute_performance_metrics(merged_result.trades),
        equity_curve=build_equity_curve_report(merged_result),
        drawdown=build_drawdown_report(merged_result),
        weekly_performance=build_periodic_performance_report(merged_result.trades, monthly=False),
        monthly_performance=build_periodic_performance_report(merged_result.trades, monthly=True),
        symbol_performance=build_symbol_performance_report(per_symbol_results),
        regime_performance=build_regime_performance_report(per_symbol_results),
        signal_quality=build_signal_quality_report(
            signal_log=merged_result.signal_log, risk_events=merged_result.risk_events, trades=merged_result.trades,
        ),
        risk_rejections=build_risk_rejections_report(merged_result.risk_events),
        trade_journal=build_trade_journal(merged_result.trades),
        real_data_used=merged_result.real_data_used,
        data_provenance=data_provenance,
        disclaimers=disclaimers,
    )


@dataclass
class FinalOosReport:
    """Item 7's explicitly-named "final OOS report" — kept as its own
    top-level object (not just another row in a table) so it can never
    be casually confused with a walk-forward TEST-window result. Only
    ever populated from `WalkForwardReport.oos_result`, and always
    carries `oos_still_untouched` front and center."""

    oos_still_untouched: bool
    tuning_log: list[str]
    parameter_set_label: str
    parameter_set_hash: str
    performance: PerformanceMetrics
    equity_curve: dict
    trade_journal: list[dict]
    overfitting_warnings: list[str]
    real_data_used: bool
    disclaimers: list[str] = field(default_factory=list)


def build_final_oos_report(walk_forward_report: WalkForwardReport) -> FinalOosReport | None:
    if walk_forward_report.oos_result is None:
        return None
    oos = walk_forward_report.oos_result
    disclaimers = [NO_LIVE_TRADING_DISCLAIMER, CONFIDENCE_DISCLAIMER]
    if not oos.real_data_used:
        disclaimers.insert(0, REAL_DATA_DISCLAIMER)
    if not walk_forward_report.oos_still_untouched:
        disclaimers.insert(
            0,
            "WARNING: parameters were adjusted based on validation/test results during this "
            "report's development — this OOS result is NOT an untouched out-of-sample "
            "validation and must not be presented as one.",
        )

    return FinalOosReport(
        oos_still_untouched=walk_forward_report.oos_still_untouched,
        tuning_log=list(walk_forward_report.tuning_log),
        parameter_set_label=walk_forward_report.parameter_set.label,
        parameter_set_hash=walk_forward_report.parameter_set.content_hash,
        performance=compute_performance_metrics(oos.trades),
        equity_curve=build_equity_curve_report(oos),
        trade_journal=build_trade_journal(oos.trades),
        overfitting_warnings=detect_suspicious_overfitting(walk_forward_report),
        real_data_used=oos.real_data_used,
        disclaimers=disclaimers,
    )
