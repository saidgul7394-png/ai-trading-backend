import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .api.routers import (
    auth_router,
    auto_trading_router,
    backtest_router,
    binance_router,
    market_router,
    news_router,
    notifications_router,
    paper_trading_router,
    portfolio_router,
    risk_router,
    signals_router,
    trades_router,
    ws_router,
)
from .core.config import cors_origins_list, get_settings, settings_backend
from .paper_trading.config import DEFAULT_PAPER_CONFIG
from .paper_trading.db import Database
from .paper_trading.engine import PaperExecutionEngine
from .paper_trading.pipeline import DEFAULT_RISK_LIMITS, TradingPipeline
from .paper_trading.position_manager import PositionManager
from .paper_trading.repository import PaperTradingRepository
from .paper_trading.worker import BackgroundWorker
from .services.market_data.binance_client import BinanceRestClient
from .services.market_data.candle_store import CandleStore
from .services.market_data.models import DEFAULT_SYMBOLS, SUPPORTED_INTERVALS
from .services.market_data.rate_limiter import TokenBucketLimiter
from .services.market_data.service import MarketDataService
from .signal_engine.service import SignalGenerationService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("main")

settings = get_settings()

# Symbols the background worker actively trades. A subset of
# DEFAULT_SYMBOLS (which is the broader set the market-data layer keeps
# warm) — keeps the paper-trading loop's scope explicit and small while
# still giving BTC-trend confirmation "for free" as a market-data symbol.
WORKER_SYMBOLS = ("BTCUSDT", "ETHUSDT", "BNBUSDT")
WORKER_TIMEFRAME = "1h"
WORKER_INTERVAL_SECONDS = 30.0


@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- Startup: market data (Phase 2) ---
    base_url = settings.binance_testnet_base_url if settings.binance_use_testnet else settings.binance_api_base_url

    rest_client = BinanceRestClient(
        base_url=base_url,
        allowed_symbols=DEFAULT_SYMBOLS,
        limiter=TokenBucketLimiter(capacity=1200, refill_per_second=20.0),
    )
    candle_store = CandleStore()
    market_data_service = MarketDataService(
        rest_client=rest_client,
        candle_store=candle_store,
        symbols=DEFAULT_SYMBOLS,
        intervals=SUPPORTED_INTERVALS,
    )

    logger.info("Backfilling market data for %s across %s...", DEFAULT_SYMBOLS, SUPPORTED_INTERVALS)
    await market_data_service.bootstrap_all()
    market_data_service.start_live_stream()

    signal_service = SignalGenerationService(market_data=market_data_service)

    # --- Startup: paper trading (Phase 3) ---
    paper_db = Database(settings.paper_trading_db_path)
    paper_repository = PaperTradingRepository(paper_db)
    await paper_repository.get_or_create_account(starting_balance=DEFAULT_PAPER_CONFIG.starting_balance_usd)

    execution_engine = PaperExecutionEngine(repository=paper_repository, config=DEFAULT_PAPER_CONFIG)
    position_manager = PositionManager(
        repository=paper_repository, engine=execution_engine, config=DEFAULT_PAPER_CONFIG
    )
    trading_pipeline = TradingPipeline(
        signal_service=signal_service,
        market_data=market_data_service,
        repository=paper_repository,
        execution_engine=execution_engine,
        position_manager=position_manager,
        paper_config=DEFAULT_PAPER_CONFIG,
        risk_limits=DEFAULT_RISK_LIMITS,
    )
    background_worker = BackgroundWorker(
        pipeline=trading_pipeline,
        repository=paper_repository,
        symbols=WORKER_SYMBOLS,
        timeframe=WORKER_TIMEFRAME,
        interval_seconds=WORKER_INTERVAL_SECONDS,
    )

    open_positions = await paper_repository.get_open_positions()
    if open_positions:
        logger.info(
            "Recovered %d open paper position(s) from prior run: %s",
            len(open_positions), [p.symbol for p in open_positions],
        )

    background_worker.start()

    app.state.rest_client = rest_client
    app.state.market_data_service = market_data_service
    app.state.signal_service = signal_service
    app.state.paper_repository = paper_repository
    app.state.trading_pipeline = trading_pipeline
    app.state.background_worker = background_worker

    logger.info("Startup complete. settings_backend=%s", settings_backend())
    yield

    # --- Shutdown ---
    logger.info("Shutting down: stopping worker, live stream, and closing REST client...")
    await background_worker.stop()
    await market_data_service.stop_live_stream()
    await rest_client.close()


app = FastAPI(
    title="AI Trading Backend",
    description=(
        "Backend for the AI Trading Android app. Runs the AI signal engine, "
        "enforces risk limits, and runs a full paper-trading simulation loop "
        "against real market data. "
        "This backend NEVER holds, accepts, or stores Binance API credentials "
        "— those are entered and stored only on the user's own device (Android "
        "Keystore-backed local storage). Live (real-money) order placement is "
        "hard-disabled by default and is not implemented in this phase. "
        "See backend/README.md and backend/DEPLOYMENT.md for the full "
        "security and deployment model."
    ),
    version="0.5.0",
    lifespan=lifespan,
)

# CORS: the Android app talks to this backend directly over HTTPS, not
# from a browser origin, so production normally allows zero origins by
# default (see CORS_ALLOWED_ORIGINS in .env.example) — there is nothing
# for CORS to permit unless a browser-based client is added later. In
# development, localhost origins are allowed automatically so local
# web-based tooling (e.g. a local Swagger/docs client, a dev web
# build) keeps working without needing any .env changes.
_cors_origins = (
    ["http://localhost:3000", "http://127.0.0.1:3000"]
    if settings.environment == "development"
    else cors_origins_list()
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router.router)
app.include_router(binance_router.router)
app.include_router(signals_router.router)
app.include_router(trades_router.router)
app.include_router(risk_router.router)
app.include_router(auto_trading_router.router)
app.include_router(portfolio_router.router)
app.include_router(news_router.router)
app.include_router(market_router.router)
app.include_router(notifications_router.router)
app.include_router(paper_trading_router.router)
app.include_router(backtest_router.router)
app.include_router(ws_router.router)


@app.get("/health", tags=["health"])
async def health():
    """Liveness check: "is the process up and able to respond at
    all". Deliberately never fails just because a dependent subsystem
    (market data stream, worker) is degraded — a process manager
    (systemd) should not restart the process for a degraded worker,
    only for a genuinely dead one. Use /health/ready for a stricter
    check that reflects whether the app is actually doing its job."""
    market_data_service: MarketDataService | None = getattr(app.state, "market_data_service", None)
    background_worker: BackgroundWorker | None = getattr(app.state, "background_worker", None)
    return {
        "status": "ok",
        "environment": settings.environment,
        "settings_backend": settings_backend(),
        "live_trading_enabled": settings.live_trading_enabled,
        "market_data_stream_healthy": market_data_service.is_stream_healthy if market_data_service else False,
        "paper_trading_worker_running": background_worker.is_running if background_worker else False,
    }


@app.get("/health/ready", tags=["health"])
async def health_ready():
    """Readiness check: everything this backend needs to actually do
    its job must be true, or this returns a non-200 status (so a load
    balancer / uptime monitor can distinguish "process is up" from
    "process is actually working"). Checks:
      - the paper trading repository can be reached (SQLite file is
        openable and queryable)
      - the background worker task is running
      - the live market-data stream is healthy
    Never touches or reports on Binance credentials — this backend has
    none to check.
    """
    market_data_service: MarketDataService | None = getattr(app.state, "market_data_service", None)
    background_worker: BackgroundWorker | None = getattr(app.state, "background_worker", None)
    paper_repository: PaperTradingRepository | None = getattr(app.state, "paper_repository", None)

    checks = {
        "database_reachable": False,
        "market_data_stream_healthy": False,
        "paper_trading_worker_running": False,
    }

    if paper_repository is not None:
        try:
            await paper_repository.get_account()
            checks["database_reachable"] = True
        except Exception:  # noqa: BLE001 — any failure here means "not ready", not a 500
            checks["database_reachable"] = False

    if market_data_service is not None:
        checks["market_data_stream_healthy"] = market_data_service.is_stream_healthy
    if background_worker is not None:
        checks["paper_trading_worker_running"] = background_worker.is_running

    all_healthy = all(checks.values())
    body = {"status": "ready" if all_healthy else "not_ready", **checks}
    return JSONResponse(content=body, status_code=200 if all_healthy else 503)
