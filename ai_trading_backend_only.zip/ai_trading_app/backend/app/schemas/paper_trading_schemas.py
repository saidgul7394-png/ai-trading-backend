from datetime import datetime

from pydantic import BaseModel


class PaperAccountSchema(BaseModel):
    id: str
    starting_balance: float
    current_balance: float
    created_at: datetime


class PaperPositionSchema(BaseModel):
    id: str
    symbol: str
    side: str  # LONG | SHORT
    status: str  # OPEN | CLOSING | CLOSED
    entry_price: float
    quantity: float
    stop_loss: float
    take_profit: float
    trailing_stop_price: float | None = None
    trailing_stop_active: bool = False
    exit_price: float | None = None
    exit_reason: str | None = None
    realized_pnl: float | None = None
    unrealized_pnl: float | None = None
    unrealized_pnl_percent: float | None = None
    entry_fee: float
    exit_fee: float | None = None
    signal_id: str
    signal_confidence_at_entry: float
    opened_at: datetime
    closed_at: datetime | None = None
    max_holding_seconds: int | None = None


class TradeStatsSchema(BaseModel):
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate_percent: float
    total_realized_pnl: float
    avg_win: float
    avg_loss: float
    largest_win: float
    largest_loss: float


class PaperTradingDashboardResponse(BaseModel):
    account: PaperAccountSchema
    open_positions: list[PaperPositionSchema]
    stats: TradeStatsSchema
    worker_running: bool
    emergency_stop_active: bool
    last_worker_run_at: datetime | None = None


class EmergencyStopRequest(BaseModel):
    close_positions: bool = True


class EmergencyStopResponse(BaseModel):
    emergency_stop_active: bool
    closed_symbols: list[str]
