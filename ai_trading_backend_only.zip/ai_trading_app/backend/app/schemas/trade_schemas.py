from datetime import datetime

from pydantic import BaseModel


class TradeSchema(BaseModel):
    id: str
    binance_order_id: str
    symbol: str
    side: str
    status: str
    mode: str
    entry_price: float
    quantity: float
    stop_loss: float
    take_profit: float
    exit_price: float | None = None
    exit_reason: str = "none"
    unrealized_pnl: float
    unrealized_pnl_percent: float
    realized_pnl: float | None = None
    opened_at: datetime
    closed_at: datetime | None = None
    signal_id: str
    signal_confidence_at_entry: float


class RiskStatusSchema(BaseModel):
    circuit_breaker_tripped: bool
    emergency_stop_active: bool
    daily_loss_used_percent: float
    max_daily_loss_percent: float
    daily_trades_used: int
    max_daily_trades: int | None
    open_trades_count: int
    max_open_trades: int
    cooldown_active: bool
    cooldown_ends_at: datetime | None = None
    blocking_reasons: list[str] = []


class EmergencyStopRequest(BaseModel):
    close_open_positions: bool = True
