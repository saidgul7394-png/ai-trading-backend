"""Binance-related API schemas.

Phase 4.2: there is deliberately NO request schema anywhere in this
file (or this codebase) that accepts a Binance API key or secret. The
backend has no HTTP surface capable of receiving one — see
`api/routers/binance_router.py` and `services/binance_service.py` for
the full architecture note.

`BinanceConnectionStatusSchema` below describes only a PERMISSION
SUMMARY the user's own device may report for read-only display
purposes in some future phase (e.g. "trade-only key linked locally,
withdrawal disabled: true") — never the credential itself, and this
backend never persists it against a real Binance account since it
never authenticates as one.
"""

from datetime import datetime

from pydantic import BaseModel


class BinanceConnectionStatusSchema(BaseModel):
    """Informational only. `status` reflects whether the CLIENT DEVICE
    has reported a local key as configured — this backend has no way
    to verify that independently, since it never holds the key."""

    status: str  # not_configured_on_device | device_reports_configured
    has_trade_permission: bool | None = None
    has_withdrawal_permission: bool | None = None
    last_reported_at: datetime | None = None
