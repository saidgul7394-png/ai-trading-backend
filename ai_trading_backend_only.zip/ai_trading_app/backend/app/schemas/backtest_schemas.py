"""Pydantic response/request schemas for the backtesting API
(`api/routers/backtest_router.py`). Mirrors the field-level shape of
`backtesting.reports`/`backtesting.metrics`/`backtesting.walk_forward`
dataclasses — this file is the JSON contract the Flutter Backtesting
screen parses against.

Same environment caveat as Phase 2/3's other schema files: `pydantic`/
`fastapi` are not installed in this sandbox (no network egress to
pip-install them), so this file is syntax-checked and reviewed but not
execution-tested against a live server, identical to the existing
routers/schemas in this codebase.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class PerformanceMetricsSchema(BaseModel):
    total_trades: int
    winning_trades: int
    losing_trades: int
    breakeven_trades: int
    win_rate_percent: float
    profit_factor: float | None
    expectancy: float
    net_pnl: float
    gross_profit: float
    gross_loss: float
    average_win: float
    average_loss: float
    average_r_multiple: float | None
    max_drawdown_percent: float
    max_drawdown_absolute: float
    max_consecutive_wins: int
    max_consecutive_losses: int
    total_fees: float
    total_slippage: float
    long_trades: int
    short_trades: int
    long_win_rate_percent: float
    short_win_rate_percent: float
    long_net_pnl: float
    short_net_pnl: float
    average_mfe_percent: float
    average_mae_percent: float


class EquityCurvePointSchema(BaseModel):
    timestamp: str
    equity: float


class EquityCurveSchema(BaseModel):
    starting_balance: float
    ending_balance: float
    points: list[EquityCurvePointSchema]


class DrawdownPointSchema(BaseModel):
    timestamp: str
    drawdown_absolute: float
    drawdown_percent: float


class DrawdownReportSchema(BaseModel):
    points: list[DrawdownPointSchema]


class PeriodicPerformanceRowSchema(BaseModel):
    period: str
    # Remaining fields mirror PerformanceMetricsSchema, flattened —
    # kept as a permissive dict at the API boundary since the row is
    # produced by `asdict(PerformanceMetrics)` merged with `period`.
    model_config = {"extra": "allow"}


class SymbolPerformanceRowSchema(BaseModel):
    symbol: str
    model_config = {"extra": "allow"}


class RegimePerformanceRowSchema(BaseModel):
    regime: str
    model_config = {"extra": "allow"}


class ConfidenceBucketSchema(BaseModel):
    label: str
    low: float
    high: float
    trade_count: int
    observed_win_rate_percent: float | None
    average_pnl: float


class FactorContributionSchema(BaseModel):
    factor_name: str
    appearances: int
    average_leaning_when_directional: float
    appearances_in_winning_trades: int
    appearances_in_losing_trades: int


class SignalQualityReportSchema(BaseModel):
    confidence_disclaimer: str
    summary: dict
    confidence_calibration: list[ConfidenceBucketSchema]
    factor_contribution: list[FactorContributionSchema]


class RiskRejectionsReportSchema(BaseModel):
    total_rejections: int
    by_reason: dict[str, int]
    events: list[dict]


class TradeJournalRowSchema(BaseModel):
    position_id: str
    symbol: str
    side: str
    opened_at: str
    closed_at: str | None
    entry_price: float
    exit_price: float | None
    quantity: float
    stop_loss: float
    take_profit: float
    exit_reason: str | None
    realized_pnl: float | None
    entry_fee: float
    exit_fee: float | None
    signal_confidence_at_entry: float
    mfe_percent: float
    mae_percent: float
    regimes_at_entry: list[str]


class OverallBacktestReportSchema(BaseModel):
    performance: PerformanceMetricsSchema
    equity_curve: EquityCurveSchema
    drawdown: DrawdownReportSchema
    weekly_performance: list[dict]
    monthly_performance: list[dict]
    symbol_performance: list[dict]
    regime_performance: list[dict]
    signal_quality: SignalQualityReportSchema
    risk_rejections: RiskRejectionsReportSchema
    trade_journal: list[TradeJournalRowSchema]
    real_data_used: bool
    data_provenance: str
    disclaimers: list[str]


class FinalOosReportSchema(BaseModel):
    oos_still_untouched: bool
    tuning_log: list[str]
    parameter_set_label: str
    parameter_set_hash: str
    performance: PerformanceMetricsSchema
    equity_curve: EquityCurveSchema
    trade_journal: list[TradeJournalRowSchema]
    overfitting_warnings: list[str]
    real_data_used: bool
    disclaimers: list[str]


class BacktestRunRequest(BaseModel):
    symbols: list[str]
    primary_timeframe: str = "1h"
    start: datetime
    end: datetime
    run_walk_forward: bool = True
    train_candles: int = 400
    validation_candles: int = 150
    test_candles: int = 150
    oos_fraction: float = 0.2
    min_confidence: float = 0.65
    max_daily_loss_percent: float = 3.0
    max_risk_per_trade_percent: float = 1.0
    max_open_trades: int = 3
    starting_balance_usd: float = 10_000.0
    trade_amount_usd: float = 500.0


class BacktestRunResponse(BaseModel):
    data_provenance: str
    real_data_used: bool
    blocked_reasons: list[str]
    overall_report: OverallBacktestReportSchema | None
    final_oos_report: FinalOosReportSchema | None
    walk_forward_window_count: int
