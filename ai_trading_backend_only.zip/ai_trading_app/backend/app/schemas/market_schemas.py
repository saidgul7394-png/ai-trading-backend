from datetime import datetime

from pydantic import BaseModel


class CandleSchema(BaseModel):
    open_time: datetime
    close_time: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


class CandlesResponse(BaseModel):
    symbol: str
    interval: str
    candles: list[CandleSchema]
    freshness_seconds: int | None = None


class PriceResponse(BaseModel):
    symbol: str
    price: float


class OrderBookLevelSchema(BaseModel):
    price: float
    quantity: float


class OrderBookResponse(BaseModel):
    symbol: str
    bids: list[OrderBookLevelSchema]
    asks: list[OrderBookLevelSchema]
    mid_price: float | None = None
