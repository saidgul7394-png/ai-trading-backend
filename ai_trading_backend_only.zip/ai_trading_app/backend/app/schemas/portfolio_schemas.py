from datetime import datetime

from pydantic import BaseModel


class PortfolioSummarySchema(BaseModel):
    total_balance_usd: float
    available_balance_usd: float
    today_pnl_usd: float
    today_pnl_percent: float
    all_time_pnl_usd: float
    open_trades_count: int
    win_rate_percent: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    avg_risk_reward_ratio: float
    last_updated: datetime
