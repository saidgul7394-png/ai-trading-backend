from datetime import datetime

from pydantic import BaseModel


class SignalFactorSchema(BaseModel):
    name: str
    value: str
    weight: float
    leaning: float


class TradingSignalSchema(BaseModel):
    id: str
    symbol: str
    timeframe: str
    action: str  # BUY | SELL | HOLD
    confidence: float
    strength: str  # WEAK | MODERATE | STRONG
    entry_price: float
    stop_loss: float
    take_profit: float
    risk_reward_ratio: float
    reasons: list[str]
    contributing_factors: list[SignalFactorSchema]
    generated_at: datetime
    data_freshness_seconds: int
    eligible_for_auto_trade: bool
    rejection_reason: str | None = None


class LatestSignalsResponse(BaseModel):
    signals: list[TradingSignalSchema]
