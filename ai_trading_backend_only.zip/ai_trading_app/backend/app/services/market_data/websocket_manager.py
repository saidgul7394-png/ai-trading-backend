"""Live market data via Binance's public combined-stream WebSocket
(no API key required — this is public market data, same trust boundary
as the REST client).

Responsibilities:
  - subscribe to <symbol>@kline_<interval> streams for every configured
    symbol/interval pair
  - reconnect with capped exponential backoff on any disconnect
  - detect a stalled connection (no message within `stale_after_seconds`)
    and force a reconnect even if the socket looks technically open
  - drop malformed messages instead of forwarding them (never let a bad
    payload become a Candle)
  - hand each valid, CLOSED candle to a caller-supplied async callback
    (typically `CandleStore.upsert`)
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Awaitable, Callable

import websockets

from .models import Candle, MalformedDataError

logger = logging.getLogger("market_data.websocket")

CandleCallback = Callable[[Candle], Awaitable[None]]


class BinanceWebSocketManager:
    def __init__(
        self,
        *,
        streams: list[tuple[str, str]],  # [(symbol, interval), ...]
        on_candle: CandleCallback,
        base_url: str = "wss://stream.binance.com:9443",
        stale_after_seconds: int = 90,
        max_backoff_seconds: int = 60,
    ):
        self._streams = [(s.upper(), i) for s, i in streams]
        self._on_candle = on_candle
        self._base_url = base_url.rstrip("/")
        self._stale_after_seconds = stale_after_seconds
        self._max_backoff_seconds = max_backoff_seconds

        self._last_message_at: datetime | None = None
        self._running = False
        self._task: asyncio.Task | None = None

    def _combined_stream_url(self) -> str:
        parts = [f"{s.lower()}@kline_{i}" for s, i in self._streams]
        return f"{self._base_url}/stream?streams={'/'.join(parts)}"

    @property
    def is_stale(self) -> bool:
        if self._last_message_at is None:
            return True
        age = (datetime.now(timezone.utc) - self._last_message_at).total_seconds()
        return age > self._stale_after_seconds

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run_forever())

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()

    async def _run_forever(self) -> None:
        backoff = 1
        while self._running:
            try:
                await self._connect_and_listen()
                backoff = 1  # reset after a clean connect
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001 — any failure triggers reconnect
                logger.warning("WebSocket disconnected (%s); reconnecting in %ss", e, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, self._max_backoff_seconds)

    async def _connect_and_listen(self) -> None:
        url = self._combined_stream_url()
        async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
            logger.info("Connected to %s", url)
            while self._running:
                # Force-reconnect if the stream has gone quiet even though
                # the socket itself hasn't errored — protects against a
                # "silently stuck" connection feeding stale-looking data.
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=self._stale_after_seconds)
                except asyncio.TimeoutError:
                    raise ConnectionError("No messages received within stale-data window")

                self._last_message_at = datetime.now(timezone.utc)
                await self._handle_message(raw)

    async def _handle_message(self, raw: str) -> None:
        try:
            envelope = json.loads(raw)
            payload = envelope.get("data", envelope)
            if payload.get("e") != "kline":
                return
            k = payload["k"]
            if not k.get("x", False):
                # Candle not yet closed — Phase 2 only acts on closed
                # candles so every indicator sees a complete bar.
                return

            candle = Candle(
                symbol=payload["s"],
                interval=k["i"],
                open_time=datetime.fromtimestamp(k["t"] / 1000, tz=timezone.utc),
                close_time=datetime.fromtimestamp(k["T"] / 1000, tz=timezone.utc),
                open=float(k["o"]),
                high=float(k["h"]),
                low=float(k["l"]),
                close=float(k["c"]),
                volume=float(k["v"]),
                is_closed=True,
            )
        except (KeyError, ValueError, TypeError, json.JSONDecodeError, MalformedDataError) as e:
            logger.warning("Dropping malformed WebSocket message: %s", e)
            return

        await self._on_candle(candle)
