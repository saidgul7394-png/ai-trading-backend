"""Orchestrates the market-data layer for one running backend process:
  - REST backfill on startup (and on-demand for a symbol/timeframe the
    WebSocket hasn't populated yet)
  - owns the WebSocket manager(s) that keep the CandleStore current
  - exposes the read API the signal engine and market_router use

This is intentionally the ONLY module that wires binance_client +
websocket_manager + candle_store together, so there's one place that
understands "how fresh is fresh enough" and "what happens when a
symbol has a gap".
"""

from __future__ import annotations

import asyncio
import logging

from .binance_client import BinanceRestClient
from .candle_store import CandleStore
from .models import (
    Candle,
    DEFAULT_SYMBOLS,
    OrderBook,
    SUPPORTED_INTERVALS,
    StaleDataError,
)
from .websocket_manager import BinanceWebSocketManager

logger = logging.getLogger("market_data.service")

BACKFILL_CANDLE_COUNT = 300


class MarketDataService:
    def __init__(
        self,
        *,
        rest_client: BinanceRestClient,
        candle_store: CandleStore,
        symbols: tuple[str, ...] = DEFAULT_SYMBOLS,
        intervals: tuple[str, ...] = SUPPORTED_INTERVALS,
    ):
        self._rest = rest_client
        self._store = candle_store
        self._symbols = symbols
        self._intervals = intervals
        self._ws_manager: BinanceWebSocketManager | None = None

    async def bootstrap_all(self) -> None:
        """REST backfill for every configured symbol/interval pair
        before the WebSocket takes over. Failures for one pair are
        logged and skipped rather than aborting the whole startup —
        a single bad symbol shouldn't take the whole service down."""
        tasks = [
            self._bootstrap_one(symbol, interval)
            for symbol in self._symbols
            for interval in self._intervals
        ]
        await asyncio.gather(*tasks, return_exceptions=True)

    async def _bootstrap_one(self, symbol: str, interval: str) -> None:
        try:
            candles = await self._rest.get_klines(symbol, interval, limit=BACKFILL_CANDLE_COUNT)
            await self._store.bootstrap(symbol, interval, candles)
            logger.info("Backfilled %s %s (%d candles)", symbol, interval, len(candles))
        except Exception as e:  # noqa: BLE001
            logger.error("Backfill failed for %s %s: %s", symbol, interval, e)

    def start_live_stream(self) -> None:
        """Starts (or restarts) the combined WebSocket stream covering
        every configured symbol/interval pair."""
        streams = [(symbol, interval) for symbol in self._symbols for interval in self._intervals]
        self._ws_manager = BinanceWebSocketManager(streams=streams, on_candle=self._on_live_candle)
        self._ws_manager.start()

    async def stop_live_stream(self) -> None:
        if self._ws_manager:
            await self._ws_manager.stop()

    async def _on_live_candle(self, candle: Candle) -> None:
        await self._store.upsert(candle)

    @property
    def is_stream_healthy(self) -> bool:
        return self._ws_manager is not None and not self._ws_manager.is_stale

    @property
    def symbols(self) -> tuple[str, ...]:
        return self._symbols

    @property
    def intervals(self) -> tuple[str, ...]:
        return self._intervals

    async def get_candles(self, symbol: str, interval: str, *, limit: int | None = None) -> list[Candle]:
        return await self._store.get_candles(symbol, interval, limit=limit)

    async def get_candles_multi_timeframe(
        self, symbol: str, intervals: tuple[str, ...]
    ) -> dict[str, list[Candle]]:
        results = await asyncio.gather(*[self._store.get_candles(symbol, i) for i in intervals])
        return dict(zip(intervals, results))

    async def freshness_seconds(self, symbol: str, interval: str) -> int | None:
        return await self._store.freshness_seconds(symbol, interval)

    async def ensure_fresh_or_backfill(self, symbol: str, interval: str) -> None:
        """Called before serving a signal request: if the cached series
        is stale (WebSocket dropped, gap, etc.), attempt one REST
        backfill before giving up and letting the caller treat the data
        as stale."""
        try:
            await self._store.assert_fresh(symbol, interval)
        except StaleDataError:
            logger.warning("%s %s stale — attempting REST backfill", symbol, interval)
            await self._bootstrap_one(symbol, interval)
            # Re-check; if still stale after a fresh backfill attempt,
            # the caller (signal engine) will correctly fall back to HOLD.
            await self._store.assert_fresh(symbol, interval)

    async def get_order_book(self, symbol: str, *, depth: int = 20) -> OrderBook:
        # Order book isn't cached/streamed in Phase 2 — fetched fresh
        # per request since imbalance is only meaningful in the moment.
        return await self._rest.get_order_book(symbol, depth=depth)

    async def get_price(self, symbol: str) -> float:
        # Live tick price, fetched directly rather than derived from the
        # last closed candle — callers want "right now", not "as of the
        # last candle close".
        return await self._rest.get_price(symbol)
