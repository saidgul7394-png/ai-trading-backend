"""Core market-data value objects shared by the REST client, the
WebSocket manager, the candle store, and the indicator/signal engine.

Kept dependency-free (stdlib only) so indicator math stays deterministic
and testable without a running exchange connection.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

SUPPORTED_INTERVALS = ("1m", "5m", "15m", "1h", "4h", "1d")

# Binance interval string -> seconds, used for staleness checks and gap
# detection (a missing candle is a data-quality problem, not just a
# staleness problem).
INTERVAL_SECONDS: dict[str, int] = {
    "1m": 60,
    "5m": 5 * 60,
    "15m": 15 * 60,
    "1h": 60 * 60,
    "4h": 4 * 60 * 60,
    "1d": 24 * 60 * 60,
}

DEFAULT_SYMBOLS = ("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT")


class MarketDataError(Exception):
    """Base class for all market-data layer errors."""


class MalformedDataError(MarketDataError):
    """Raised when exchange data fails basic sanity checks (negative
    price, non-monotonic timestamps, NaN, high < low, etc.). Malformed
    data must never silently become a candle — better to drop the tick
    and keep the last-known-good state than to feed garbage to the
    signal engine."""


class StaleDataError(MarketDataError):
    """Raised when the most recent candle/tick is older than the
    configured staleness threshold for its timeframe."""


class InsufficientDataError(MarketDataError):
    """Raised when there are not enough candles to compute a requested
    indicator (e.g. asking for RSI(14) with 5 candles available)."""


class RateLimitError(MarketDataError):
    """Raised when the local rate limiter rejects a request before it
    would exceed Binance's request-weight budget."""


class UnsupportedSymbolError(MarketDataError):
    """Raised for a symbol outside the configured allow-list. Prevents
    silently fetching/trading a pair nobody vetted."""


class UnsupportedIntervalError(MarketDataError):
    """Raised for an interval outside SUPPORTED_INTERVALS."""


@dataclass(frozen=True)
class Candle:
    """One OHLCV candlestick. Immutable — indicator functions never
    mutate candles, only derive new values from them."""

    symbol: str
    interval: str
    open_time: datetime  # UTC, candle open
    close_time: datetime  # UTC, candle close
    open: float
    high: float
    low: float
    close: float
    volume: float
    is_closed: bool = True  # False for the currently-forming candle

    def __post_init__(self) -> None:
        # Basic sanity checks — raise immediately rather than let bad
        # data propagate silently into indicator math.
        if self.high < self.low:
            raise MalformedDataError(
                f"{self.symbol} {self.interval}: high ({self.high}) < low ({self.low})"
            )
        if not (self.low <= self.open <= self.high and self.low <= self.close <= self.high):
            raise MalformedDataError(
                f"{self.symbol} {self.interval}: open/close outside high/low range"
            )
        if self.open <= 0 or self.close <= 0 or self.high <= 0 or self.low <= 0:
            raise MalformedDataError(f"{self.symbol} {self.interval}: non-positive price")
        if self.volume < 0:
            raise MalformedDataError(f"{self.symbol} {self.interval}: negative volume")
        if self.close_time <= self.open_time:
            raise MalformedDataError(
                f"{self.symbol} {self.interval}: close_time <= open_time"
            )

    @property
    def typical_price(self) -> float:
        return (self.high + self.low + self.close) / 3.0

    @property
    def is_bullish(self) -> bool:
        return self.close > self.open

    @property
    def range(self) -> float:
        return self.high - self.low


@dataclass(frozen=True)
class OrderBookLevel:
    price: float
    quantity: float


@dataclass(frozen=True)
class OrderBook:
    symbol: str
    bids: tuple[OrderBookLevel, ...]  # best bid first
    asks: tuple[OrderBookLevel, ...]  # best ask first
    fetched_at: datetime

    @property
    def best_bid(self) -> float | None:
        return self.bids[0].price if self.bids else None

    @property
    def best_ask(self) -> float | None:
        return self.asks[0].price if self.asks else None

    @property
    def mid_price(self) -> float | None:
        if self.best_bid is None or self.best_ask is None:
            return None
        return (self.best_bid + self.best_ask) / 2.0


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def validate_symbol(symbol: str, allowed: tuple[str, ...] = DEFAULT_SYMBOLS) -> str:
    normalized = symbol.upper().strip()
    if normalized not in allowed:
        raise UnsupportedSymbolError(f"Symbol '{symbol}' is not in the allowed list: {allowed}")
    return normalized


def validate_interval(interval: str) -> str:
    if interval not in SUPPORTED_INTERVALS:
        raise UnsupportedIntervalError(
            f"Interval '{interval}' not supported. Use one of {SUPPORTED_INTERVALS}"
        )
    return interval
