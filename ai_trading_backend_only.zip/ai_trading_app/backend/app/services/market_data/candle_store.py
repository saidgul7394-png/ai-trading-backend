"""Central cache of recent candles per (symbol, interval), fed by both
the REST client (initial backfill) and the WebSocket manager (live
updates). Everything downstream — indicators, the signal engine, the
market REST router — reads through this store rather than hitting
Binance directly per-request.

This is intentionally a plain in-memory structure with an asyncio.Lock
for Phase 2 (single backend process). Multi-process deployments should
back this with Redis (same interface) in a later phase — noted so
nobody is surprised this doesn't survive a process restart yet.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from .models import Candle, INTERVAL_SECONDS, StaleDataError

MAX_CANDLES_PER_SERIES = 500


class CandleStore:
    def __init__(self, *, max_candles: int = MAX_CANDLES_PER_SERIES):
        self._max_candles = max_candles
        self._series: dict[tuple[str, str], list[Candle]] = {}
        self._lock = asyncio.Lock()

    def _key(self, symbol: str, interval: str) -> tuple[str, str]:
        return (symbol.upper(), interval)

    async def bootstrap(self, symbol: str, interval: str, candles: list[Candle]) -> None:
        """Seed a series from a REST backfill. Candles are sorted and
        de-duplicated by open_time."""
        async with self._lock:
            ordered = sorted(candles, key=lambda c: c.open_time)
            deduped: list[Candle] = []
            seen_times = set()
            for c in ordered:
                if c.open_time not in seen_times:
                    deduped.append(c)
                    seen_times.add(c.open_time)
            self._series[self._key(symbol, interval)] = deduped[-self._max_candles :]

    async def upsert(self, candle: Candle) -> None:
        """Append a new closed candle from the WebSocket stream,
        replacing any existing candle with the same open_time (handles
        the rare case of a duplicate/replayed message)."""
        async with self._lock:
            key = self._key(candle.symbol, candle.interval)
            series = self._series.setdefault(key, [])
            if series and series[-1].open_time == candle.open_time:
                series[-1] = candle
            else:
                series.append(candle)
            if len(series) > self._max_candles:
                del series[: len(series) - self._max_candles]

    async def get_candles(self, symbol: str, interval: str, *, limit: int | None = None) -> list[Candle]:
        async with self._lock:
            series = self._series.get(self._key(symbol, interval), [])
            return series[-limit:] if limit else list(series)

    async def freshness_seconds(self, symbol: str, interval: str) -> int | None:
        """Seconds since the most recent closed candle for this series.
        None if we have no data at all for this symbol/interval."""
        series = await self.get_candles(symbol, interval, limit=1)
        if not series:
            return None
        return int((datetime.now(timezone.utc) - series[-1].close_time).total_seconds())

    async def assert_fresh(self, symbol: str, interval: str, *, max_staleness_multiplier: float = 3.0) -> None:
        """Raises StaleDataError if the newest candle is older than
        `max_staleness_multiplier` intervals — e.g. for 1m candles, data
        older than 3 minutes is considered stale."""
        freshness = await self.freshness_seconds(symbol, interval)
        if freshness is None:
            raise StaleDataError(f"No data available for {symbol} {interval}")
        max_allowed = INTERVAL_SECONDS[interval] * max_staleness_multiplier
        if freshness > max_allowed:
            raise StaleDataError(
                f"{symbol} {interval} data is stale: {freshness}s old (max {int(max_allowed)}s)"
            )

    async def has_gap(self, symbol: str, interval: str) -> bool:
        """True if there's a missing candle between the two most recent
        entries — a sign the WebSocket dropped a message and a REST
        backfill should run before this series is trusted again."""
        series = await self.get_candles(symbol, interval, limit=2)
        if len(series) < 2:
            return False
        expected_gap = INTERVAL_SECONDS[interval]
        actual_gap = (series[-1].open_time - series[-2].open_time).total_seconds()
        return actual_gap > expected_gap * 1.5
