"""Simple async token-bucket limiter.

Binance weights REST endpoints (klines ~= 1-2 weight, depth ~= 1-50
depending on limit param) and enforces a rolling budget per IP
(1200/min at time of writing, subject to change). Rather than hardcode
that number and drift out of sync with Binance's docs, this limiter is
configured with a budget the caller supplies — `services/binance_client.py`
sets it from `core/config.py` so it's one place to tune.

Fails closed: if the budget is exhausted, `acquire()` raises
RateLimitError immediately rather than silently blocking forever (a
caller may want to back off and retry, but never for an unbounded
duration invisible to the rest of the system).
"""

from __future__ import annotations

import asyncio
import time

from .models import RateLimitError


class TokenBucketLimiter:
    def __init__(self, *, capacity: int, refill_per_second: float):
        if capacity <= 0 or refill_per_second <= 0:
            raise ValueError("capacity and refill_per_second must be positive")
        self._capacity = capacity
        self._tokens = float(capacity)
        self._refill_per_second = refill_per_second
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self._capacity, self._tokens + elapsed * self._refill_per_second)
        self._last_refill = now

    async def acquire(self, weight: int = 1) -> None:
        async with self._lock:
            self._refill()
            if self._tokens < weight:
                raise RateLimitError(
                    f"Rate limit budget exhausted: need {weight}, have {self._tokens:.1f}"
                )
            self._tokens -= weight

    def available_tokens(self) -> float:
        self._refill()
        return self._tokens
