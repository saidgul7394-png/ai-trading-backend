"""Binance PUBLIC REST API client — market data only.

Every method here hits a public, unauthenticated Binance endpoint
(klines, ticker/price, depth). No API key/secret is used or accepted
anywhere in this module — that's `services/binance_service.py`'s job,
kept entirely separate so market-data code can never accidentally touch
account/order endpoints.

Handles, per the Phase 2 requirements:
  - rate limits         -> TokenBucketLimiter, raises RateLimitError
  - malformed data       -> Candle.__post_init__ validation, raises MalformedDataError
  - connection failures  -> retried with capped exponential backoff, then
                            raises the underlying error (caller decides
                            whether to serve stale cached data or fail)
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import httpx

from .models import (
    Candle,
    INTERVAL_SECONDS,
    OrderBook,
    OrderBookLevel,
    validate_interval,
    validate_symbol,
)
from .rate_limiter import TokenBucketLimiter


class BinanceRestClient:
    def __init__(
        self,
        *,
        base_url: str = "https://api.binance.com",
        allowed_symbols: tuple[str, ...] | None = None,
        limiter: TokenBucketLimiter | None = None,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int = 3,
        request_timeout_seconds: float = 10.0,
    ):
        self._base_url = base_url.rstrip("/")
        self._allowed_symbols = allowed_symbols
        self._limiter = limiter or TokenBucketLimiter(capacity=1200, refill_per_second=20.0)
        self._client = http_client or httpx.AsyncClient(timeout=request_timeout_seconds)
        self._max_retries = max_retries

    async def close(self) -> None:
        await self._client.aclose()

    def _validate_symbol(self, symbol: str) -> str:
        if self._allowed_symbols is not None:
            return validate_symbol(symbol, self._allowed_symbols)
        return symbol.upper().strip()

    async def _get(self, path: str, params: dict, *, weight: int = 1) -> object:
        await self._limiter.acquire(weight)

        last_error: Exception | None = None
        for attempt in range(self._max_retries):
            try:
                response = await self._client.get(f"{self._base_url}{path}", params=params)
                if response.status_code == 429 or response.status_code == 418:
                    # Binance's own rate-limit / IP-ban signal — back off hard.
                    retry_after = float(response.headers.get("Retry-After", 2 ** attempt))
                    await asyncio.sleep(retry_after)
                    last_error = ConnectionError(f"Binance rate limited (HTTP {response.status_code})")
                    continue
                response.raise_for_status()
                return response.json()
            except (httpx.TransportError, httpx.HTTPStatusError) as e:
                last_error = e
                await asyncio.sleep(min(2 ** attempt, 8) * 0.25)

        assert last_error is not None
        raise ConnectionError(f"Binance request failed after {self._max_retries} attempts: {last_error}")

    async def get_klines(
        self, symbol: str, interval: str, *, limit: int = 200
    ) -> list[Candle]:
        symbol = self._validate_symbol(symbol)
        interval = validate_interval(interval)
        limit = max(1, min(limit, 1000))  # Binance caps at 1000

        raw = await self._get(
            "/api/v3/klines",
            {"symbol": symbol, "interval": interval, "limit": limit},
            weight=2,
        )
        return [self._parse_kline(symbol, interval, row) for row in raw]

    @staticmethod
    def _parse_kline(symbol: str, interval: str, row: list) -> Candle:
        # Binance kline row shape:
        # [ open_time, open, high, low, close, volume, close_time, ... ]
        # Raises MalformedDataError via Candle.__post_init__ on bad values —
        # deliberately NOT caught here, so a malformed candle never
        # silently becomes part of a returned list.
        return Candle(
            symbol=symbol,
            interval=interval,
            open_time=datetime.fromtimestamp(row[0] / 1000, tz=timezone.utc),
            close_time=datetime.fromtimestamp(row[6] / 1000, tz=timezone.utc),
            open=float(row[1]),
            high=float(row[2]),
            low=float(row[3]),
            close=float(row[4]),
            volume=float(row[5]),
            is_closed=True,
        )

    async def get_price(self, symbol: str) -> float:
        symbol = self._validate_symbol(symbol)
        raw = await self._get("/api/v3/ticker/price", {"symbol": symbol}, weight=1)
        price = float(raw["price"])
        if price <= 0:
            raise ValueError(f"Malformed price for {symbol}: {price}")
        return price

    async def get_order_book(self, symbol: str, *, depth: int = 20) -> OrderBook:
        symbol = self._validate_symbol(symbol)
        depth = depth if depth in (5, 10, 20, 50, 100, 500, 1000, 5000) else 20
        raw = await self._get(
            "/api/v3/depth", {"symbol": symbol, "limit": depth}, weight=1 if depth <= 100 else 5
        )
        bids = tuple(OrderBookLevel(price=float(p), quantity=float(q)) for p, q in raw["bids"])
        asks = tuple(OrderBookLevel(price=float(p), quantity=float(q)) for p, q in raw["asks"])
        return OrderBook(symbol=symbol, bids=bids, asks=asks, fetched_at=datetime.now(timezone.utc))

    def expected_interval_seconds(self, interval: str) -> int:
        return INTERVAL_SECONDS[validate_interval(interval)]
