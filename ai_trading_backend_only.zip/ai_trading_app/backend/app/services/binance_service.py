"""Binance integration service.

CREDENTIAL ARCHITECTURE (Phase 4.2 — read before touching this file):
This backend server NEVER accepts, receives, stores, logs, or holds a
Binance API key or secret, in any form, at any layer. There is no
constructor parameter, HTTP endpoint, request schema, or database
column anywhere in this codebase for a server-held Binance credential
— that surface was deliberately removed. See `binance_router.py` and
`models/binance_link.py`'s removal notes for what used to exist here
in earlier phases and why it was taken out.

WHAT THIS SERVICE DOES TODAY: calls Binance's UNAUTHENTICATED PUBLIC
market-data endpoints only (klines/candles, exchange info, symbol
filters) — the same public REST surface
`services/market_data/binance_client.py` already uses for live price
data and `backtesting/historical_data.py` uses for historical data.
No method on this class requires or accepts an API key.

WHAT THIS SERVICE DOES NOT DO: place orders, fetch account balances,
fetch account permissions, or anything else requiring an authenticated
(signed) Binance request. Every such method below is an explicit,
documented, `NotImplementedError`-raising placeholder for a FUTURE
architecture where:
  1. The API key/secret are entered and stored ONLY on the user's own
     device (Flutter `flutter_secure_storage`, OS Keystore/Keychain-
     backed at-rest encryption) — see
     `lib/features/binance_connect/`.
  2. Authenticated requests (including the HMAC signature, which
     requires the secret) are constructed and sent DIRECTLY from the
     device to Binance — never proxied through, or even transiently
     held by, this backend server.
  3. This backend, at most, receives a permission SUMMARY the device
     computed locally (e.g. "trade-only, spot, withdrawal disabled:
     true") for read-only display/audit purposes — never the
     credential itself.
  4. `core.config.get_settings().live_trading_enabled` (hard-disabled
     by default, server-operator-only, no remote code path to enable
     it — see `trading_orchestrator.py`) gates whether any of this
     matters at all; it remains False in every phase up to and
     including this one.

Until that device-signed architecture is actually built, every
authenticated method below stays exactly what it is: unimplemented.
"""

from __future__ import annotations

from dataclasses import dataclass


class BinancePermissionError(Exception):
    """Raised when a linked key has disallowed permissions (e.g.
    withdrawal enabled) or lacks required trading permission. Kept for
    the future device-side permission-check flow (the same safety
    rule — no withdrawal permission, trade permission required — will
    apply there too, just evaluated from a device-computed summary
    instead of a server-held key)."""


@dataclass
class BinanceAccountPermissions:
    can_trade: bool
    can_withdraw: bool
    can_deposit: bool


@dataclass
class OrderRequest:
    symbol: str
    side: str  # BUY | SELL
    quantity: float
    order_type: str = "MARKET"
    stop_loss: float | None = None
    take_profit: float | None = None
    client_order_id: str | None = None


@dataclass
class OrderResult:
    binance_order_id: str
    status: str
    filled_price: float
    filled_quantity: float


class BinanceService:
    """No constructor parameter here ever accepts an API key or
    secret — this class only wraps Binance's public, unauthenticated
    endpoints. See module docstring for why authenticated methods
    below remain unimplemented rather than accepting credentials to
    implement them here."""

    def __init__(self, *, use_testnet: bool):
        self._use_testnet = use_testnet

    async def fetch_account_permissions(self) -> BinanceAccountPermissions:
        """Would require an authenticated (signed) request to
        /sapi/v1/account/apiRestrictions — that signing must happen on
        the user's own device with their locally-held secret, never
        here. See module docstring, architecture point 2."""
        raise NotImplementedError(
            "Account permission checks require a signed Binance request using the user's "
            "secret. This backend never holds that secret — this call must be made from the "
            "user's own device in a future phase, not implemented server-side."
        )

    async def validate_key_is_safe_to_use(
        self, perms: BinanceAccountPermissions
    ) -> BinanceAccountPermissions:
        """Pure safety check over an ALREADY-COMPUTED permission
        summary (e.g. one the device fetched locally and is reporting
        for display/audit) — this method itself never touches a key or
        secret, only the boolean summary. Raises BinancePermissionError
        if the summary indicates an unsafe key. Kept as a pure function
        so the exact same safety rule is testable without any network
        or credential involved.
        """
        if perms.can_withdraw:
            raise BinancePermissionError(
                "This API key has withdrawal permission enabled. Please create a "
                "new key on Binance with ONLY 'Enable Spot & Margin Trading' "
                "checked, and withdrawal/transfer permissions left off."
            )
        if not perms.can_trade:
            raise BinancePermissionError(
                "This API key does not have trading permission enabled."
            )
        return perms

    async def get_balance_usd(self) -> float:
        raise NotImplementedError(
            "Balance queries require an authenticated Binance request — must be issued from "
            "the user's own device in a future phase, not implemented server-side."
        )

    async def get_symbol_filters(self, symbol: str) -> dict:
        """Lot size, min notional, price tick size, etc. — this ONE
        endpoint (GET /api/v3/exchangeInfo) IS public/unauthenticated,
        so it's safe to implement here; kept unimplemented only
        because it isn't needed yet (no live order path exists to
        consume it)."""
        raise NotImplementedError("Not yet implemented: GET /api/v3/exchangeInfo (public endpoint, cache per symbol).")

    async def place_order(self, order: OrderRequest) -> OrderResult:
        """Requires a signed request using the user's secret — must be
        issued from the user's own device in a future phase. This
        backend has no code path that can construct this request
        itself, by design. Additionally gated by
        `trading_orchestrator.TradingOrchestrator`'s hard
        `live_trading_enabled` kill switch, which defaults to False."""
        raise NotImplementedError(
            "Order placement requires a signed Binance request using the user's secret. This "
            "backend never holds that secret. Not implemented server-side by design."
        )

    async def get_open_orders(self, symbol: str | None = None) -> list[dict]:
        raise NotImplementedError(
            "Requires an authenticated Binance request — must be issued from the user's own "
            "device in a future phase, not implemented server-side."
        )

    async def cancel_order(self, symbol: str, binance_order_id: str) -> None:
        raise NotImplementedError(
            "Requires an authenticated Binance request — must be issued from the user's own "
            "device in a future phase, not implemented server-side."
        )
