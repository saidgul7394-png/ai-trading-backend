"""Trading orchestrator — the ONLY place where a signal can turn into a
real order. Enforces the pipeline order the whole system depends on:

    signal_engine  ->  risk_engine.evaluate_trade_proposal  ->  binance_service.place_order

Every rejection is written to the audit log with the exact reasons, so
"why didn't the AI trade that obvious setup" is always answerable.

HARD KILL SWITCH (Phase 4.2): `execute_if_approved` refuses to run
AT ALL unless `core.config.get_settings().live_trading_enabled` is
True. That flag defaults to False and is readable only from the
server operator's own environment at process startup — nothing in
this codebase (no HTTP request, no client payload, no other module)
can set it to True. This orchestrator is not currently instantiated
or wired into `main.py`, any router, or the worker; live order
execution remains fully disabled end-to-end.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.config import get_settings
from ..risk_engine.engine import RiskContext, evaluate_trade_proposal
from ..services.binance_service import BinanceService, OrderRequest


class LiveTradingDisabledError(Exception):
    """Raised whenever anything attempts to execute a real order while
    `live_trading_enabled` is False (the default). This is distinct
    from a risk-engine rejection — a risk rejection means "this
    specific trade is unsafe"; this means "no real trade of any kind
    is permitted right now, full stop"."""


@dataclass
class TradeProposal:
    user_id: str
    symbol: str
    action: str  # BUY | SELL
    signal_id: str
    signal_confidence: float
    entry_price: float
    stop_loss: float
    take_profit: float
    quantity: float
    proposed_risk_percent: float


class TradingOrchestrator:
    def __init__(self, binance_service: BinanceService):
        self._binance = binance_service

    async def execute_if_approved(
        self, proposal: TradeProposal, risk_context: RiskContext
    ) -> tuple[bool, list[str]]:
        """Returns (was_executed, reasons). reasons is populated on
        rejection, and always empty on success.

        Raises `LiveTradingDisabledError` before evaluating anything
        else if the hard kill switch is off — this check happens
        first, ahead of even the risk engine, so there is no code path
        where a risk-approved trade could slip through while live
        trading is meant to be disabled.
        """
        if not get_settings().live_trading_enabled:
            raise LiveTradingDisabledError(
                "Live trading is disabled (live_trading_enabled=False). No real order can be "
                "placed. This must be explicitly enabled by the server operator's own "
                "environment configuration — it cannot be turned on remotely."
            )

        check = evaluate_trade_proposal(risk_context)

        if not check.approved:
            await self._audit_reject(proposal, check.reasons)
            return False, check.reasons

        order = OrderRequest(
            symbol=proposal.symbol,
            side=proposal.action,
            quantity=proposal.quantity,
            stop_loss=proposal.stop_loss,
            take_profit=proposal.take_profit,
            client_order_id=f"sig-{proposal.signal_id}",
        )

        # NOTE: in paper-trading mode, this call is swapped for a
        # simulated fill inside paper_trading.engine — the orchestrator
        # logic and risk gate are identical either way. `binance_service`
        # itself has no code path that accepts or holds API credentials
        # server-side — see that module's docstring.
        result = await self._binance.place_order(order)

        await self._audit_execute(proposal, result.binance_order_id)
        return True, []

    async def _audit_reject(self, proposal: TradeProposal, reasons: list[str]) -> None:
        # Phase 2: write AuditLogEntry(event_type="risk_block", ...)
        pass

    async def _audit_execute(self, proposal: TradeProposal, binance_order_id: str) -> None:
        # Phase 2: write AuditLogEntry(event_type="trade_opened", ...)
        pass
