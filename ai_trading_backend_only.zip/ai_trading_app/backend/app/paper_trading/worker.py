"""Server-side background loop.

Every cycle: refresh signals for the watchlist (which internally
refreshes/validates market data via `MarketDataService`), let the
pipeline open new positions where warranted, and manage every open
position. One symbol failing (bad data, a transient market-data
exception, a WebSocket drop) is logged and skipped — it never aborts
the cycle for the other symbols, and it never crashes the loop itself.

Recovery model: the loop wraps EVERY cycle in a try/except. A cycle
that raises is recorded via `repository.record_worker_failure` and the
loop sleeps and retries on the next interval — it does not exit, does
not need external supervision to come back, and does not lose any
state (all position/account/signal state already lives in SQLite, not
in this object) if the process itself is restarted.
"""

from __future__ import annotations

import asyncio
import logging

from .pipeline import TradingPipeline
from .repository import PaperTradingRepository

logger = logging.getLogger("paper_trading.worker")


class BackgroundWorker:
    def __init__(
        self,
        *,
        pipeline: TradingPipeline,
        repository: PaperTradingRepository,
        symbols: tuple[str, ...],
        timeframe: str = "1h",
        interval_seconds: float = 30.0,
    ):
        self._pipeline = pipeline
        self._repo = repository
        self._symbols = symbols
        self._timeframe = timeframe
        self._interval_seconds = interval_seconds
        self._task: asyncio.Task | None = None
        self._running = False

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run_forever())

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _run_forever(self) -> None:
        while self._running:
            try:
                results = await self.run_once()
                if results.get("symbols_failed") or results.get("position_management_error"):
                    # The cycle completed (nothing crashed the loop) but
                    # part of it failed — record that as a failure for
                    # observability/alerting purposes, while still
                    # continuing to loop normally on the next interval.
                    summary = {
                        "symbols_failed": results.get("symbols_failed"),
                        "position_management_error": results.get("position_management_error"),
                    }
                    await self._repo.record_worker_failure(str(summary))
                else:
                    await self._repo.record_worker_success()
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001 — a cycle failure must never kill the loop
                logger.error("Worker cycle failed: %s", e, exc_info=True)
                await self._repo.record_worker_failure(str(e))

            await asyncio.sleep(self._interval_seconds)

    async def run_once(self) -> dict:
        """Runs exactly one full cycle. Exposed separately from
        `_run_forever` so tests (and a manual "refresh now" endpoint)
        can trigger a single deterministic cycle without dealing with
        the sleep loop."""
        emergency_stop = await self._repo.get_flag("emergency_stop_active")

        results = {"symbols_evaluated": [], "symbols_failed": [], "emergency_stop_active": emergency_stop}

        if not emergency_stop:
            for symbol in self._symbols:
                try:
                    signal = await self._pipeline.evaluate_symbol(symbol, self._timeframe)
                    results["symbols_evaluated"].append({"symbol": symbol, "action": signal.action})
                except Exception as e:  # noqa: BLE001 — isolate one bad symbol from the rest of the cycle
                    logger.error("Signal evaluation failed for %s: %s", symbol, e, exc_info=True)
                    results["symbols_failed"].append({"symbol": symbol, "error": str(e)})

        # Position management (SL/TP/trailing/max-holding-time) runs
        # every cycle regardless of emergency-stop state — emergency
        # stop blocks NEW trades, it doesn't stop the engine from
        # protecting positions that are already open (those get closed
        # explicitly via trigger_emergency_stop's close_positions flag,
        # not left unmanaged).
        try:
            await self._pipeline.manage_all_open_positions()
        except Exception as e:  # noqa: BLE001
            logger.error("Position management pass failed: %s", e, exc_info=True)
            results["position_management_error"] = str(e)

        return results

    @property
    def is_running(self) -> bool:
        return self._running and self._task is not None and not self._task.done()
