"""Configurable paper-trading parameters. Nothing in `engine.py` or
`position_manager.py` hardcodes a fee rate, slippage assumption, or
sizing rule — all of it flows through here, mirroring how
`signal_engine/config.py` centralizes the signal engine's knobs."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PaperTradingConfig:
    starting_balance_usd: float = 10_000.0

    # Fixed USD amount risked per trade (position sizing: quantity =
    # trade_amount_usd / entry_price, adjusted for simulated slippage).
    trade_amount_usd: float = 500.0

    # Simulated taker fee, matching a typical Binance spot taker rate.
    fee_rate: float = 0.001  # 0.1%

    # Simulated slippage as a fraction of price, applied against the
    # trader on both entry and exit (buy fills slightly higher, sell
    # fills slightly lower) — never in the trader's favor, since real
    # slippage rarely is.
    slippage_bps: float = 5.0  # 5 basis points = 0.05%

    # Trailing stop: once price has moved this % in the position's
    # favor, the trailing stop activates and then trails behind price
    # by `trailing_stop_distance_percent`.
    trailing_stop_activation_percent: float = 1.5
    trailing_stop_distance_percent: float = 1.0

    # Maximum time a position may stay open regardless of price action.
    # None = no time-based exit.
    max_holding_seconds: int | None = 24 * 60 * 60  # 24h default

    # How much the signal must reverse (opposite-direction confidence)
    # before an open position is closed early on signal reversal.
    early_exit_min_reversal_confidence: float = 0.5

    @property
    def slippage_fraction(self) -> float:
        return self.slippage_bps / 10_000.0


DEFAULT_PAPER_CONFIG = PaperTradingConfig()
