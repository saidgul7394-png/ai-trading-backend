"""Repository layer over `db.py`. Every method here is `async` (via
`run_db`/`asyncio.to_thread`) even though the underlying driver is
synchronous, so callers in `engine.py`, `position_manager.py`,
`pipeline.py`, and the FastAPI routers all use one consistent async
interface regardless of storage engine.

Idempotency and race-safety live here:
  - `open_position` uses a UNIQUE constraint on `client_order_id`
    (derived deterministically from the signal id) — a retried or
    duplicated open request is a no-op, not a second position.
  - `begin_close_position` does an atomic
    `UPDATE ... WHERE status = 'OPEN'` compare-and-swap into `CLOSING`
    before any P&L is computed or persisted, so two concurrent close
    attempts can never both "win".
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from .db import Database, dict_from_json, json_from_dict, run_db
from .models import (
    ExitReason,
    PaperAccount,
    PaperOrder,
    PaperPosition,
    PositionSide,
    PositionStatus,
    SignalLogEntry,
    TradeStats,
)

DEFAULT_ACCOUNT_ID = "default"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_dt(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value) if value else None


class PaperTradingRepository:
    def __init__(self, db: Database):
        self._db = db

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------

    async def get_or_create_account(
        self, *, starting_balance: float, account_id: str = DEFAULT_ACCOUNT_ID
    ) -> PaperAccount:
        def _op():
            row = self._db.query_one("SELECT * FROM paper_accounts WHERE id = ?", (account_id,))
            if row:
                return row
            self._db.execute(
                "INSERT INTO paper_accounts (id, starting_balance, current_balance, created_at) "
                "VALUES (?, ?, ?, ?)",
                (account_id, starting_balance, starting_balance, _now_iso()),
            )
            return self._db.query_one("SELECT * FROM paper_accounts WHERE id = ?", (account_id,))

        row = await run_db(_op)
        return _account_from_row(row)

    async def get_account(self, account_id: str = DEFAULT_ACCOUNT_ID) -> PaperAccount | None:
        row = await run_db(self._db.query_one, "SELECT * FROM paper_accounts WHERE id = ?", (account_id,))
        return _account_from_row(row) if row else None

    async def adjust_balance(self, delta: float, account_id: str = DEFAULT_ACCOUNT_ID) -> PaperAccount:
        def _op():
            self._db.execute(
                "UPDATE paper_accounts SET current_balance = current_balance + ? WHERE id = ?",
                (delta, account_id),
            )
            return self._db.query_one("SELECT * FROM paper_accounts WHERE id = ?", (account_id,))

        row = await run_db(_op)
        return _account_from_row(row)

    async def reset_account(self, starting_balance: float, account_id: str = DEFAULT_ACCOUNT_ID) -> PaperAccount:
        def _op():
            self._db.execute(
                "UPDATE paper_accounts SET starting_balance = ?, current_balance = ? WHERE id = ?",
                (starting_balance, starting_balance, account_id),
            )
            return self._db.query_one("SELECT * FROM paper_accounts WHERE id = ?", (account_id,))

        row = await run_db(_op)
        return _account_from_row(row)

    # ------------------------------------------------------------------
    # Positions
    # ------------------------------------------------------------------

    async def open_position(self, position: PaperPosition) -> PaperPosition | None:
        """Returns the created position, or None if a position with the
        same client_order_id already exists (idempotent no-op — this is
        the duplicate-trade guard at the persistence layer, on top of
        the signal-level and pipeline-level guards)."""

        def _op():
            existing = self._db.query_one(
                "SELECT id FROM paper_positions WHERE client_order_id = ?",
                (position.client_order_id,),
            )
            if existing:
                return None

            self._db.execute(
                """
                INSERT INTO paper_positions (
                    id, account_id, symbol, side, status, entry_price, quantity,
                    stop_loss, take_profit, trailing_stop_price, trailing_stop_active,
                    entry_fee, signal_id, signal_confidence_at_entry, opened_at,
                    max_holding_seconds, client_order_id
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    position.id,
                    position.account_id,
                    position.symbol,
                    position.side.value,
                    position.status.value,
                    position.entry_price,
                    position.quantity,
                    position.stop_loss,
                    position.take_profit,
                    position.trailing_stop_price,
                    int(position.trailing_stop_active),
                    position.entry_fee,
                    position.signal_id,
                    position.signal_confidence_at_entry,
                    position.opened_at.isoformat(),
                    position.max_holding_seconds,
                    position.client_order_id,
                ),
            )
            return self._db.query_one("SELECT * FROM paper_positions WHERE id = ?", (position.id,))

        row = await run_db(_op)
        return _position_from_row(row) if row else None

    async def begin_close_position(self, position_id: str) -> bool:
        """Atomic compare-and-swap: OPEN -> CLOSING. Returns True only
        for the caller that actually won the transition — this is what
        makes concurrent close attempts (e.g. TP hit at the same instant
        the worker's stale-check also tries to close it) safe without an
        explicit lock across processes."""
        rowcount = await run_db(
            self._db.execute_returning_rowcount,
            "UPDATE paper_positions SET status = ? WHERE id = ? AND status = ?",
            (PositionStatus.CLOSING.value, position_id, PositionStatus.OPEN.value),
        )
        return rowcount == 1

    async def finalize_close_position(
        self,
        position_id: str,
        *,
        exit_price: float,
        exit_reason: ExitReason,
        realized_pnl: float,
        exit_fee: float,
    ) -> PaperPosition:
        def _op():
            self._db.execute(
                """
                UPDATE paper_positions
                SET status = ?, exit_price = ?, exit_reason = ?, realized_pnl = ?,
                    exit_fee = ?, closed_at = ?
                WHERE id = ?
                """,
                (
                    PositionStatus.CLOSED.value,
                    exit_price,
                    exit_reason.value,
                    realized_pnl,
                    exit_fee,
                    _now_iso(),
                    position_id,
                ),
            )
            return self._db.query_one("SELECT * FROM paper_positions WHERE id = ?", (position_id,))

        row = await run_db(_op)
        return _position_from_row(row)

    async def revert_closing(self, position_id: str) -> None:
        """If finalize fails after begin_close_position succeeded (e.g.
        an exception mid-computation), revert CLOSING back to OPEN so
        the position isn't stuck in limbo and the next cycle can retry."""
        await run_db(
            self._db.execute,
            "UPDATE paper_positions SET status = ? WHERE id = ? AND status = ?",
            (PositionStatus.OPEN.value, position_id, PositionStatus.CLOSING.value),
        )

    async def update_trailing_stop(self, position_id: str, *, price: float, active: bool) -> None:
        await run_db(
            self._db.execute,
            "UPDATE paper_positions SET trailing_stop_price = ?, trailing_stop_active = ? WHERE id = ? AND status = ?",
            (price, int(active), position_id, PositionStatus.OPEN.value),
        )

    async def get_open_positions(self, account_id: str = DEFAULT_ACCOUNT_ID) -> list[PaperPosition]:
        rows = await run_db(
            self._db.query_all,
            "SELECT * FROM paper_positions WHERE account_id = ? AND status = ? ORDER BY opened_at",
            (account_id, PositionStatus.OPEN.value),
        )
        return [_position_from_row(r) for r in rows]

    async def get_open_position_for_symbol(
        self, symbol: str, account_id: str = DEFAULT_ACCOUNT_ID
    ) -> PaperPosition | None:
        row = await run_db(
            self._db.query_one,
            "SELECT * FROM paper_positions WHERE account_id = ? AND symbol = ? AND status IN (?, ?) LIMIT 1",
            (account_id, symbol, PositionStatus.OPEN.value, PositionStatus.CLOSING.value),
        )
        return _position_from_row(row) if row else None

    async def get_position(self, position_id: str) -> PaperPosition | None:
        row = await run_db(self._db.query_one, "SELECT * FROM paper_positions WHERE id = ?", (position_id,))
        return _position_from_row(row) if row else None

    async def get_trade_history(
        self, account_id: str = DEFAULT_ACCOUNT_ID, *, limit: int = 100
    ) -> list[PaperPosition]:
        rows = await run_db(
            self._db.query_all,
            "SELECT * FROM paper_positions WHERE account_id = ? AND status = ? "
            "ORDER BY closed_at DESC LIMIT ?",
            (account_id, PositionStatus.CLOSED.value, limit),
        )
        return [_position_from_row(r) for r in rows]

    async def get_trade_stats(self, account_id: str = DEFAULT_ACCOUNT_ID) -> TradeStats:
        rows = await run_db(
            self._db.query_all,
            "SELECT realized_pnl FROM paper_positions WHERE account_id = ? AND status = ?",
            (account_id, PositionStatus.CLOSED.value),
        )
        pnls = [r["realized_pnl"] for r in rows if r["realized_pnl"] is not None]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]
        total = len(pnls)
        return TradeStats(
            total_trades=total,
            winning_trades=len(wins),
            losing_trades=len(losses),
            win_rate_percent=(len(wins) / total * 100.0) if total else 0.0,
            total_realized_pnl=sum(pnls),
            avg_win=(sum(wins) / len(wins)) if wins else 0.0,
            avg_loss=(sum(losses) / len(losses)) if losses else 0.0,
            largest_win=max(wins) if wins else 0.0,
            largest_loss=min(losses) if losses else 0.0,
        )

    async def count_trades_opened_today(self, account_id: str = DEFAULT_ACCOUNT_ID) -> int:
        today = datetime.now(timezone.utc).date().isoformat()
        row = await run_db(
            self._db.query_one,
            "SELECT COUNT(*) AS n FROM paper_positions "
            "WHERE account_id = ? AND date(opened_at) = ?",
            (account_id, today),
        )
        return row["n"] if row else 0

    async def realized_loss_today_percent(self, account_id: str = DEFAULT_ACCOUNT_ID) -> float:
        """Sum of today's realized losses as a % of starting balance —
        what the risk engine's daily-loss gate checks against."""
        account = await self.get_account(account_id)
        if account is None or account.starting_balance <= 0:
            return 0.0
        today = datetime.now(timezone.utc).date().isoformat()
        row = await run_db(
            self._db.query_one,
            "SELECT COALESCE(SUM(realized_pnl), 0) AS total FROM paper_positions "
            "WHERE account_id = ? AND status = ? AND date(closed_at) = ? AND realized_pnl < 0",
            (account_id, PositionStatus.CLOSED.value, today),
        )
        total_loss = abs(row["total"]) if row else 0.0
        return (total_loss / account.starting_balance) * 100.0

    # ------------------------------------------------------------------
    # Orders (fill audit trail)
    # ------------------------------------------------------------------

    async def record_order(self, order: PaperOrder) -> None:
        await run_db(
            self._db.execute,
            """
            INSERT OR IGNORE INTO paper_orders (
                id, position_id, side, purpose, requested_price, filled_price,
                quantity, fee, slippage_amount, filled_at, client_order_id
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                order.id,
                order.position_id,
                order.side,
                order.purpose,
                order.requested_price,
                order.filled_price,
                order.quantity,
                order.fee,
                order.slippage_amount,
                order.filled_at.isoformat(),
                order.client_order_id,
            ),
        )

    async def get_orders_for_position(self, position_id: str) -> list[PaperOrder]:
        rows = await run_db(
            self._db.query_all,
            "SELECT * FROM paper_orders WHERE position_id = ? ORDER BY filled_at",
            (position_id,),
        )
        return [_order_from_row(r) for r in rows]

    # ------------------------------------------------------------------
    # Signal log
    # ------------------------------------------------------------------

    async def log_signal(self, entry: SignalLogEntry) -> None:
        await run_db(
            self._db.execute,
            """
            INSERT INTO signal_log (
                id, symbol, timeframe, action, confidence, eligible_for_auto_trade,
                rejection_reason, generated_at, factors_json
            ) VALUES (?,?,?,?,?,?,?,?,?)
            """,
            (
                entry.id,
                entry.symbol,
                entry.timeframe,
                entry.action,
                entry.confidence,
                int(entry.eligible_for_auto_trade),
                entry.rejection_reason,
                entry.generated_at.isoformat(),
                json_from_dict(entry.factors),
            ),
        )

    async def get_last_signal_action(self, symbol: str) -> str | None:
        row = await run_db(
            self._db.query_one,
            "SELECT action FROM signal_log WHERE symbol = ? ORDER BY generated_at DESC LIMIT 1",
            (symbol,),
        )
        return row["action"] if row else None

    # ------------------------------------------------------------------
    # Risk events (audit trail)
    # ------------------------------------------------------------------

    async def log_risk_event(self, event_type: str, *, symbol: str | None, payload: dict) -> None:
        await run_db(
            self._db.execute,
            "INSERT INTO risk_events (id, event_type, symbol, payload_json, created_at) VALUES (?,?,?,?,?)",
            (str(uuid.uuid4()), event_type, symbol, json_from_dict(payload), _now_iso()),
        )

    async def get_recent_risk_events(self, limit: int = 50) -> list[dict]:
        rows = await run_db(
            self._db.query_all,
            "SELECT * FROM risk_events ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [
            {
                "id": r["id"],
                "event_type": r["event_type"],
                "symbol": r["symbol"],
                "payload": dict_from_json(r["payload_json"]),
                "created_at": r["created_at"],
            }
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Risk state: emergency stop / circuit breaker (persisted, survives
    # restart — required by Phase 3 point 8)
    # ------------------------------------------------------------------

    async def set_flag(self, key: str, value: bool) -> None:
        await run_db(
            self._db.execute,
            "INSERT INTO risk_state (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
            (key, "1" if value else "0", _now_iso()),
        )

    async def get_flag(self, key: str) -> bool:
        row = await run_db(self._db.query_one, "SELECT value FROM risk_state WHERE key = ?", (key,))
        return row["value"] == "1" if row else False

    async def set_text(self, key: str, value: str | None) -> None:
        await run_db(
            self._db.execute,
            "INSERT INTO risk_state (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
            (key, value or "", _now_iso()),
        )

    async def get_text(self, key: str) -> str | None:
        row = await run_db(self._db.query_one, "SELECT value FROM risk_state WHERE key = ?", (key,))
        return row["value"] if row and row["value"] else None

    # ------------------------------------------------------------------
    # Per-symbol cooldown (persisted — the order-level cooldown, distinct
    # from signal_engine.protections' in-memory signal-level cooldown)
    # ------------------------------------------------------------------

    async def set_cooldown(self, symbol: str, *, action: str, until: datetime) -> None:
        await run_db(
            self._db.execute,
            "INSERT INTO symbol_cooldowns (symbol, last_signal_action, cooldown_until) VALUES (?, ?, ?) "
            "ON CONFLICT(symbol) DO UPDATE SET last_signal_action = excluded.last_signal_action, "
            "cooldown_until = excluded.cooldown_until",
            (symbol, action, until.isoformat()),
        )

    async def get_cooldown_until(self, symbol: str) -> datetime | None:
        row = await run_db(
            self._db.query_one, "SELECT cooldown_until FROM symbol_cooldowns WHERE symbol = ?", (symbol,)
        )
        return _parse_dt(row["cooldown_until"]) if row else None

    # ------------------------------------------------------------------
    # Worker heartbeat (used to prove/inspect restart & failure recovery)
    # ------------------------------------------------------------------

    async def record_worker_success(self) -> None:
        await run_db(
            self._db.execute,
            "UPDATE worker_heartbeat SET last_run_at = ?, last_error = NULL, "
            "consecutive_failures = 0, total_cycles = total_cycles + 1 WHERE id = 1",
            (_now_iso(),),
        )

    async def record_worker_failure(self, error: str) -> None:
        await run_db(
            self._db.execute,
            "UPDATE worker_heartbeat SET last_run_at = ?, last_error = ?, "
            "consecutive_failures = consecutive_failures + 1, total_cycles = total_cycles + 1 WHERE id = 1",
            (_now_iso(), error),
        )

    async def get_worker_heartbeat(self) -> dict:
        row = await run_db(self._db.query_one, "SELECT * FROM worker_heartbeat WHERE id = 1", ())
        return dict(row) if row else {}


def new_client_order_id(prefix: str, unique_key: str) -> str:
    """Deterministic order id derived from a stable key (e.g. signal id
    + symbol + side) so retrying the exact same trade proposal is a
    no-op at the DB layer via the UNIQUE constraint, rather than relying
    solely on in-process locks."""
    return f"{prefix}-{unique_key}"


# ---------------------------------------------------------------------------
# Row -> dataclass conversions
# ---------------------------------------------------------------------------


def _account_from_row(row) -> PaperAccount:
    return PaperAccount(
        id=row["id"],
        starting_balance=row["starting_balance"],
        current_balance=row["current_balance"],
        created_at=_parse_dt(row["created_at"]),
    )


def _position_from_row(row) -> PaperPosition:
    return PaperPosition(
        id=row["id"],
        account_id=row["account_id"],
        symbol=row["symbol"],
        side=PositionSide(row["side"]),
        status=PositionStatus(row["status"]),
        entry_price=row["entry_price"],
        quantity=row["quantity"],
        stop_loss=row["stop_loss"],
        take_profit=row["take_profit"],
        trailing_stop_price=row["trailing_stop_price"],
        trailing_stop_active=bool(row["trailing_stop_active"]),
        exit_price=row["exit_price"],
        exit_reason=ExitReason(row["exit_reason"]) if row["exit_reason"] else None,
        realized_pnl=row["realized_pnl"],
        entry_fee=row["entry_fee"],
        exit_fee=row["exit_fee"],
        signal_id=row["signal_id"],
        signal_confidence_at_entry=row["signal_confidence_at_entry"],
        opened_at=_parse_dt(row["opened_at"]),
        closed_at=_parse_dt(row["closed_at"]),
        max_holding_seconds=row["max_holding_seconds"],
        client_order_id=row["client_order_id"],
    )


def _order_from_row(row) -> PaperOrder:
    return PaperOrder(
        id=row["id"],
        position_id=row["position_id"],
        side=row["side"],
        purpose=row["purpose"],
        requested_price=row["requested_price"],
        filled_price=row["filled_price"],
        quantity=row["quantity"],
        fee=row["fee"],
        slippage_amount=row["slippage_amount"],
        filled_at=_parse_dt(row["filled_at"]),
        client_order_id=row["client_order_id"],
    )
