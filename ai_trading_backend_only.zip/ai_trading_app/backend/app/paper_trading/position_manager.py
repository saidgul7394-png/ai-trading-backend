"""Continuously evaluates every open paper position against the current
market price (and, for early exit, the latest signal) and decides
whether to close it. Never modifies position size — only ever fully
closes a position. No martingale, no averaging down: those words don't
appear anywhere in this module because there is no code path that adds
to an existing position.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone

from .config import PaperTradingConfig
from .engine import PaperExecutionEngine
from .models import ExitReason, PaperPosition, PositionSide
from .repository import PaperTradingRepository

logger = logging.getLogger("paper_trading.position_manager")


@dataclass(frozen=True)
class ExitDecision:
    should_exit: bool
    reason: ExitReason | None = None


def _hit_take_profit(position: PaperPosition, price: float) -> bool:
    if position.side == PositionSide.LONG:
        return price >= position.take_profit
    return price <= position.take_profit


def _hit_stop_loss(position: PaperPosition, price: float) -> bool:
    if position.side == PositionSide.LONG:
        return price <= position.stop_loss
    return price >= position.stop_loss


def _hit_max_holding_time(position: PaperPosition, now: datetime) -> bool:
    if position.max_holding_seconds is None:
        return False
    return position.holding_seconds(now) >= position.max_holding_seconds


def compute_trailing_stop(
    position: PaperPosition, price: float, config: PaperTradingConfig
) -> tuple[float | None, bool]:
    """Returns (new_trailing_stop_price, is_active). Pure function —
    kept separate from any DB write so it's directly unit-testable.

    Once price has moved `trailing_stop_activation_percent` in the
    position's favor, the trailing stop activates at
    `trailing_stop_distance_percent` behind the current price, and can
    only ever move in the position's favor from there (a LONG's
    trailing stop only ever rises; a SHORT's only ever falls) — it
    never gives back protection it already earned.
    """
    direction = 1.0 if position.side == PositionSide.LONG else -1.0
    favorable_move_percent = ((price - position.entry_price) / position.entry_price) * 100.0 * direction

    activation = config.trailing_stop_activation_percent
    distance = config.trailing_stop_distance_percent

    if not position.trailing_stop_active and favorable_move_percent < activation:
        return position.trailing_stop_price, False

    candidate = price * (1 - distance / 100.0 * direction)

    if position.trailing_stop_price is None:
        return candidate, True

    if position.side == PositionSide.LONG:
        new_stop = max(position.trailing_stop_price, candidate)
    else:
        new_stop = min(position.trailing_stop_price, candidate)

    return new_stop, True


def _hit_trailing_stop(position: PaperPosition, price: float) -> bool:
    if not position.trailing_stop_active or position.trailing_stop_price is None:
        return False
    if position.side == PositionSide.LONG:
        return price <= position.trailing_stop_price
    return price >= position.trailing_stop_price


def evaluate_exit(
    position: PaperPosition,
    *,
    current_price: float,
    now: datetime,
    reversal_signal_action: str | None,
    reversal_signal_confidence: float,
    config: PaperTradingConfig,
) -> ExitDecision:
    """Pure decision function — priority order matters: protective exits
    (stop loss, trailing stop) are checked before profit-taking, and
    both are checked before the softer signal-reversal / time-based
    exits, so a position is never left open past a hard risk boundary
    while waiting on a "nicer" exit reason to also become true.
    """
    if _hit_stop_loss(position, current_price):
        return ExitDecision(True, ExitReason.STOP_LOSS)

    if _hit_trailing_stop(position, current_price):
        return ExitDecision(True, ExitReason.TRAILING_STOP)

    if _hit_take_profit(position, current_price):
        return ExitDecision(True, ExitReason.TAKE_PROFIT)

    if _hit_max_holding_time(position, now):
        return ExitDecision(True, ExitReason.MAX_HOLDING_TIME)

    if reversal_signal_action is not None:
        opposite = "SELL" if position.side == PositionSide.LONG else "BUY"
        if (
            reversal_signal_action == opposite
            and reversal_signal_confidence >= config.early_exit_min_reversal_confidence
        ):
            return ExitDecision(True, ExitReason.EARLY_EXIT_SIGNAL_REVERSAL)

    return ExitDecision(False, None)


class PositionManager:
    def __init__(
        self,
        *,
        repository: PaperTradingRepository,
        engine: PaperExecutionEngine,
        config: PaperTradingConfig,
    ):
        self._repo = repository
        self._engine = engine
        self._config = config

    async def manage_position(
        self,
        position: PaperPosition,
        *,
        current_price: float,
        reversal_signal_action: str | None = None,
        reversal_signal_confidence: float = 0.0,
        now: datetime | None = None,
    ) -> PaperPosition | None:
        """Evaluates and, if warranted, closes one position. Returns the
        closed position, or None if it stayed open (or another caller
        already closed it in the same instant — see engine.close_position).
        """
        now = now or datetime.now(timezone.utc)

        new_stop, active = compute_trailing_stop(position, current_price, self._config)
        if active and new_stop != position.trailing_stop_price:
            await self._repo.update_trailing_stop(position.id, price=new_stop, active=True)
            position = PaperPosition(**{**position.__dict__, "trailing_stop_price": new_stop, "trailing_stop_active": True})

        decision = evaluate_exit(
            position,
            current_price=current_price,
            now=now,
            reversal_signal_action=reversal_signal_action,
            reversal_signal_confidence=reversal_signal_confidence,
            config=self._config,
        )

        if not decision.should_exit:
            return None

        closed = await self._engine.close_position(
            position, reference_price=current_price, exit_reason=decision.reason
        )
        if closed:
            logger.info(
                "Closed %s %s at %.4f (%s), realized_pnl=%.4f",
                position.symbol, position.side.value, closed.exit_price, decision.reason.value, closed.realized_pnl,
            )
            await self._repo.log_risk_event(
                "TRADE_CLOSED",
                symbol=position.symbol,
                payload={
                    "position_id": position.id,
                    "exit_reason": decision.reason.value,
                    "realized_pnl": closed.realized_pnl,
                    "exit_price": closed.exit_price,
                },
            )
        return closed

    async def emergency_close_all(self, *, current_prices: dict[str, float]) -> list[PaperPosition]:
        """Closes every open position immediately, regardless of
        SL/TP/trailing state. `current_prices` must contain a real
        market price for every open symbol — if a price is missing for
        some symbol, that position is skipped (never closed at a
        fabricated price) and logged so the caller can retry once data
        is available."""
        closed_positions: list[PaperPosition] = []
        open_positions = await self._repo.get_open_positions()

        for position in open_positions:
            price = current_prices.get(position.symbol)
            if price is None:
                logger.error(
                    "Emergency close: no current price for %s — position %s left open, retry needed",
                    position.symbol, position.id,
                )
                continue

            closed = await self._engine.close_position(
                position, reference_price=price, exit_reason=ExitReason.EMERGENCY_STOP
            )
            if closed:
                closed_positions.append(closed)
                await self._repo.log_risk_event(
                    "TRADE_CLOSED",
                    symbol=position.symbol,
                    payload={"position_id": position.id, "exit_reason": "EMERGENCY_STOP", "realized_pnl": closed.realized_pnl},
                )

        return closed_positions
