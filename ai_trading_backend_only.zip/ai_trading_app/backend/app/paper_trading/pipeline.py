"""The complete Phase 3 pipeline:

    Market Data -> Signal Engine -> Risk Engine -> Paper Execution -> Position Manager

This module is the only place that connects `signal_engine.service` to
`paper_trading.engine` — the same separation-of-concerns rule from
Phase 1's `trading_orchestrator.py` applies here: nothing produces a
signal and places an order in the same breath without the risk engine
in between, and there is still no import path anywhere in this
pipeline to `services/binance_service.py`. This is paper trading only.

Concurrency: `evaluate_symbol` takes a per-symbol `asyncio.Lock` for its
entire duration. Combined with the DB-level idempotency in
`repository.py` (unique `client_order_id`, atomic CLOSING compare-and-
swap), this is what makes "duplicate trades / duplicate exits /
concurrent execution races" actually impossible rather than just
unlikely: two overlapping calls for the same symbol (e.g. the
background worker's regular cycle and a manual "refresh now" request
racing each other) serialize on the lock, and even if the lock were
somehow bypassed, the DB layer would still reject the duplicate.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Callable, TYPE_CHECKING

from ..risk_engine.engine import RiskContext, evaluate_trade_proposal
from ..signal_engine.composite import CompositeSignal
from .config import PaperTradingConfig
from .engine import PaperExecutionEngine, PaperExecutionError
from .models import PositionSide, SignalLogEntry
from .position_manager import PositionManager
from .repository import DEFAULT_ACCOUNT_ID, PaperTradingRepository

if TYPE_CHECKING:
    from ..services.market_data.service import MarketDataService
    from ..signal_engine.service import SignalGenerationService

logger = logging.getLogger("paper_trading.pipeline")


class RiskLimits:
    """User-configurable risk limits for paper trading. Mirrors the
    shape of `settings/domain/entities/auto_trading_settings.dart` on
    the Flutter side — this is the server-side source of truth those
    settings map onto. Values are always clamped against
    `core.config.get_settings()`'s hard ceilings inside
    `evaluate_trade_proposal`, so nothing here can be raised past the
    platform maximum by a client request.
    """

    def __init__(
        self,
        *,
        min_confidence: float = 0.65,
        max_daily_loss_percent: float = 3.0,
        max_risk_per_trade_percent: float = 1.0,
        max_open_trades: int = 3,
        max_trades_per_day: int | None = None,
        cooldown_seconds: int = 300,
        max_data_staleness_seconds: int = 300,
    ):
        self.min_confidence = min_confidence
        self.max_daily_loss_percent = max_daily_loss_percent
        self.max_risk_per_trade_percent = max_risk_per_trade_percent
        self.max_open_trades = max_open_trades
        self.max_trades_per_day = max_trades_per_day
        self.cooldown_seconds = cooldown_seconds
        self.max_data_staleness_seconds = max_data_staleness_seconds


DEFAULT_RISK_LIMITS = RiskLimits()


class TradingPipeline:
    def __init__(
        self,
        *,
        signal_service: "SignalGenerationService",
        market_data: "MarketDataService",
        repository: PaperTradingRepository,
        execution_engine: PaperExecutionEngine,
        position_manager: PositionManager,
        paper_config: PaperTradingConfig,
        risk_limits: RiskLimits = DEFAULT_RISK_LIMITS,
        account_id: str = DEFAULT_ACCOUNT_ID,
        now_fn: Callable[[], datetime] | None = None,
    ):
        self._signals = signal_service
        self._market_data = market_data
        self._repo = repository
        self._execution = execution_engine
        self._positions = position_manager
        self._paper_config = paper_config
        self._risk_limits = risk_limits
        self._account_id = account_id
        self._symbol_locks: dict[str, asyncio.Lock] = {}
        # Defaults to the real wall clock — unchanged live/paper-trading
        # behavior. `backtesting.replay_engine` passes a
        # `SimulatedClock.now` here so cooldown timestamps and the risk
        # engine's cooldown check are judged against simulated
        # historical time instead of the real current time, which is
        # what makes a chronological replay's risk gate meaningful.
        self._now_fn: Callable[[], datetime] = now_fn or (lambda: datetime.now(timezone.utc))

    def _lock_for(self, symbol: str) -> asyncio.Lock:
        if symbol not in self._symbol_locks:
            self._symbol_locks[symbol] = asyncio.Lock()
        return self._symbol_locks[symbol]

    async def evaluate_symbol(self, symbol: str, timeframe: str = "1h") -> CompositeSignal:
        """Runs the full pipeline for one symbol: generate signal, log
        it, manage any existing open position (including early exit on
        reversal), and — only if every gate passes — open a new paper
        position. Always returns the signal that was generated (HOLD
        included) so callers/tests can inspect what happened even when
        no trade resulted.
        """
        async with self._lock_for(symbol):
            # apply_protections=False: this pipeline has its own
            # cooldown/duplicate protection (repository.set_cooldown,
            # applied only after a trade actually executes — see
            # _attempt_open) which is authoritative for trading
            # decisions. The signal engine's own cooldown is scoped to
            # signal *display* concerns and would otherwise incorrectly
            # suppress a retry after e.g. an emergency-stop rejection
            # that never actually placed a trade.
            signal = await self._signals.generate_signal(symbol, timeframe, apply_protections=False)

            await self._repo.log_signal(
                SignalLogEntry(
                    id=str(uuid.uuid4()),
                    symbol=signal.symbol,
                    timeframe=signal.timeframe,
                    action=signal.action,
                    confidence=signal.confidence,
                    eligible_for_auto_trade=signal.eligible_for_auto_trade,
                    rejection_reason=signal.rejection_reason,
                    generated_at=signal.generated_at,
                    factors=[f.__dict__ for f in signal.factors],
                )
            )

            # --- Manage any existing open position for this symbol first
            # (protective exits and reversal-based exits take priority
            # over opening anything new) ---
            existing = await self._repo.get_open_position_for_symbol(symbol, self._account_id)
            if existing and existing.status.value == "OPEN":
                await self._positions.manage_position(
                    existing,
                    current_price=signal.entry_price,
                    reversal_signal_action=signal.action if signal.action != "HOLD" else None,
                    reversal_signal_confidence=signal.confidence,
                )

            if signal.action == "HOLD":
                return signal

            # Re-check after position management above — if a position
            # is still open (or newly opened) for this symbol, don't
            # stack a second one on top of it.
            still_open = await self._repo.get_open_position_for_symbol(symbol, self._account_id)
            if still_open:
                return signal

            if not signal.eligible_for_auto_trade:
                return signal  # signal engine already explains why in rejection_reason

            await self._attempt_open(signal)
            return signal

    async def _attempt_open(self, signal: CompositeSignal) -> None:
        try:
            emergency_stop = await self._repo.get_flag("emergency_stop_active")
            circuit_breaker = await self._repo.get_flag("circuit_breaker_tripped")

            open_positions = await self._repo.get_open_positions(self._account_id)
            duplicate_open = any(p.symbol == signal.symbol for p in open_positions)

            daily_trades = await self._repo.count_trades_opened_today(self._account_id)
            daily_loss_percent = await self._repo.realized_loss_today_percent(self._account_id)

            cooldown_until = await self._repo.get_cooldown_until(signal.symbol)
            last_trade_at = None
            if cooldown_until is not None:
                last_trade_at = cooldown_until - timedelta(seconds=self._risk_limits.cooldown_seconds)

            account = await self._repo.get_account(self._account_id)
            proposed_risk_percent = 0.0
            if account and account.starting_balance:
                stop_distance = abs(signal.entry_price - signal.stop_loss)
                risk_amount = (stop_distance / signal.entry_price) * self._paper_config.trade_amount_usd
                proposed_risk_percent = (risk_amount / account.starting_balance) * 100.0

            ctx = RiskContext(
                user_min_confidence=self._risk_limits.min_confidence,
                user_max_daily_loss_percent=self._risk_limits.max_daily_loss_percent,
                user_max_risk_per_trade_percent=self._risk_limits.max_risk_per_trade_percent,
                user_max_open_trades=self._risk_limits.max_open_trades,
                user_max_trades_per_day=self._risk_limits.max_trades_per_day,
                current_daily_loss_percent=daily_loss_percent,
                current_daily_trades=daily_trades,
                current_open_trades=len(open_positions),
                last_trade_at=last_trade_at,
                cooldown_seconds=self._risk_limits.cooldown_seconds,
                circuit_breaker_tripped=circuit_breaker,
                emergency_stop_active=emergency_stop,
                signal_confidence=signal.confidence,
                signal_data_freshness_seconds=(
                    signal.data_freshness_seconds if signal.data_freshness_seconds is not None else 10**9
                ),
                max_allowed_data_staleness_seconds=self._risk_limits.max_data_staleness_seconds,
                proposed_risk_percent=proposed_risk_percent,
                duplicate_open_signal=duplicate_open,
            )

            check = evaluate_trade_proposal(ctx, now=self._now_fn())

            if not check.approved:
                logger.info("Risk engine rejected %s: %s", signal.symbol, check.reasons)
                await self._repo.log_risk_event(
                    "RISK_BLOCK", symbol=signal.symbol, payload={"reasons": check.reasons}
                )
                return

            side = PositionSide.LONG if signal.action == "BUY" else PositionSide.SHORT
            position = await self._execution.open_position(
                symbol=signal.symbol,
                side=side,
                reference_price=signal.entry_price,
                stop_loss=signal.stop_loss,
                take_profit=signal.take_profit,
                signal_id=f"{signal.symbol}-{signal.timeframe}-{int(signal.generated_at.timestamp())}",
                signal_confidence=signal.confidence,
                account_id=self._account_id,
            )

            if position is None:
                logger.info("Duplicate open for %s suppressed at the persistence layer", signal.symbol)
                return

            await self._repo.set_cooldown(
                signal.symbol,
                action=signal.action,
                until=self._now_fn() + timedelta(seconds=self._risk_limits.cooldown_seconds),
            )
            await self._repo.log_risk_event(
                "TRADE_OPENED",
                symbol=signal.symbol,
                payload={
                    "position_id": position.id,
                    "side": side.value,
                    "entry_price": position.entry_price,
                    "quantity": position.quantity,
                    "signal_confidence": signal.confidence,
                },
            )
            logger.info(
                "Opened paper %s %s @ %.4f (confidence=%.0f%%)",
                side.value, signal.symbol, position.entry_price, signal.confidence * 100,
            )

        except PaperExecutionError as e:
            logger.warning("Paper execution rejected %s: %s", signal.symbol, e)
            await self._repo.log_risk_event("RISK_BLOCK", symbol=signal.symbol, payload={"reasons": [str(e)]})

    async def manage_all_open_positions(self) -> None:
        """Re-checks every open position against its symbol's current
        market price, independent of whether a new signal was just
        generated for it — this is what the background worker calls
        every cycle so SL/TP/trailing-stop/max-holding-time exits fire
        even between signal refreshes."""
        open_positions = await self._repo.get_open_positions(self._account_id)
        for position in open_positions:
            async with self._lock_for(position.symbol):
                # Re-fetch inside the lock — another task may have
                # closed it between the snapshot above and now.
                current = await self._repo.get_position(position.id)
                if current is None or current.status.value != "OPEN":
                    continue
                try:
                    price = await self._market_data.get_price(position.symbol)
                except Exception as e:  # noqa: BLE001
                    logger.warning("Skipping position check for %s — price unavailable: %s", position.symbol, e)
                    continue
                await self._positions.manage_position(current, current_price=price)

    async def trigger_emergency_stop(self, *, close_positions: bool) -> list[str]:
        await self._repo.set_flag("emergency_stop_active", True)
        await self._repo.log_risk_event("EMERGENCY_STOP", symbol=None, payload={"close_positions": close_positions})

        closed_symbols: list[str] = []
        if close_positions:
            open_positions = await self._repo.get_open_positions(self._account_id)
            prices: dict[str, float] = {}
            for p in open_positions:
                try:
                    prices[p.symbol] = await self._market_data.get_price(p.symbol)
                except Exception as e:  # noqa: BLE001
                    logger.error("Emergency stop: could not fetch price for %s: %s", p.symbol, e)
            closed = await self._positions.emergency_close_all(current_prices=prices)
            closed_symbols = [c.symbol for c in closed]

        return closed_symbols

    async def clear_emergency_stop(self) -> None:
        await self._repo.set_flag("emergency_stop_active", False)
        await self._repo.log_risk_event("EMERGENCY_STOP_CLEARED", symbol=None, payload={})
