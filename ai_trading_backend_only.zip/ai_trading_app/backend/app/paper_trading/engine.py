"""Simulated order execution against REAL market prices.

Nothing here ever invents a price — every call site passes in a price
obtained from `MarketDataService` (a live ticker price or the latest
closed candle's close), sourced from the real Binance market-data layer
built in Phase 2. This module's only job is to simulate what a real
fill would look like on top of that real price: fees, slippage, and
position sizing.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from .config import PaperTradingConfig
from .models import ExitReason, PaperOrder, PaperPosition, PositionSide, PositionStatus
from .repository import PaperTradingRepository, new_client_order_id


class PaperExecutionError(Exception):
    """Raised when a simulated order cannot be filled (e.g. insufficient
    virtual balance) — the caller must treat this exactly like a
    rejected real order, never silently proceed."""


@dataclass(frozen=True)
class FillResult:
    filled_price: float
    quantity: float
    fee: float
    slippage_amount: float


def _simulate_fill_price(reference_price: float, *, side: str, slippage_fraction: float) -> float:
    """Slippage always works against the trader: buys fill slightly
    above the reference price, sells fill slightly below it. This is a
    deliberately pessimistic (not random, not favorable) simulation —
    real slippage is not free money, and a paper engine that pretends
    otherwise teaches the wrong lesson before the AI ever risks real
    capital."""
    if side == "BUY":
        return reference_price * (1 + slippage_fraction)
    return reference_price * (1 - slippage_fraction)


class PaperExecutionEngine:
    def __init__(
        self,
        *,
        repository: PaperTradingRepository,
        config: PaperTradingConfig,
        now_fn: Callable[[], datetime] | None = None,
    ):
        self._repo = repository
        self._config = config
        # Defaults to the real wall clock — unchanged live/paper-trading
        # behavior. `backtesting.replay_engine` passes a
        # `SimulatedClock.now` here so a position's `opened_at` reflects
        # the simulated historical instant it was opened at during
        # replay, never the real moment the backtest happens to be
        # running. Without this, `opened_at` would always read "today"
        # regardless of which historical candle triggered the trade —
        # silently breaking chronological ordering, holding-time
        # calculations, and daily-loss/daily-trade-count windows for
        # every backtested trade.
        self._now_fn: Callable[[], datetime] = now_fn or (lambda: datetime.now(timezone.utc))

    async def open_position(
        self,
        *,
        symbol: str,
        side: PositionSide,
        reference_price: float,
        stop_loss: float,
        take_profit: float,
        signal_id: str,
        signal_confidence: float,
        account_id: str,
    ) -> PaperPosition | None:
        """Opens a simulated position sized from `trade_amount_usd`.
        Returns None if a position with this exact client_order_id
        already exists (idempotent duplicate-trade protection) — this
        is NOT an error, callers should treat None as "already handled".
        """
        account = await self._repo.get_account(account_id)
        if account is None:
            raise PaperExecutionError(f"No paper account '{account_id}' — call get_or_create_account first")

        order_side = "BUY" if side == PositionSide.LONG else "SELL"
        fill_price = _simulate_fill_price(
            reference_price, side=order_side, slippage_fraction=self._config.slippage_fraction
        )
        slippage_amount = abs(fill_price - reference_price)

        quantity = self._config.trade_amount_usd / fill_price
        notional = quantity * fill_price
        fee = notional * self._config.fee_rate

        required = notional + fee
        if required > account.current_balance:
            raise PaperExecutionError(
                f"Insufficient virtual balance: need {required:.2f}, have {account.current_balance:.2f}"
            )

        client_order_id = new_client_order_id("open", f"{signal_id}-{symbol}-{side.value}")
        position = PaperPosition(
            id=str(uuid.uuid4()),
            account_id=account_id,
            symbol=symbol,
            side=side,
            status=PositionStatus.OPEN,
            entry_price=fill_price,
            quantity=quantity,
            stop_loss=stop_loss,
            take_profit=take_profit,
            entry_fee=fee,
            signal_id=signal_id,
            signal_confidence_at_entry=signal_confidence,
            opened_at=self._now_fn(),
            client_order_id=client_order_id,
            max_holding_seconds=self._config.max_holding_seconds,
        )

        created = await self._repo.open_position(position)
        if created is None:
            return None  # duplicate — another caller already opened this exact trade

        await self._repo.record_order(
            PaperOrder(
                id=str(uuid.uuid4()),
                position_id=created.id,
                side=order_side,
                purpose="ENTRY",
                requested_price=reference_price,
                filled_price=fill_price,
                quantity=quantity,
                fee=fee,
                slippage_amount=slippage_amount,
                filled_at=created.opened_at,
                client_order_id=client_order_id,
            )
        )

        # Reserve the notional + fee from the virtual balance immediately
        # (mirrors a real exchange holding margin/funds against an open order).
        await self._repo.adjust_balance(-required, account_id)

        return created

    async def close_position(
        self,
        position: PaperPosition,
        *,
        reference_price: float,
        exit_reason: ExitReason,
    ) -> PaperPosition | None:
        """Atomically transitions OPEN -> CLOSING -> CLOSED. Returns
        None if another caller already won the close race (e.g. TP and
        an early-exit check firing in the same cycle) — again, not an
        error, just "someone else already handled it"."""
        won = await self._repo.begin_close_position(position.id)
        if not won:
            return None

        try:
            order_side = "SELL" if position.side == PositionSide.LONG else "BUY"
            fill_price = _simulate_fill_price(
                reference_price, side=order_side, slippage_fraction=self._config.slippage_fraction
            )
            slippage_amount = abs(fill_price - reference_price)

            notional = position.quantity * fill_price
            fee = notional * self._config.fee_rate

            direction = 1.0 if position.side == PositionSide.LONG else -1.0
            gross_pnl = (fill_price - position.entry_price) * position.quantity * direction
            realized_pnl = gross_pnl - position.entry_fee - fee

            closed = await self._repo.finalize_close_position(
                position.id,
                exit_price=fill_price,
                exit_reason=exit_reason,
                realized_pnl=realized_pnl,
                exit_fee=fee,
            )

            await self._repo.record_order(
                PaperOrder(
                    id=str(uuid.uuid4()),
                    position_id=position.id,
                    side=order_side,
                    purpose="EXIT",
                    requested_price=reference_price,
                    filled_price=fill_price,
                    quantity=position.quantity,
                    fee=fee,
                    slippage_amount=slippage_amount,
                    filled_at=closed.closed_at,
                    client_order_id=new_client_order_id("close", position.client_order_id),
                )
            )

            # Return the original notional + fee reservation, plus/minus
            # the realized P&L.
            returned_amount = (position.entry_price * position.quantity) + position.entry_fee + realized_pnl
            await self._repo.adjust_balance(returned_amount, position.account_id)

            return closed
        except Exception:
            # Never leave a position stuck in CLOSING if something failed
            # mid-computation — the next cycle must be able to retry.
            await self._repo.revert_closing(position.id)
            raise
