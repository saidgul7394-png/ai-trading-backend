"""Domain value objects for the paper trading engine. Deliberately
separate from Phase 1's SQLAlchemy `models/trade.py` — that models a
future live-trading DB row; these model what actually runs in Phase 3
against the SQLite persistence layer in `db.py`."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class PositionSide(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"


class PositionStatus(str, Enum):
    OPEN = "OPEN"
    CLOSING = "CLOSING"  # transient — being closed, prevents a second closer
    CLOSED = "CLOSED"


class ExitReason(str, Enum):
    TAKE_PROFIT = "TAKE_PROFIT"
    STOP_LOSS = "STOP_LOSS"
    TRAILING_STOP = "TRAILING_STOP"
    EARLY_EXIT_SIGNAL_REVERSAL = "EARLY_EXIT_SIGNAL_REVERSAL"
    MAX_HOLDING_TIME = "MAX_HOLDING_TIME"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    MANUAL = "MANUAL"


@dataclass
class PaperAccount:
    id: str
    starting_balance: float
    current_balance: float
    created_at: datetime


@dataclass
class PaperPosition:
    id: str
    account_id: str
    symbol: str
    side: PositionSide
    status: PositionStatus
    entry_price: float
    quantity: float
    stop_loss: float
    take_profit: float
    entry_fee: float
    signal_id: str
    signal_confidence_at_entry: float
    opened_at: datetime
    client_order_id: str
    trailing_stop_price: float | None = None
    trailing_stop_active: bool = False
    exit_price: float | None = None
    exit_reason: ExitReason | None = None
    realized_pnl: float | None = None
    exit_fee: float | None = None
    closed_at: datetime | None = None
    max_holding_seconds: int | None = None

    @property
    def is_open(self) -> bool:
        return self.status == PositionStatus.OPEN

    def unrealized_pnl(self, current_price: float) -> float:
        direction = 1.0 if self.side == PositionSide.LONG else -1.0
        return (current_price - self.entry_price) * self.quantity * direction

    def unrealized_pnl_percent(self, current_price: float) -> float:
        notional = self.entry_price * self.quantity
        if notional == 0:
            return 0.0
        return (self.unrealized_pnl(current_price) / notional) * 100.0

    def holding_seconds(self, now: datetime) -> float:
        return (now - self.opened_at).total_seconds()


@dataclass
class PaperOrder:
    id: str
    position_id: str
    side: str  # BUY | SELL
    purpose: str  # ENTRY | EXIT
    requested_price: float
    filled_price: float
    quantity: float
    fee: float
    slippage_amount: float
    filled_at: datetime
    client_order_id: str


@dataclass
class TradeStats:
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate_percent: float
    total_realized_pnl: float
    avg_win: float
    avg_loss: float
    largest_win: float
    largest_loss: float


@dataclass
class SignalLogEntry:
    id: str
    symbol: str
    timeframe: str
    action: str
    confidence: float
    eligible_for_auto_trade: bool
    rejection_reason: str | None
    generated_at: datetime
    factors: list[dict] = field(default_factory=list)
