"""SQLite-backed persistence for Phase 3 (paper trading, position state,
risk state, signal/audit log).

Why SQLite here and not the Postgres/SQLAlchemy models in `app/db/` and
`app/models/`: those model a future production deployment (account
data, live Binance links) and are intentionally left as reviewed-but-
unexercised scaffolding per the Phase 1/2 notes. Phase 3's explicit
requirements — "do not keep critical trading state only in memory" and
"verify application restart does not lose open paper positions" — need
a persistence layer that actually runs and is actually tested, not one
more layer of stubs. SQLite via the stdlib `sqlite3` module needs no
external service, no network, and no extra dependency, which makes it
possible to prove the restart-recovery guarantee end-to-end in this
environment. The repository interface in `repository.py` is the
seam: swapping the storage engine for Postgres in a later phase means
reimplementing `Database`/`PaperTradingRepository` internals, not
touching the engine, position manager, pipeline, or worker.

Concurrency note: `sqlite3` connections are not safe to share across
threads. Every operation here opens a short-lived connection (cheap for
SQLite) and every write is serialized through a single process-wide
`threading.Lock`, which — combined with the per-symbol asyncio locks in
`pipeline.py` — is what makes duplicate-trade / concurrent-execution
protection actually hold under concurrent async callers.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

DEFAULT_DB_PATH = "paper_trading.sqlite3"

_write_lock = threading.Lock()

SCHEMA_VERSION = 1

MIGRATIONS: list[str] = [
    # --- v1: initial schema ---
    """
    CREATE TABLE IF NOT EXISTS schema_meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS paper_accounts (
        id TEXT PRIMARY KEY,
        starting_balance REAL NOT NULL,
        current_balance REAL NOT NULL,
        created_at TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS paper_positions (
        id TEXT PRIMARY KEY,
        account_id TEXT NOT NULL,
        symbol TEXT NOT NULL,
        side TEXT NOT NULL,               -- LONG | SHORT
        status TEXT NOT NULL,             -- OPEN | CLOSING | CLOSED
        entry_price REAL NOT NULL,
        quantity REAL NOT NULL,
        stop_loss REAL NOT NULL,
        take_profit REAL NOT NULL,
        trailing_stop_price REAL,
        trailing_stop_active INTEGER NOT NULL DEFAULT 0,
        exit_price REAL,
        exit_reason TEXT,
        realized_pnl REAL,
        entry_fee REAL NOT NULL,
        exit_fee REAL,
        signal_id TEXT NOT NULL,
        signal_confidence_at_entry REAL NOT NULL,
        opened_at TEXT NOT NULL,
        closed_at TEXT,
        max_holding_seconds INTEGER,
        client_order_id TEXT NOT NULL UNIQUE,
        FOREIGN KEY (account_id) REFERENCES paper_accounts(id)
    );
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_positions_status ON paper_positions(status);
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_positions_symbol ON paper_positions(symbol);
    """,
    """
    CREATE TABLE IF NOT EXISTS paper_orders (
        id TEXT PRIMARY KEY,
        position_id TEXT NOT NULL,
        side TEXT NOT NULL,               -- BUY | SELL
        purpose TEXT NOT NULL,            -- ENTRY | EXIT
        requested_price REAL NOT NULL,
        filled_price REAL NOT NULL,
        quantity REAL NOT NULL,
        fee REAL NOT NULL,
        slippage_amount REAL NOT NULL,
        filled_at TEXT NOT NULL,
        client_order_id TEXT NOT NULL UNIQUE,
        FOREIGN KEY (position_id) REFERENCES paper_positions(id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS signal_log (
        id TEXT PRIMARY KEY,
        symbol TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        action TEXT NOT NULL,
        confidence REAL NOT NULL,
        eligible_for_auto_trade INTEGER NOT NULL,
        rejection_reason TEXT,
        generated_at TEXT NOT NULL,
        factors_json TEXT NOT NULL
    );
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_signal_log_symbol_time ON signal_log(symbol, generated_at);
    """,
    """
    CREATE TABLE IF NOT EXISTS risk_events (
        id TEXT PRIMARY KEY,
        event_type TEXT NOT NULL,          -- TRADE_OPENED | TRADE_CLOSED | RISK_BLOCK | EMERGENCY_STOP | EMERGENCY_STOP_CLEARED | CIRCUIT_BREAKER_TRIPPED
        symbol TEXT,
        payload_json TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_risk_events_time ON risk_events(created_at);
    """,
    """
    CREATE TABLE IF NOT EXISTS risk_state (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS symbol_cooldowns (
        symbol TEXT PRIMARY KEY,
        last_signal_action TEXT NOT NULL,
        cooldown_until TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS worker_heartbeat (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        last_run_at TEXT,
        last_error TEXT,
        consecutive_failures INTEGER NOT NULL DEFAULT 0,
        total_cycles INTEGER NOT NULL DEFAULT 0
    );
    """,
]


class Database:
    """Thin synchronous SQLite wrapper. All public methods are safe to
    call from async code via `asyncio.to_thread` (see `repository.py`,
    which never calls sqlite3 directly on the event loop thread)."""

    def __init__(self, path: str | Path = DEFAULT_DB_PATH):
        self.path = str(path)
        self._migrate()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _migrate(self) -> None:
        with _write_lock, self._connect() as conn:
            conn.execute(
                "CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)"
            )
            row = conn.execute(
                "SELECT value FROM schema_meta WHERE key = 'version'"
            ).fetchone()
            current_version = int(row["value"]) if row else 0

            for i, statement in enumerate(MIGRATIONS, start=1):
                if i > current_version:
                    conn.executescript(statement)

            conn.execute(
                "INSERT INTO schema_meta (key, value) VALUES ('version', ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (str(SCHEMA_VERSION),),
            )
            conn.execute(
                "INSERT OR IGNORE INTO worker_heartbeat (id, consecutive_failures, total_cycles) VALUES (1, 0, 0)"
            )

    # --- Generic execute helpers used by the repository layer ---

    def execute(self, sql: str, params: tuple = ()) -> None:
        with _write_lock, self._connect() as conn:
            conn.execute(sql, params)

    def execute_returning_rowcount(self, sql: str, params: tuple = ()) -> int:
        """Runs an UPDATE/INSERT and returns how many rows were affected
        — used for atomic compare-and-swap style state transitions
        (e.g. `UPDATE ... WHERE status = 'OPEN'`), which is how this
        layer prevents double-close/double-exit races without needing
        a distributed lock."""
        with _write_lock, self._connect() as conn:
            cursor = conn.execute(sql, params)
            return cursor.rowcount

    def query_one(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        with self._connect() as conn:
            return conn.execute(sql, params).fetchone()

    def query_all(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        with self._connect() as conn:
            return conn.execute(sql, params).fetchall()

    def reset_for_tests(self) -> None:
        """Drops all tables and re-runs migrations. Test-only — never
        called from application code."""
        with _write_lock, self._connect() as conn:
            tables = [
                r["name"]
                for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence'"
                ).fetchall()
            ]
            for t in tables:
                conn.execute(f"DROP TABLE IF EXISTS {t}")
        self._migrate()


async def run_db(fn, *args, **kwargs):
    """Runs a synchronous Database method off the event loop thread."""
    return await asyncio.to_thread(fn, *args, **kwargs)


def dict_from_json(value: str | None) -> dict:
    return json.loads(value) if value else {}


def json_from_dict(value: dict | list) -> str:
    return json.dumps(value)
