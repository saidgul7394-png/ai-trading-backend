"""Circuit breaker + emergency stop state, backed by Redis so it's
consistent across multiple backend worker processes and survives a
single process restart.

Circuit breaker: trips AUTOMATICALLY when abnormal conditions are
detected (e.g. rapid consecutive losses, extreme volatility spike,
exchange API errors spiking, slippage repeatedly exceeding tolerance).
Emergency stop: triggered by the USER (or an admin) and must be
explicitly cleared by the user before auto trading can resume.
"""

from __future__ import annotations

import redis.asyncio as redis

_CIRCUIT_BREAKER_KEY = "risk:circuit_breaker:{user_id}"
_EMERGENCY_STOP_KEY = "risk:emergency_stop:{user_id}"
_COOLDOWN_KEY = "risk:cooldown:{user_id}:{symbol}"


class RiskStateStore:
    def __init__(self, redis_client: redis.Redis):
        self._redis = redis_client

    async def is_circuit_breaker_tripped(self, user_id: str) -> bool:
        return bool(await self._redis.get(_CIRCUIT_BREAKER_KEY.format(user_id=user_id)))

    async def trip_circuit_breaker(self, user_id: str, *, reason: str, ttl_seconds: int = 3600) -> None:
        await self._redis.set(
            _CIRCUIT_BREAKER_KEY.format(user_id=user_id), reason, ex=ttl_seconds
        )

    async def is_emergency_stop_active(self, user_id: str) -> bool:
        return bool(await self._redis.get(_EMERGENCY_STOP_KEY.format(user_id=user_id)))

    async def set_emergency_stop(self, user_id: str, active: bool) -> None:
        key = _EMERGENCY_STOP_KEY.format(user_id=user_id)
        if active:
            await self._redis.set(key, "1")
        else:
            await self._redis.delete(key)

    async def set_cooldown(self, user_id: str, symbol: str, seconds: int) -> None:
        await self._redis.set(_COOLDOWN_KEY.format(user_id=user_id, symbol=symbol), "1", ex=seconds)

    async def is_cooldown_active(self, user_id: str, symbol: str) -> bool:
        return bool(await self._redis.get(_COOLDOWN_KEY.format(user_id=user_id, symbol=symbol)))
