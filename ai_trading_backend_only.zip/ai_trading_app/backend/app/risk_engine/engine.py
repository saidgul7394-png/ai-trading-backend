"""Server-side risk engine.

This module is the single gate every automatic trade must pass through.
`signal_engine/` NEVER calls the Binance order service directly — it can
only *propose* a trade, which this module then approves or rejects.

Design principle: fail closed. Any missing data, stale price, ambiguous
state, or exception inside this module must result in a REJECTED trade,
never a silently-approved one.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from ..core.config import get_settings


@dataclass
class RiskCheckResult:
    approved: bool
    reasons: list[str] = field(default_factory=list)


@dataclass
class RiskContext:
    """Everything the risk engine needs to evaluate one proposed trade.
    Populated by the orchestration service from live DB/account state —
    never from client-supplied values, to prevent a compromised client
    from spoofing "we have plenty of room left"."""

    user_min_confidence: float
    user_max_daily_loss_percent: float
    user_max_risk_per_trade_percent: float
    user_max_open_trades: int
    user_max_trades_per_day: int | None  # None => AI decides, no fixed cap

    current_daily_loss_percent: float
    current_daily_trades: int
    current_open_trades: int

    last_trade_at: datetime | None
    cooldown_seconds: int

    circuit_breaker_tripped: bool
    emergency_stop_active: bool

    signal_confidence: float
    signal_data_freshness_seconds: int
    max_allowed_data_staleness_seconds: int

    proposed_risk_percent: float
    duplicate_open_signal: bool  # same symbol+direction already open


def evaluate_trade_proposal(ctx: RiskContext, *, now: datetime | None = None) -> RiskCheckResult:
    """Pure function: given a fully-populated context, decide approve or
    reject. Kept side-effect free and synchronous so it's trivially unit
    testable — this is the function correctness of the whole app hinges
    on most.

    `now` defaults to the real wall clock (unchanged live-trading /
    paper-trading behavior) but can be supplied explicitly so the exact
    same gate can be replayed deterministically against *simulated*
    historical time during backtesting — without this, a chronological
    replay's cooldown check would compare a historical `last_trade_at`
    against today's real date and the cooldown gate would never fire
    (or would fire nonsensically), silently corrupting the backtest.
    """
    now = now or datetime.now(timezone.utc)
    settings = get_settings()
    reasons: list[str] = []

    if ctx.emergency_stop_active:
        reasons.append("Emergency stop is active.")

    if ctx.circuit_breaker_tripped:
        reasons.append("Circuit breaker has tripped — trading paused.")

    # --- Confidence gate ---
    if ctx.signal_confidence < ctx.user_min_confidence:
        reasons.append(
            f"Signal confidence {ctx.signal_confidence:.0%} below minimum "
            f"{ctx.user_min_confidence:.0%}."
        )

    # --- Data freshness / stale-data protection ---
    if ctx.signal_data_freshness_seconds > ctx.max_allowed_data_staleness_seconds:
        reasons.append(
            f"Market data is stale ({ctx.signal_data_freshness_seconds}s old)."
        )

    # --- Daily loss limit (user setting, capped by platform hard ceiling) ---
    effective_max_daily_loss = min(
        ctx.user_max_daily_loss_percent, settings.hard_max_daily_loss_percent
    )
    if ctx.current_daily_loss_percent >= effective_max_daily_loss:
        reasons.append(
            f"Daily loss limit reached ({ctx.current_daily_loss_percent:.2f}% "
            f">= {effective_max_daily_loss:.2f}%)."
        )

    # --- Per-trade risk cap ---
    effective_max_risk_per_trade = min(
        ctx.user_max_risk_per_trade_percent, settings.hard_max_risk_per_trade_percent
    )
    if ctx.proposed_risk_percent > effective_max_risk_per_trade:
        reasons.append(
            f"Proposed risk {ctx.proposed_risk_percent:.2f}% exceeds max "
            f"{effective_max_risk_per_trade:.2f}% per trade."
        )

    # --- Open trades cap ---
    effective_max_open = min(ctx.user_max_open_trades, settings.hard_max_open_trades)
    if ctx.current_open_trades >= effective_max_open:
        reasons.append(
            f"Max open trades reached ({ctx.current_open_trades}/{effective_max_open})."
        )

    # --- Daily trade count cap (only when user fixed a limit) ---
    if (
        ctx.user_max_trades_per_day is not None
        and ctx.current_daily_trades >= ctx.user_max_trades_per_day
    ):
        reasons.append(
            f"Max trades for today reached "
            f"({ctx.current_daily_trades}/{ctx.user_max_trades_per_day})."
        )

    # --- Cooldown ---
    if ctx.last_trade_at is not None:
        elapsed = now - ctx.last_trade_at
        cooldown = timedelta(seconds=ctx.cooldown_seconds)
        if elapsed < cooldown:
            remaining = int((cooldown - elapsed).total_seconds())
            reasons.append(f"Cooldown active ({remaining}s remaining).")

    # --- Duplicate-signal protection ---
    if ctx.duplicate_open_signal:
        reasons.append("A trade in the same direction on this symbol is already open.")

    return RiskCheckResult(approved=len(reasons) == 0, reasons=reasons)
