from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from ..core.config import get_settings


class Base(DeclarativeBase):
    """Base class for all ORM models (see app/models/)."""


_settings = get_settings()

engine = create_async_engine(_settings.database_url, echo=_settings.environment == "development")

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_db() -> AsyncSession:
    """FastAPI dependency — yields a request-scoped DB session."""
    async with AsyncSessionLocal() as session:
        yield session
