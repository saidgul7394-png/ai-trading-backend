"""Ties market data, the composite signal engine, and the signal-level
protections (stale data / duplicate / cooldown) together into one
callable used by the signals router and (in a future phase) the
background worker loop that continuously refreshes signals.

Every signal produced here is PAPER/SIMULATION ONLY in Phase 2 — this
module has no knowledge of order placement and never calls
`services/trading_orchestrator.py` or `services/binance_service.py`.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..services.market_data.models import (
    StaleDataError,
    UnsupportedIntervalError,
    UnsupportedSymbolError,
    validate_interval,
    validate_symbol,
)
from .composite import CompositeSignal, build_composite_signal
from .config import DEFAULT_CONFIG, SignalEngineConfig
from .protections import CooldownTracker, DuplicateSignalGuard

if TYPE_CHECKING:
    # Only needed for the type hint below — kept out of the runtime
    # import graph so this module (and anything using a duck-typed
    # fake/mock market-data service in tests) never has to pull in
    # httpx/websockets transitively via the real MarketDataService.
    from ..services.market_data.service import MarketDataService

logger = logging.getLogger("signal_engine.service")

BTC_SYMBOL = "BTCUSDT"


class SignalGenerationService:
    def __init__(
        self,
        *,
        market_data: MarketDataService,
        config: SignalEngineConfig = DEFAULT_CONFIG,
        duplicate_guard: DuplicateSignalGuard | None = None,
        cooldown_tracker: CooldownTracker | None = None,
    ):
        self._market_data = market_data
        self._config = config
        self._duplicate_guard = duplicate_guard or DuplicateSignalGuard(
            window_seconds=config.duplicate_signal_window_seconds
        )
        self._cooldown = cooldown_tracker or CooldownTracker(cooldown_seconds=config.cooldown_seconds)

    async def generate_signal(
        self, symbol: str, primary_timeframe: str = "1h", *, apply_protections: bool = True
    ) -> CompositeSignal:
        """Full pipeline for one symbol: validate -> ensure fresh data
        -> gather multi-timeframe + BTC candles -> composite scoring ->
        apply cooldown/duplicate protections. Never raises for "no
        opportunity" — that's represented as a HOLD signal, not an
        exception. Raises only for programming/config errors (unknown
        symbol/interval) or when a fresh-data attempt truly fails.

        `apply_protections=False` skips this service's own signal-level
        duplicate/cooldown suppression. Set this when the caller (e.g.
        `paper_trading.pipeline.TradingPipeline`) has its OWN cooldown
        that is correctly tied to actual trade execution rather than to
        "a signal was merely eligible" — without this, a signal that was
        eligible but blocked downstream (emergency stop, a risk-limit
        rejection) would incorrectly start this service's cooldown as if
        a trade had happened, then wrongly suppress the next, otherwise
        legitimate, evaluation. Callers that only display signals (e.g.
        the AI Signals screen) should leave this True so rapid re-polling
        doesn't flood the UI with re-flagged duplicates.
        """
        symbol = validate_symbol(symbol, self._market_data.symbols)
        primary_timeframe = validate_interval(primary_timeframe)

        try:
            await self._market_data.ensure_fresh_or_backfill(symbol, primary_timeframe)
        except StaleDataError as e:
            logger.warning("Serving stale-forced HOLD for %s %s: %s", symbol, primary_timeframe, e)
            return build_composite_signal(
                symbol=symbol,
                primary_timeframe=primary_timeframe,
                candles_by_timeframe={},
                data_freshness_seconds=None,
                config=self._config,
            )

        candles_by_tf = await self._market_data.get_candles_multi_timeframe(
            symbol, self._config.confirmation_timeframes + (primary_timeframe,)
        )

        btc_candles = None
        try:
            btc_candles = await self._market_data.get_candles(BTC_SYMBOL, primary_timeframe)
        except (UnsupportedSymbolError, UnsupportedIntervalError):
            pass

        order_book = None
        try:
            order_book = await self._market_data.get_order_book(symbol)
        except Exception as e:  # noqa: BLE001 — order book is best-effort, never blocks a signal
            logger.info("Order book unavailable for %s: %s", symbol, e)

        freshness = await self._market_data.freshness_seconds(symbol, primary_timeframe)

        signal = build_composite_signal(
            symbol=symbol,
            primary_timeframe=primary_timeframe,
            candles_by_timeframe=candles_by_tf,
            btc_candles=btc_candles,
            order_book=order_book,
            data_freshness_seconds=freshness,
            config=self._config,
        )

        return self._apply_protections(signal) if apply_protections else signal

    def _apply_protections(self, signal: CompositeSignal) -> CompositeSignal:
        """Duplicate/cooldown protections never change what the
        composite engine computed — they only strip auto-trade
        eligibility and annotate why, so the UI still shows the honest
        analysis while paper-trading (and, later, live trading) is
        blocked from acting on it."""
        if signal.action == "HOLD":
            return signal

        if self._cooldown.is_active(signal.symbol):
            remaining = self._cooldown.remaining_seconds(signal.symbol)
            return _strip_eligibility(signal, f"Cooldown active for {signal.symbol} ({remaining}s remaining).")

        if self._duplicate_guard.is_duplicate(signal.symbol, signal.action):
            return _strip_eligibility(
                signal, f"Duplicate {signal.action} signal for {signal.symbol} suppressed."
            )

        if signal.eligible_for_auto_trade:
            self._duplicate_guard.record(signal.symbol, signal.action)
            self._cooldown.record(signal.symbol, signal.action)

        return signal


def _strip_eligibility(signal: CompositeSignal, reason: str) -> CompositeSignal:
    from dataclasses import replace

    return replace(signal, eligible_for_auto_trade=False, rejection_reason=reason)
