"""Signal-level safety gates, independent of (and in addition to) the
order-level risk engine in `app/risk_engine/`. These operate purely on
signal generation/emission — they run even in paper-trading mode, and
even before any trade is proposed, so a bad signal never even reaches
the UI badged as tradeable.

Kept as small, pure, dependency-injected classes (clock injected) so
they're fully deterministic in tests — no `datetime.now()` calls buried
inside logic that would make tests flaky or require sleeping.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable

Clock = Callable[[], datetime]


def _default_clock() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class DuplicateSignalGuard:
    """Suppresses re-emitting the same (symbol, action) signal within a
    short window — prevents flooding the UI/paper-trading loop with
    near-identical signals as the same setup gets re-evaluated on every
    tick.
    """

    window_seconds: int
    clock: Clock = field(default=_default_clock)
    _last_emitted: dict[tuple[str, str], datetime] = field(default_factory=dict)

    def is_duplicate(self, symbol: str, action: str) -> bool:
        if action == "HOLD":
            return False  # HOLD is never considered a duplicate-worth signal
        key = (symbol.upper(), action.upper())
        last = self._last_emitted.get(key)
        if last is None:
            return False
        return (self.clock() - last).total_seconds() < self.window_seconds

    def record(self, symbol: str, action: str) -> None:
        if action == "HOLD":
            return
        self._last_emitted[(symbol.upper(), action.upper())] = self.clock()


@dataclass
class CooldownTracker:
    """Per-symbol cooldown, independent of direction — once ANY
    directional signal fires for a symbol, no new directional signal is
    allowed to fire for that symbol until the cooldown elapses. This is
    stricter than the duplicate guard (which only blocks the *same*
    direction) and exists to stop rapid flip-flopping BUY/SELL churn.
    """

    cooldown_seconds: int
    clock: Clock = field(default=_default_clock)
    _last_signal_at: dict[str, datetime] = field(default_factory=dict)

    def remaining_seconds(self, symbol: str) -> int:
        last = self._last_signal_at.get(symbol.upper())
        if last is None:
            return 0
        elapsed = (self.clock() - last).total_seconds()
        remaining = self.cooldown_seconds - elapsed
        return max(0, int(remaining))

    def is_active(self, symbol: str) -> bool:
        return self.remaining_seconds(symbol) > 0

    def record(self, symbol: str, action: str) -> None:
        if action == "HOLD":
            return
        self._last_signal_at[symbol.upper()] = self.clock()


def is_data_stale(freshness_seconds: int | None, *, max_allowed_seconds: float) -> bool:
    """freshness_seconds is None => no data at all => treated as stale
    (fail closed)."""
    if freshness_seconds is None:
        return True
    return freshness_seconds > max_allowed_seconds
