"""Deterministic technical indicator calculations.

Every function here is pure: same input candles always produce the same
output, no randomness, no external calls, no LLM involvement. This is
what the Phase 2 spec means by "do not use an LLM to calculate numeric
indicators" — indicator math is arithmetic, not inference.

Each function raises InsufficientDataError when there isn't enough
history for the requested period, rather than silently returning a
degraded/zero value that could look like a real signal.
"""

from __future__ import annotations

from dataclasses import dataclass
from statistics import fmean, pstdev

from ..services.market_data.models import Candle, InsufficientDataError

# ---------------------------------------------------------------------------
# Moving averages
# ---------------------------------------------------------------------------


def sma(values: list[float], period: int) -> float:
    """Simple moving average of the last `period` values."""
    if period <= 0:
        raise ValueError("period must be positive")
    if len(values) < period:
        raise InsufficientDataError(f"SMA({period}) needs {period} values, got {len(values)}")
    return fmean(values[-period:])


def sma_series(values: list[float], period: int) -> list[float]:
    """Full SMA series (one value per index once enough history exists).
    Used internally by indicators that need a moving SMA, e.g. Bollinger
    Bands and MACD signal-line-free consumers."""
    if len(values) < period:
        raise InsufficientDataError(f"SMA({period}) needs {period} values, got {len(values)}")
    return [fmean(values[i - period + 1 : i + 1]) for i in range(period - 1, len(values))]


def ema_series(values: list[float], period: int) -> list[float]:
    """Full EMA series, seeded with the SMA of the first `period` values
    (the standard, most common EMA seeding convention)."""
    if period <= 0:
        raise ValueError("period must be positive")
    if len(values) < period:
        raise InsufficientDataError(f"EMA({period}) needs {period} values, got {len(values)}")

    k = 2.0 / (period + 1)
    seed = fmean(values[:period])
    out = [seed]
    for v in values[period:]:
        out.append(v * k + out[-1] * (1 - k))
    return out


def ema(values: list[float], period: int) -> float:
    return ema_series(values, period)[-1]


# ---------------------------------------------------------------------------
# RSI
# ---------------------------------------------------------------------------


def rsi(closes: list[float], period: int = 14) -> float:
    """Wilder's RSI. Returns a value in [0, 100]."""
    if period <= 0:
        raise ValueError("period must be positive")
    if len(closes) < period + 1:
        raise InsufficientDataError(f"RSI({period}) needs {period + 1} closes, got {len(closes)}")

    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [max(d, 0.0) for d in deltas]
    losses = [max(-d, 0.0) for d in deltas]

    avg_gain = fmean(gains[:period])
    avg_loss = fmean(losses[:period])

    # Wilder smoothing for the remainder of the series.
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    if avg_gain == 0 and avg_loss == 0:
        return 50.0  # perfectly flat series: no gains, no losses => neutral
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


# ---------------------------------------------------------------------------
# MACD
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MacdResult:
    macd_line: float
    signal_line: float
    histogram: float


def macd(
    closes: list[float], *, fast: int = 12, slow: int = 26, signal: int = 9
) -> MacdResult:
    if slow <= fast:
        raise ValueError("slow period must be greater than fast period")
    min_len = slow + signal
    if len(closes) < min_len:
        raise InsufficientDataError(f"MACD({fast},{slow},{signal}) needs {min_len} closes, got {len(closes)}")

    fast_ema = ema_series(closes, fast)
    slow_ema = ema_series(closes, slow)
    # Align series (fast_ema is longer since it starts earlier) to compute
    # the MACD line over the overlapping tail.
    offset = len(fast_ema) - len(slow_ema)
    macd_line_series = [fast_ema[i + offset] - slow_ema[i] for i in range(len(slow_ema))]

    if len(macd_line_series) < signal:
        raise InsufficientDataError("Not enough MACD history to compute the signal line")

    signal_series = ema_series(macd_line_series, signal)
    macd_line = macd_line_series[-1]
    signal_line = signal_series[-1]
    return MacdResult(macd_line=macd_line, signal_line=signal_line, histogram=macd_line - signal_line)


# ---------------------------------------------------------------------------
# Bollinger Bands
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BollingerBands:
    upper: float
    middle: float
    lower: float
    bandwidth: float  # (upper - lower) / middle — squeeze/expansion measure
    percent_b: float  # where the last close sits within the bands, 0..1 typical


def bollinger_bands(closes: list[float], *, period: int = 20, num_std: float = 2.0) -> BollingerBands:
    if len(closes) < period:
        raise InsufficientDataError(f"Bollinger({period}) needs {period} closes, got {len(closes)}")

    window = closes[-period:]
    middle = fmean(window)
    std = pstdev(window)
    upper = middle + num_std * std
    lower = middle - num_std * std
    bandwidth = (upper - lower) / middle if middle else 0.0
    band_range = upper - lower
    percent_b = (closes[-1] - lower) / band_range if band_range else 0.5
    return BollingerBands(upper=upper, middle=middle, lower=lower, bandwidth=bandwidth, percent_b=percent_b)


# ---------------------------------------------------------------------------
# ATR / Volatility
# ---------------------------------------------------------------------------


def true_ranges(candles: list[Candle]) -> list[float]:
    if len(candles) < 2:
        raise InsufficientDataError("True range needs at least 2 candles")
    out = []
    for i in range(1, len(candles)):
        c, prev = candles[i], candles[i - 1]
        out.append(max(c.high - c.low, abs(c.high - prev.close), abs(c.low - prev.close)))
    return out


def atr(candles: list[Candle], period: int = 14) -> float:
    """Wilder's ATR."""
    trs = true_ranges(candles)
    if len(trs) < period:
        raise InsufficientDataError(f"ATR({period}) needs {period + 1} candles, got {len(candles)}")

    avg = fmean(trs[:period])
    for tr in trs[period:]:
        avg = (avg * (period - 1) + tr) / period
    return avg


def volatility_percent(candles: list[Candle], period: int = 14) -> float:
    """ATR expressed as a percentage of the latest close — a
    timeframe-agnostic volatility measure usable across symbols with
    very different absolute prices (BTC vs a low-priced altcoin)."""
    value = atr(candles, period)
    latest_close = candles[-1].close
    return (value / latest_close) * 100.0 if latest_close else 0.0


# ---------------------------------------------------------------------------
# Volume
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class VolumeAnalysis:
    current: float
    average: float
    ratio: float  # current / average
    is_spike: bool  # ratio exceeds the spike threshold


def volume_analysis(volumes: list[float], *, lookback: int = 20, spike_threshold: float = 2.0) -> VolumeAnalysis:
    if len(volumes) < lookback + 1:
        raise InsufficientDataError(f"Volume analysis needs {lookback + 1} candles, got {len(volumes)}")

    current = volumes[-1]
    average = fmean(volumes[-lookback - 1 : -1])  # average of the lookback window BEFORE current
    ratio = current / average if average else 0.0
    return VolumeAnalysis(current=current, average=average, ratio=ratio, is_spike=ratio >= spike_threshold)


# ---------------------------------------------------------------------------
# Momentum
# ---------------------------------------------------------------------------


def momentum_percent(closes: list[float], period: int = 10) -> float:
    """Percent change over the last `period` closes. Positive = upward
    momentum, negative = downward."""
    if len(closes) < period + 1:
        raise InsufficientDataError(f"Momentum({period}) needs {period + 1} closes, got {len(closes)}")
    past = closes[-period - 1]
    current = closes[-1]
    return ((current - past) / past) * 100.0 if past else 0.0


# ---------------------------------------------------------------------------
# Support / Resistance and market structure
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SupportResistance:
    support: float
    resistance: float


def support_resistance(candles: list[Candle], *, lookback: int = 50) -> SupportResistance:
    """Simple, deterministic swing-based S/R: lowest low and highest
    high over the lookback window. A more advanced pivot-clustering
    approach can replace this later without changing the interface."""
    if len(candles) < lookback:
        raise InsufficientDataError(f"Support/resistance needs {lookback} candles, got {len(candles)}")
    window = candles[-lookback:]
    return SupportResistance(
        support=min(c.low for c in window),
        resistance=max(c.high for c in window),
    )


MarketStructure = str  # "uptrend" | "downtrend" | "range"


def market_structure(candles: list[Candle], *, swing_window: int = 5, lookback: int = 30) -> MarketStructure:
    """Classifies trend via swing highs/lows: higher-highs + higher-lows
    => uptrend, lower-highs + lower-lows => downtrend, otherwise range.

    `swing_window` is the half-width used to detect a local pivot (a
    candle whose high/low is the max/min within +/- swing_window of it).
    """
    if len(candles) < lookback:
        raise InsufficientDataError(f"Market structure needs {lookback} candles, got {len(candles)}")

    window = candles[-lookback:]
    swing_highs: list[float] = []
    swing_lows: list[float] = []

    for i in range(swing_window, len(window) - swing_window):
        segment = window[i - swing_window : i + swing_window + 1]
        if window[i].high == max(c.high for c in segment):
            swing_highs.append(window[i].high)
        if window[i].low == min(c.low for c in segment):
            swing_lows.append(window[i].low)

    if len(swing_highs) < 2 or len(swing_lows) < 2:
        return "range"

    higher_highs = swing_highs[-1] > swing_highs[0]
    higher_lows = swing_lows[-1] > swing_lows[0]
    lower_highs = swing_highs[-1] < swing_highs[0]
    lower_lows = swing_lows[-1] < swing_lows[0]

    if higher_highs and higher_lows:
        return "uptrend"
    if lower_highs and lower_lows:
        return "downtrend"
    return "range"


# ---------------------------------------------------------------------------
# Order book imbalance
# ---------------------------------------------------------------------------


def order_book_imbalance(bid_volumes: list[float], ask_volumes: list[float]) -> float:
    """Returns a value in [-1, 1]: positive => more bid depth (buy
    pressure), negative => more ask depth (sell pressure). 0 when book
    data is empty/unreliable — caller should treat 0 as "no reliable
    signal" rather than "neutral conviction" (see signal_engine which
    down-weights this factor when the book is thin)."""
    total_bid = sum(bid_volumes)
    total_ask = sum(ask_volumes)
    total = total_bid + total_ask
    if total <= 0:
        return 0.0
    return (total_bid - total_ask) / total
