"""Multi-factor composite signal engine.

Combines independent, deterministic indicator readings (see
`indicators.py`) plus BTC market-wide trend and multi-timeframe
confirmation into one composite BUY/SELL/HOLD signal with a confidence
score, entry/stop/target levels, and a full audit trail of which
factors contributed and why.

Hard rules enforced here (not just documented):
  - never produces BUY/SELL from fewer than
    `config.min_factors_for_directional_signal` independent factors
  - strongly conflicting factors force HOLD even if the net score would
    otherwise clear a threshold
  - missing/insufficient data for a factor means that factor is simply
    omitted (never fabricated) — if too few factors remain, the
    min-factors rule naturally forces HOLD
  - stale primary-timeframe data forces HOLD regardless of what the
    indicators say
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from ..services.market_data.models import Candle, InsufficientDataError, OrderBook
from . import indicators as ind
from .config import DEFAULT_CONFIG, SignalEngineConfig


@dataclass(frozen=True)
class Factor:
    name: str
    value: str  # human-readable raw reading, e.g. "RSI=28.4 (oversold)"
    weight: float  # weight actually used (post-reliability adjustment)
    leaning: float  # -1.0 (fully bearish) .. +1.0 (fully bullish)


@dataclass(frozen=True)
class CompositeSignal:
    symbol: str
    timeframe: str
    action: str  # BUY | SELL | HOLD
    confidence: float  # 0..1
    score: float  # raw normalized composite score, -1..1, before thresholding
    factors: list[Factor]
    reasons: list[str]
    entry_price: float
    stop_loss: float
    take_profit: float
    risk_reward_ratio: float
    generated_at: datetime
    data_freshness_seconds: int | None
    eligible_for_auto_trade: bool
    rejection_reason: str | None = None  # populated when forced to HOLD by a hard gate


def _clamp(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# ---------------------------------------------------------------------------
# Individual factor builders — each returns Factor | None (None = could
# not be computed from available data, never a fabricated neutral guess)
# ---------------------------------------------------------------------------


def _factor_ema_sma(closes: list[float], weight: float) -> Factor | None:
    try:
        ema_fast = ind.ema(closes, 9)
        ema_slow = ind.ema(closes, 21)
        sma_trend = ind.sma(closes, 50)
    except InsufficientDataError:
        return None

    price = closes[-1]
    cross_leaning = 1.0 if ema_fast > ema_slow else -1.0
    trend_leaning = 1.0 if price > sma_trend else -1.0
    leaning = _clamp((cross_leaning + trend_leaning) / 2.0)
    value = f"EMA9={ema_fast:.4f} EMA21={ema_slow:.4f} SMA50={sma_trend:.4f}"
    return Factor(name="EMA/SMA Trend", value=value, weight=weight, leaning=leaning)


def _factor_rsi(closes: list[float], weight: float) -> Factor | None:
    try:
        value = ind.rsi(closes, 14)
    except InsufficientDataError:
        return None

    if value <= 30:
        leaning = _clamp((30 - value) / 30)
        label = "oversold"
    elif value >= 70:
        leaning = _clamp(-(value - 70) / 30)
        label = "overbought"
    else:
        leaning = _clamp((value - 50) / 50) * 0.3
        label = "neutral"
    return Factor(name="RSI(14)", value=f"{value:.1f} ({label})", weight=weight, leaning=leaning)


def _factor_macd(closes: list[float], weight: float) -> Factor | None:
    try:
        result = ind.macd(closes)
    except InsufficientDataError:
        return None

    scale = abs(closes[-1]) * 0.002 or 1.0
    leaning = _clamp(result.histogram / scale)
    label = "bullish crossover" if result.histogram > 0 else "bearish crossover"
    value = f"MACD={result.macd_line:.4f} Signal={result.signal_line:.4f} Hist={result.histogram:.4f} ({label})"
    return Factor(name="MACD", value=value, weight=weight, leaning=leaning)


def _factor_bollinger(closes: list[float], weight: float) -> Factor | None:
    try:
        bands = ind.bollinger_bands(closes)
    except InsufficientDataError:
        return None

    leaning = _clamp((0.5 - bands.percent_b) * 2)
    value = f"%B={bands.percent_b:.2f} bandwidth={bands.bandwidth:.4f}"
    return Factor(name="Bollinger Bands", value=value, weight=weight, leaning=leaning)


def _factor_volume(volumes: list[float], candles: list[Candle], weight: float) -> Factor | None:
    try:
        analysis = ind.volume_analysis(volumes)
    except InsufficientDataError:
        return None

    if not analysis.is_spike:
        return Factor(
            name="Volume",
            value=f"ratio={analysis.ratio:.2f} (normal)",
            weight=weight * 0.4,
            leaning=0.0,
        )

    direction = 1.0 if candles[-1].is_bullish else -1.0
    intensity = _clamp((analysis.ratio - 1.0) / 3.0)
    leaning = _clamp(direction * intensity)
    return Factor(
        name="Volume", value=f"ratio={analysis.ratio:.2f} (spike, {'up' if direction > 0 else 'down'})",
        weight=weight, leaning=leaning,
    )


def _factor_momentum(closes: list[float], weight: float) -> Factor | None:
    try:
        pct = ind.momentum_percent(closes, 10)
    except InsufficientDataError:
        return None
    leaning = _clamp(pct / 5.0)
    return Factor(name="Momentum(10)", value=f"{pct:+.2f}%", weight=weight, leaning=leaning)


def _factor_support_resistance(candles: list[Candle], weight: float) -> Factor | None:
    try:
        sr = ind.support_resistance(candles, lookback=50)
    except InsufficientDataError:
        return None

    price = candles[-1].close
    span = sr.resistance - sr.support
    if span <= 0:
        return None
    position = (price - sr.support) / span
    leaning = _clamp((0.5 - position) * 1.6)
    value = f"support={sr.support:.4f} resistance={sr.resistance:.4f} pos={position:.2f}"
    return Factor(name="Support/Resistance", value=value, weight=weight, leaning=leaning)


def _factor_market_structure(candles: list[Candle], weight: float) -> Factor | None:
    try:
        structure = ind.market_structure(candles, lookback=min(30, len(candles)))
    except InsufficientDataError:
        return None
    leaning = {"uptrend": 1.0, "downtrend": -1.0, "range": 0.0}[structure]
    return Factor(name="Market Structure", value=structure, weight=weight, leaning=leaning)


def _factor_volatility(candles: list[Candle], weight: float) -> Factor | None:
    """Informational only — always leaning 0. Included for factor-list
    transparency; can drive future confidence damping without becoming
    a directional vote itself."""
    try:
        vol_pct = ind.volatility_percent(candles, period=14)
    except InsufficientDataError:
        return None
    return Factor(name="Volatility (ATR%)", value=f"{vol_pct:.2f}%", weight=weight, leaning=0.0)


def _factor_order_book(order_book: OrderBook | None, weight: float) -> Factor | None:
    if order_book is None or not order_book.bids or not order_book.asks:
        return None
    bid_vols = [level.quantity for level in order_book.bids]
    ask_vols = [level.quantity for level in order_book.asks]
    imbalance = ind.order_book_imbalance(bid_vols, ask_vols)
    reliability = _clamp(min(len(order_book.bids), len(order_book.asks)) / 20.0, 0.0, 1.0)
    return Factor(
        name="Order Book Imbalance",
        value=f"{imbalance:+.2f} ({len(order_book.bids)}x{len(order_book.asks)} levels)",
        weight=weight * reliability,
        leaning=imbalance,
    )


def _factor_btc_trend(btc_candles: list[Candle] | None, symbol: str, weight: float) -> Factor | None:
    if btc_candles is None:
        return None
    try:
        structure = ind.market_structure(btc_candles, lookback=min(30, len(btc_candles)))
    except InsufficientDataError:
        return None
    leaning = {"uptrend": 1.0, "downtrend": -1.0, "range": 0.0}[structure]
    label = "self" if symbol.upper() == "BTCUSDT" else "market-wide"
    return Factor(name="BTC Trend", value=f"{structure} ({label} confirmation)", weight=weight, leaning=leaning)


def _factor_multi_timeframe(
    candles_by_timeframe: dict[str, list[Candle]], config: SignalEngineConfig
) -> Factor | None:
    votes: list[float] = []
    details = []
    for tf in config.confirmation_timeframes:
        candles = candles_by_timeframe.get(tf)
        if not candles:
            continue
        try:
            structure = ind.market_structure(candles, lookback=min(30, len(candles)))
        except InsufficientDataError:
            continue
        vote = {"uptrend": 1.0, "downtrend": -1.0, "range": 0.0}[structure]
        votes.append(vote)
        details.append(f"{tf}={structure}")

    if len(votes) < config.timeframe_agreement_required:
        return None

    agreement = sum(votes) / len(votes)
    return Factor(
        name="Multi-Timeframe Confirmation",
        value=", ".join(details),
        weight=config.weights.multi_timeframe_agreement,
        leaning=_clamp(agreement),
    )


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------


def _build_all_factors(
    symbol: str,
    candles: list[Candle],
    candles_by_timeframe: dict[str, list[Candle]],
    btc_candles: list[Candle] | None,
    order_book: OrderBook | None,
    config: SignalEngineConfig,
) -> list[Factor]:
    closes = [c.close for c in candles]
    volumes = [c.volume for c in candles]
    w = config.weights

    builders: list[Factor | None] = [
        _factor_ema_sma(closes, w.ema_sma),
        _factor_rsi(closes, w.rsi),
        _factor_macd(closes, w.macd),
        _factor_bollinger(closes, w.bollinger),
        _factor_volume(volumes, candles, w.volume),
        _factor_momentum(closes, w.momentum),
        _factor_support_resistance(candles, w.support_resistance),
        _factor_market_structure(candles, w.market_structure),
        _factor_volatility(candles, w.volatility),
        _factor_order_book(order_book, w.order_book_imbalance),
        _factor_btc_trend(btc_candles, symbol, w.btc_trend),
        _factor_multi_timeframe(candles_by_timeframe, config),
    ]
    return [f for f in builders if f is not None]


def _detect_conflict(factors: list[Factor], config: SignalEngineConfig) -> bool:
    bullish_weight = sum(f.weight * f.leaning for f in factors if f.leaning > 0)
    bearish_weight = -sum(f.weight * f.leaning for f in factors if f.leaning < 0)

    if bullish_weight < config.conflict_min_magnitude or bearish_weight < config.conflict_min_magnitude:
        return False

    ratio = min(bullish_weight, bearish_weight) / max(bullish_weight, bearish_weight)
    return ratio >= config.conflict_ratio_threshold


def build_composite_signal(
    *,
    symbol: str,
    primary_timeframe: str,
    candles_by_timeframe: dict[str, list[Candle]],
    btc_candles: list[Candle] | None = None,
    order_book: OrderBook | None = None,
    data_freshness_seconds: int | None = None,
    config: SignalEngineConfig = DEFAULT_CONFIG,
    now: datetime | None = None,
) -> CompositeSignal:
    now = now or datetime.now(timezone.utc)
    candles = candles_by_timeframe.get(primary_timeframe, [])

    def _hold(reason: str, factors: list[Factor] | None = None) -> CompositeSignal:
        price = candles[-1].close if candles else 0.0
        return CompositeSignal(
            symbol=symbol,
            timeframe=primary_timeframe,
            action="HOLD",
            confidence=0.0,
            score=0.0,
            factors=factors or [],
            reasons=[reason],
            entry_price=price,
            stop_loss=price,
            take_profit=price,
            risk_reward_ratio=0.0,
            generated_at=now,
            data_freshness_seconds=data_freshness_seconds,
            eligible_for_auto_trade=False,
            rejection_reason=reason,
        )

    if data_freshness_seconds is not None:
        from .protections import is_data_stale
        from ..services.market_data.models import INTERVAL_SECONDS

        try:
            max_allowed = INTERVAL_SECONDS[primary_timeframe] * config.max_staleness_multiplier
        except KeyError:
            max_allowed = 3600
        if is_data_stale(data_freshness_seconds, max_allowed_seconds=max_allowed):
            return _hold(f"Market data is stale ({data_freshness_seconds}s old).")

    if len(candles) < config.min_candles_required:
        return _hold(
            f"Insufficient market data: {len(candles)} candles available, "
            f"{config.min_candles_required} required."
        )

    factors = _build_all_factors(symbol, candles, candles_by_timeframe, btc_candles, order_book, config)

    if len(factors) < config.min_factors_for_directional_signal:
        return _hold(
            f"Only {len(factors)} independent factors available "
            f"(minimum {config.min_factors_for_directional_signal} required).",
            factors=factors,
        )

    conflicting = _detect_conflict(factors, config)

    total_weight = sum(f.weight for f in factors) or 1.0
    score = _clamp(sum(f.weight * f.leaning for f in factors) / total_weight)

    if conflicting:
        return _hold(
            "Factors strongly conflict (roughly equal bullish and bearish weight) — "
            "no clear consensus.",
            factors=factors,
        )

    if score >= config.buy_threshold:
        action = "BUY"
    elif score <= config.sell_threshold:
        action = "SELL"
    else:
        action = "HOLD"

    confidence = round(abs(score), 4)
    entry_price = candles[-1].close

    try:
        atr_value = ind.atr(candles, config.atr_period)
    except InsufficientDataError:
        atr_value = entry_price * 0.01

    if action == "HOLD":
        stop_loss = entry_price
        take_profit = entry_price
        risk_reward = 0.0
        reasons = [f"{f.name}: {f.value}" for f in factors if abs(f.leaning) > 0.3] or [
            "No factor showed strong enough conviction for a directional call."
        ]
        eligible = False
        rejection_reason = "Composite score inside the HOLD band."
    else:
        direction = 1.0 if action == "BUY" else -1.0
        stop_distance = atr_value * config.stop_loss_atr_multiple
        target_distance = max(
            atr_value * config.take_profit_atr_multiple, stop_distance * config.min_risk_reward_ratio
        )

        stop_loss = entry_price - direction * stop_distance
        take_profit = entry_price + direction * target_distance
        risk_reward = target_distance / stop_distance if stop_distance else 0.0

        reasons = [f"{f.name}: {f.value}" for f in factors if abs(f.leaning) > 0.3]
        if not reasons:
            reasons = [f"{f.name}: {f.value}" for f in factors[:3]]

        mtf_factor = next((f for f in factors if f.name == "Multi-Timeframe Confirmation"), None)
        mtf_confirms = mtf_factor is not None and (
            (action == "BUY" and mtf_factor.leaning > 0) or (action == "SELL" and mtf_factor.leaning < 0)
        )

        eligible = (
            confidence >= config.min_confidence_for_auto_trade
            and risk_reward >= config.min_risk_reward_ratio
            and mtf_confirms
        )
        rejection_reason = None
        if not eligible:
            missing = []
            if confidence < config.min_confidence_for_auto_trade:
                missing.append(f"confidence {confidence:.0%} below {config.min_confidence_for_auto_trade:.0%}")
            if risk_reward < config.min_risk_reward_ratio:
                missing.append(f"risk/reward {risk_reward:.2f} below {config.min_risk_reward_ratio:.2f}")
            if not mtf_confirms:
                missing.append("multi-timeframe confirmation does not agree")
            rejection_reason = "Not eligible for auto-trade: " + "; ".join(missing) if missing else None

    return CompositeSignal(
        symbol=symbol,
        timeframe=primary_timeframe,
        action=action,
        confidence=confidence,
        score=round(score, 4),
        factors=factors,
        reasons=reasons,
        entry_price=entry_price,
        stop_loss=round(stop_loss, 8),
        take_profit=round(take_profit, 8),
        risk_reward_ratio=round(risk_reward, 4),
        generated_at=now,
        data_freshness_seconds=data_freshness_seconds,
        eligible_for_auto_trade=eligible,
        rejection_reason=rejection_reason,
    )
