"""Configurable weights and thresholds for the multi-factor signal
engine. Nothing in `composite.py` hardcodes a magic number — every
threshold that affects a BUY/SELL/HOLD decision lives here so it can be
tuned (and unit tested against) without touching scoring logic.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class FactorWeights:
    """Relative weights per factor. Values are normalized internally, so
    they don't need to sum to 1 — only their ratios matter."""

    ema_sma: float = 1.0
    rsi: float = 1.0
    macd: float = 1.2
    bollinger: float = 0.8
    volume: float = 0.8
    momentum: float = 1.0
    support_resistance: float = 0.9
    market_structure: float = 1.1
    volatility: float = 0.5  # informational modifier, low directional weight
    order_book_imbalance: float = 0.6
    btc_trend: float = 1.3  # market-wide confirmation gets extra weight
    multi_timeframe_agreement: float = 1.4  # confirmation across timeframes gets extra weight
    news_sentiment: float = 1.0


@dataclass(frozen=True)
class SignalEngineConfig:
    weights: FactorWeights = field(default_factory=FactorWeights)

    # Composite normalized score (-1..+1) thresholds for direction.
    buy_threshold: float = 0.25
    sell_threshold: float = -0.25

    # Minimum number of independent factors required before a signal can
    # be anything other than HOLD — never trade off one indicator.
    min_factors_for_directional_signal: int = 5

    # If the bullish-leaning weight and bearish-leaning weight are both
    # within this fraction of each other (and both material), factors
    # are considered "strongly conflicting" and the result is forced to
    # HOLD even if the net score would have cleared a threshold.
    conflict_ratio_threshold: float = 0.85
    conflict_min_magnitude: float = 0.15

    # Multi-timeframe confirmation: how many of the configured
    # timeframes must agree on direction for the multi-timeframe factor
    # to count as a confirming (rather than neutral/penalizing) input.
    timeframe_agreement_required: int = 2
    confirmation_timeframes: tuple[str, ...] = ("15m", "1h", "4h")

    # Risk/reward construction defaults (ATR multiples).
    atr_period: int = 14
    stop_loss_atr_multiple: float = 1.5
    take_profit_atr_multiple: float = 3.0
    min_risk_reward_ratio: float = 1.2

    # Data-quality gates.
    max_staleness_multiplier: float = 3.0  # candles older than N * interval => stale
    min_candles_required: int = 60  # enough history for the slowest indicator (MACD 26+9)

    # Confidence required before a signal is flagged eligible for
    # (future, paper-only in Phase 2) auto-execution.
    min_confidence_for_auto_trade: float = 0.65

    # Duplicate-signal / cooldown handling (paper-trading scope only —
    # live-order cooldown state lives in risk_engine/state_store.py).
    cooldown_seconds: int = 300
    duplicate_signal_window_seconds: int = 120


DEFAULT_CONFIG = SignalEngineConfig()
