# `binance_link.py` — removed in Phase 4.2

This model used to store a user's Binance `api_key` (plaintext, by
design — a key alone isn't secret) and `encrypted_api_secret` in this
backend's own database.

It was removed, not left unused, because the product requirement is
explicit: Binance API credentials must be entered and stored **only**
on the user's own device, and this backend must have **no** database
column, table, or code path capable of holding one — "encrypted at
rest" isn't sufficient when the real requirement is "never present
server-side at all."

See:
- `app/services/binance_service.py` — module docstring explains the
  device-local credential architecture this backend now assumes.
- `app/api/routers/binance_router.py` — the `/link` endpoint that used
  to accept a key/secret over HTTP was removed for the same reason.
- `lib/features/binance_connect/` — the Flutter feature that now owns
  credential entry and storage entirely on-device via
  `flutter_secure_storage`.
