import uuid
from datetime import datetime

from sqlalchemy import DateTime, JSON, String
from sqlalchemy.orm import Mapped, mapped_column

from ..db.session import Base


class AuditLogEntry(Base):
    """Append-only. Never updated or deleted by application code.

    Every privileged action writes here: order placed, order rejected by
    risk engine (with reason), settings changed, emergency stop
    triggered/cleared, Binance key linked/unlinked. This is what makes
    "why did the AI do that trade" answerable after the fact.
    """

    __tablename__ = "audit_log"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String, index=True)
    event_type: Mapped[str] = mapped_column(String, index=True)
    # e.g. "trade_opened", "trade_closed", "risk_block", "settings_updated",
    # "emergency_stop_triggered". Never "binance_link_created" or any
    # event whose payload could contain a credential — this backend
    # never holds a Binance API key/secret (Phase 4.2), so no audit
    # event here should ever carry one. If a future device-reported
    # permission-summary event is added, its payload must contain only
    # booleans/labels, never the key or secret itself.

    payload: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
