"""Tests for `orchestrator.run_backtest` — the top-level entry point
the API layer calls. Confirms the "REAL HISTORICAL VALIDATION BLOCKED"
contract holds end-to-end and that the explicit test-only synthetic
fallback never fires unless BOTH `allow_synthetic_fallback=True` AND
fixture data are supplied.
"""

from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timezone

from app.backtesting.fixtures import make_multi_timeframe_fixture
from app.backtesting.historical_data import HistoricalDataCache
from app.backtesting.orchestrator import (
    DATA_PROVENANCE_BLOCKED,
    DATA_PROVENANCE_SYNTHETIC_TEST_ONLY,
    run_backtest,
)
from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.pipeline import RiskLimits
from app.signal_engine.config import SignalEngineConfig


class OrchestratorBlockedPathTests(unittest.IsolatedAsyncioTestCase):
    async def test_default_call_reports_blocked_not_synthetic(self):
        """Without explicit opt-in, a caller who cannot reach Binance
        gets an honest BLOCKED outcome — never a silent synthetic
        substitution."""
        with tempfile.TemporaryDirectory() as tmp:
            outcome = await run_backtest(
                symbols=("BTCUSDT",),
                start=datetime(2024, 1, 1, tzinfo=timezone.utc),
                end=datetime(2024, 2, 1, tzinfo=timezone.utc),
                cache=HistoricalDataCache(tmp),
            )
        self.assertEqual(outcome.data_provenance, DATA_PROVENANCE_BLOCKED)
        self.assertFalse(outcome.real_data_used)
        self.assertIsNone(outcome.overall_report)
        self.assertIsNone(outcome.walk_forward_report)
        self.assertIsNone(outcome.final_oos_report)
        self.assertTrue(len(outcome.blocked_reasons) > 0)

    async def test_synthetic_fallback_without_data_still_blocks(self):
        """`allow_synthetic_fallback=True` alone (no fixture data
        supplied) must NOT produce a result — both conditions are
        required, so a caller can't accidentally enable the fallback
        path without also deliberately constructing fixtures."""
        with tempfile.TemporaryDirectory() as tmp:
            outcome = await run_backtest(
                symbols=("BTCUSDT",),
                start=datetime(2024, 1, 1, tzinfo=timezone.utc),
                end=datetime(2024, 2, 1, tzinfo=timezone.utc),
                cache=HistoricalDataCache(tmp),
                allow_synthetic_fallback=True,
                synthetic_candles_by_symbol_tf=None,
            )
        self.assertEqual(outcome.data_provenance, DATA_PROVENANCE_BLOCKED)


class OrchestratorSyntheticFallbackTests(unittest.IsolatedAsyncioTestCase):
    async def test_synthetic_fallback_produces_clearly_labeled_report(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        signal_config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        with tempfile.TemporaryDirectory() as tmp:
            outcome = await run_backtest(
                symbols=("BTCUSDT",),
                start=datetime(2024, 1, 1, tzinfo=timezone.utc),
                end=datetime(2024, 2, 1, tzinfo=timezone.utc),
                signal_config=signal_config, risk_limits=risk_limits, paper_config=paper_config,
                allow_synthetic_fallback=True,
                synthetic_candles_by_symbol_tf={"BTCUSDT": btc},
                cache=HistoricalDataCache(tmp),
                train_candles=200, validation_candles=80, test_candles=80,
            )
        self.assertEqual(outcome.data_provenance, DATA_PROVENANCE_SYNTHETIC_TEST_ONLY)
        self.assertFalse(outcome.real_data_used)
        self.assertIsNotNone(outcome.overall_report)
        self.assertFalse(outcome.overall_report.real_data_used)
        # The synthetic-data disclaimer must be present in the report.
        self.assertTrue(any("BLOCKED" in d for d in outcome.overall_report.disclaimers))
        self.assertIsNotNone(outcome.walk_forward_report)
        self.assertIsNotNone(outcome.final_oos_report)


if __name__ == "__main__":
    unittest.main()
