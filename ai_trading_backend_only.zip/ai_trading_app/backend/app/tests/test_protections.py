import unittest
from datetime import datetime, timedelta, timezone

from app.signal_engine.protections import CooldownTracker, DuplicateSignalGuard, is_data_stale


class FakeClock:
    """Injectable, manually-advanced clock — avoids real `time.sleep`
    calls so cooldown/duplicate-window tests run instantly and
    deterministically."""

    def __init__(self, start: datetime | None = None):
        self._now = start or datetime(2025, 1, 1, tzinfo=timezone.utc)

    def __call__(self) -> datetime:
        return self._now

    def advance(self, seconds: float) -> None:
        self._now += timedelta(seconds=seconds)


class StaleDataProtectionTests(unittest.TestCase):
    def test_none_freshness_is_stale(self):
        self.assertTrue(is_data_stale(None, max_allowed_seconds=60))

    def test_within_window_is_not_stale(self):
        self.assertFalse(is_data_stale(30, max_allowed_seconds=60))

    def test_beyond_window_is_stale(self):
        self.assertTrue(is_data_stale(120, max_allowed_seconds=60))

    def test_exactly_at_boundary_is_not_stale(self):
        self.assertFalse(is_data_stale(60, max_allowed_seconds=60))


class DuplicateSignalGuardTests(unittest.TestCase):
    def test_first_signal_is_never_a_duplicate(self):
        clock = FakeClock()
        guard = DuplicateSignalGuard(window_seconds=120, clock=clock)
        self.assertFalse(guard.is_duplicate("BTCUSDT", "BUY"))

    def test_same_direction_within_window_is_duplicate(self):
        clock = FakeClock()
        guard = DuplicateSignalGuard(window_seconds=120, clock=clock)
        guard.record("BTCUSDT", "BUY")
        clock.advance(30)
        self.assertTrue(guard.is_duplicate("BTCUSDT", "BUY"))

    def test_same_direction_after_window_is_not_duplicate(self):
        clock = FakeClock()
        guard = DuplicateSignalGuard(window_seconds=120, clock=clock)
        guard.record("BTCUSDT", "BUY")
        clock.advance(121)
        self.assertFalse(guard.is_duplicate("BTCUSDT", "BUY"))

    def test_opposite_direction_is_not_a_duplicate(self):
        clock = FakeClock()
        guard = DuplicateSignalGuard(window_seconds=120, clock=clock)
        guard.record("BTCUSDT", "BUY")
        clock.advance(5)
        self.assertFalse(guard.is_duplicate("BTCUSDT", "SELL"))

    def test_different_symbol_is_not_a_duplicate(self):
        clock = FakeClock()
        guard = DuplicateSignalGuard(window_seconds=120, clock=clock)
        guard.record("BTCUSDT", "BUY")
        clock.advance(5)
        self.assertFalse(guard.is_duplicate("ETHUSDT", "BUY"))

    def test_hold_is_never_recorded_or_flagged_duplicate(self):
        clock = FakeClock()
        guard = DuplicateSignalGuard(window_seconds=120, clock=clock)
        guard.record("BTCUSDT", "HOLD")
        self.assertFalse(guard.is_duplicate("BTCUSDT", "HOLD"))


class CooldownTrackerTests(unittest.TestCase):
    def test_no_signal_yet_means_no_cooldown(self):
        clock = FakeClock()
        tracker = CooldownTracker(cooldown_seconds=300, clock=clock)
        self.assertFalse(tracker.is_active("BTCUSDT"))
        self.assertEqual(tracker.remaining_seconds("BTCUSDT"), 0)

    def test_cooldown_active_immediately_after_signal(self):
        clock = FakeClock()
        tracker = CooldownTracker(cooldown_seconds=300, clock=clock)
        tracker.record("BTCUSDT", "BUY")
        self.assertTrue(tracker.is_active("BTCUSDT"))
        self.assertEqual(tracker.remaining_seconds("BTCUSDT"), 300)

    def test_cooldown_counts_down_and_expires(self):
        clock = FakeClock()
        tracker = CooldownTracker(cooldown_seconds=300, clock=clock)
        tracker.record("BTCUSDT", "SELL")

        clock.advance(299)
        self.assertTrue(tracker.is_active("BTCUSDT"))
        self.assertEqual(tracker.remaining_seconds("BTCUSDT"), 1)

        clock.advance(2)
        self.assertFalse(tracker.is_active("BTCUSDT"))
        self.assertEqual(tracker.remaining_seconds("BTCUSDT"), 0)

    def test_cooldown_blocks_opposite_direction_too(self):
        # Stricter than the duplicate guard on purpose: a BUY cooldown
        # also blocks an immediate SELL on the same symbol.
        clock = FakeClock()
        tracker = CooldownTracker(cooldown_seconds=300, clock=clock)
        tracker.record("BTCUSDT", "BUY")
        clock.advance(10)
        # SELL doesn't reset/check direction — is_active is symbol-scoped.
        self.assertTrue(tracker.is_active("BTCUSDT"))

    def test_cooldown_is_per_symbol(self):
        clock = FakeClock()
        tracker = CooldownTracker(cooldown_seconds=300, clock=clock)
        tracker.record("BTCUSDT", "BUY")
        self.assertFalse(tracker.is_active("ETHUSDT"))

    def test_hold_does_not_start_a_cooldown(self):
        clock = FakeClock()
        tracker = CooldownTracker(cooldown_seconds=300, clock=clock)
        tracker.record("BTCUSDT", "HOLD")
        self.assertFalse(tracker.is_active("BTCUSDT"))


if __name__ == "__main__":
    unittest.main()
