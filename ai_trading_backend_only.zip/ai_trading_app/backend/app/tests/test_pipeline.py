import asyncio
import os
import unittest
from datetime import datetime, timedelta, timezone

from app.paper_trading.engine import ExitReason
from app.paper_trading.models import PositionSide
from app.paper_trading.pipeline import RiskLimits, TradingPipeline
from app.tests.deterministic_dataset import multi_timeframe_dataset
from app.tests.paper_trading_fixtures import (
    FakeMarketDataService,
    build_paper_stack,
    build_signal_service,
    make_temp_db_path,
)


def _btc_uptrend_dataset():
    tf = multi_timeframe_dataset(symbol="BTCUSDT", trend_per_candle=5.0)
    price = tf["1h"][-1].close
    return tf, price


def _eth_uptrend_dataset():
    tf = multi_timeframe_dataset(symbol="ETHUSDT", trend_per_candle=5.0)
    price = tf["1h"][-1].close
    return tf, price


def _flat_dataset(symbol="BTCUSDT"):
    from app.tests.deterministic_dataset import make_flat_candles

    flat = make_flat_candles(symbol=symbol, count=120)
    return {"1h": flat, "15m": flat, "4h": flat}, flat[-1].close


class PipelineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db_path = make_temp_db_path()
        self.db, self.repo, self.engine, self.pm, self.paper_config = build_paper_stack(self.db_path)
        self.account = await self.repo.get_or_create_account(starting_balance=self.paper_config.starting_balance_usd)

        btc_tf, btc_price = _btc_uptrend_dataset()
        self.market_data = FakeMarketDataService({"BTCUSDT": btc_tf}, {"BTCUSDT": btc_price})
        self.signal_service = build_signal_service(self.market_data, lenient=True)

    async def asyncTearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def _pipeline(self, risk_limits: RiskLimits | None = None) -> TradingPipeline:
        return TradingPipeline(
            signal_service=self.signal_service,
            market_data=self.market_data,
            repository=self.repo,
            execution_engine=self.engine,
            position_manager=self.pm,
            paper_config=self.paper_config,
            risk_limits=risk_limits or RiskLimits(min_confidence=0.3, max_open_trades=5),
        )

    # --- Basic happy path ---

    async def test_strong_signal_opens_a_paper_position(self):
        pipeline = self._pipeline()
        signal = await pipeline.evaluate_symbol("BTCUSDT", "1h")
        self.assertEqual(signal.action, "BUY")

        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 1)
        self.assertEqual(open_positions[0].symbol, "BTCUSDT")

    async def test_hold_signal_does_nothing(self):
        flat_tf, flat_price = _flat_dataset()
        market_data = FakeMarketDataService({"BTCUSDT": flat_tf}, {"BTCUSDT": flat_price})
        signal_service = build_signal_service(market_data, lenient=True)
        pipeline = TradingPipeline(
            signal_service=signal_service, market_data=market_data, repository=self.repo,
            execution_engine=self.engine, position_manager=self.pm, paper_config=self.paper_config,
            risk_limits=RiskLimits(min_confidence=0.3, max_open_trades=5),
        )
        signal = await pipeline.evaluate_symbol("BTCUSDT", "1h")
        self.assertEqual(signal.action, "HOLD")
        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 0)

    async def test_signal_is_logged_regardless_of_outcome(self):
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        last_action = await self.repo.get_last_signal_action("BTCUSDT")
        self.assertEqual(last_action, "BUY")

    # --- Duplicate / concurrency protection ---

    async def test_repeated_evaluate_does_not_stack_positions(self):
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 1)

    async def test_concurrent_evaluate_same_symbol_opens_only_once(self):
        pipeline = self._pipeline()
        await asyncio.gather(*[pipeline.evaluate_symbol("BTCUSDT", "1h") for _ in range(8)])
        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 1)

    async def test_concurrent_evaluate_different_symbols_both_open(self):
        eth_tf, eth_price = _eth_uptrend_dataset()
        self.market_data._data["ETHUSDT"] = eth_tf
        self.market_data.symbols = self.market_data.symbols + ("ETHUSDT",)
        self.market_data.set_price("ETHUSDT", eth_price)

        pipeline = self._pipeline(RiskLimits(min_confidence=0.3, max_open_trades=5))
        await asyncio.gather(
            pipeline.evaluate_symbol("BTCUSDT", "1h"),
            pipeline.evaluate_symbol("ETHUSDT", "1h"),
        )
        open_positions = await self.repo.get_open_positions()
        self.assertEqual({p.symbol for p in open_positions}, {"BTCUSDT", "ETHUSDT"})

    # --- Risk engine integration ---

    async def test_max_open_trades_blocks_new_trade(self):
        eth_tf, eth_price = _eth_uptrend_dataset()
        self.market_data._data["ETHUSDT"] = eth_tf
        self.market_data.symbols = self.market_data.symbols + ("ETHUSDT",)
        self.market_data.set_price("ETHUSDT", eth_price)

        pipeline = self._pipeline(RiskLimits(min_confidence=0.3, max_open_trades=1))
        await pipeline.evaluate_symbol("BTCUSDT", "1h")  # fills the 1 slot
        await pipeline.evaluate_symbol("ETHUSDT", "1h")  # should be blocked

        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 1)
        self.assertEqual(open_positions[0].symbol, "BTCUSDT")

        events = await self.repo.get_recent_risk_events(limit=10)
        block_events = [e for e in events if e["event_type"] == "RISK_BLOCK" and e["symbol"] == "ETHUSDT"]
        self.assertEqual(len(block_events), 1)

    async def test_max_daily_trades_blocks_after_limit(self):
        eth_tf, eth_price = _eth_uptrend_dataset()
        self.market_data._data["ETHUSDT"] = eth_tf
        self.market_data.symbols = self.market_data.symbols + ("ETHUSDT",)
        self.market_data.set_price("ETHUSDT", eth_price)

        pipeline = self._pipeline(RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=1))
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        await pipeline.evaluate_symbol("ETHUSDT", "1h")

        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 1)

    async def test_daily_loss_limit_blocks_new_trades(self):
        # Simulate a prior realized loss today big enough to trip the
        # daily-loss gate, then confirm a new (otherwise-approved) trade
        # is rejected.
        from app.paper_trading.models import ExitReason, PositionSide

        losing_position = await self.engine.open_position(
            symbol="XRPUSDT", side=PositionSide.LONG, reference_price=1.0,
            stop_loss=0.9, take_profit=1.1, signal_id="loss1", signal_confidence=0.9,
            account_id=self.account.id,
        )
        await self.engine.close_position(losing_position, reference_price=0.5, exit_reason=ExitReason.STOP_LOSS)

        pipeline = self._pipeline(RiskLimits(min_confidence=0.3, max_open_trades=5, max_daily_loss_percent=1.0))
        await pipeline.evaluate_symbol("BTCUSDT", "1h")

        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 0)

        events = await self.repo.get_recent_risk_events(limit=10)
        block_events = [e for e in events if e["event_type"] == "RISK_BLOCK" and e["symbol"] == "BTCUSDT"]
        self.assertEqual(len(block_events), 1)
        self.assertTrue(any("loss" in r.lower() for r in block_events[0]["payload"]["reasons"]))

    async def test_emergency_stop_blocks_new_trades(self):
        await self.repo.set_flag("emergency_stop_active", True)
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")

        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 0)

    async def test_circuit_breaker_blocks_new_trades(self):
        await self.repo.set_flag("circuit_breaker_tripped", True)
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")

        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 0)

    async def test_cooldown_blocks_immediate_re_entry_after_close(self):
        pipeline = self._pipeline(RiskLimits(min_confidence=0.3, max_open_trades=5, cooldown_seconds=300))
        await pipeline.evaluate_symbol("BTCUSDT", "1h")

        position = (await self.repo.get_open_positions())[0]
        await self.engine.close_position(position, reference_price=position.entry_price * 1.02, exit_reason=ExitReason.TAKE_PROFIT)

        # Immediately try to re-enter the same symbol -- cooldown should block it.
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 0)

    # --- Position management integrated into the pipeline ---

    async def test_manage_all_open_positions_closes_on_tp(self):
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        position = (await self.repo.get_open_positions())[0]

        self.market_data.set_price("BTCUSDT", position.take_profit + 100)
        await pipeline.manage_all_open_positions()

        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 0)
        history = await self.repo.get_trade_history()
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0].exit_reason, ExitReason.TAKE_PROFIT)

    async def test_manage_all_open_positions_skips_symbol_with_price_failure(self):
        eth_tf, eth_price = _eth_uptrend_dataset()
        failing_market_data = FakeMarketDataService(
            {"BTCUSDT": self.market_data._data["BTCUSDT"], "ETHUSDT": eth_tf},
            {"BTCUSDT": 50_000.0, "ETHUSDT": eth_price},
        )
        signal_service = build_signal_service(failing_market_data, lenient=True)
        pipeline = TradingPipeline(
            signal_service=signal_service, market_data=failing_market_data, repository=self.repo,
            execution_engine=self.engine, position_manager=self.pm, paper_config=self.paper_config,
            risk_limits=RiskLimits(min_confidence=0.3, max_open_trades=5),
        )
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        self.assertEqual(len(await self.repo.get_open_positions()), 1)

        # Now make price fetches fail for BTCUSDT and confirm the
        # position simply stays open (not crashed, not closed at a
        # fabricated price).
        failing_market_data._fail_symbols = frozenset({"BTCUSDT"})
        await pipeline.manage_all_open_positions()
        self.assertEqual(len(await self.repo.get_open_positions()), 1)

    # --- Emergency stop trigger/clear via pipeline ---

    async def test_trigger_emergency_stop_persists_flag_and_closes_positions(self):
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        self.assertEqual(len(await self.repo.get_open_positions()), 1)

        closed_symbols = await pipeline.trigger_emergency_stop(close_positions=True)
        self.assertEqual(closed_symbols, ["BTCUSDT"])
        self.assertEqual(len(await self.repo.get_open_positions()), 0)
        self.assertTrue(await self.repo.get_flag("emergency_stop_active"))

    async def test_emergency_stop_without_closing_leaves_positions_open(self):
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")

        closed_symbols = await pipeline.trigger_emergency_stop(close_positions=False)
        self.assertEqual(closed_symbols, [])
        self.assertEqual(len(await self.repo.get_open_positions()), 1)
        self.assertTrue(await self.repo.get_flag("emergency_stop_active"))

    async def test_clear_emergency_stop_allows_trading_again(self):
        await self.repo.set_flag("emergency_stop_active", True)
        pipeline = self._pipeline()
        await pipeline.evaluate_symbol("BTCUSDT", "1h")
        self.assertEqual(len(await self.repo.get_open_positions()), 0)  # blocked

        pipeline2 = self._pipeline()
        await pipeline2.clear_emergency_stop()
        self.assertFalse(await self.repo.get_flag("emergency_stop_active"))

        await pipeline2.evaluate_symbol("BTCUSDT", "1h")
        self.assertEqual(len(await self.repo.get_open_positions()), 1)


if __name__ == "__main__":
    unittest.main()
