"""Phase 4.2 — credential-safety architecture tests.

These tests exist to make the security guarantees in the Phase 4.2
requirements MECHANICALLY enforced, not just documented in docstrings:
  - the backend has no code path that accepts a Binance API key/secret
  - live trading is hard-disabled by default with no remote enable path
  - `BinanceService` methods that would require a credential raise
    NotImplementedError rather than silently accepting one
  - no source file in the backend contains a hard-coded-looking secret
"""

from __future__ import annotations

import inspect
import pathlib
import re
import unittest

from app.core.config import get_settings
from app.services.binance_service import (
    BinanceAccountPermissions,
    BinancePermissionError,
    BinanceService,
)
from app.services.trading_orchestrator import (
    LiveTradingDisabledError,
    TradeProposal,
    TradingOrchestrator,
)


class LiveTradingHardDisabledTests(unittest.TestCase):
    def test_live_trading_enabled_defaults_to_false(self):
        self.assertFalse(get_settings().live_trading_enabled)

    def test_no_public_setter_exists_for_live_trading_enabled(self):
        """Settings is a frozen-by-convention config object populated
        only from the environment at startup — confirms there is no
        method on it (or anywhere else in core.config) that could flip
        this flag at runtime from request-handling code."""
        settings = get_settings()
        # Only environment variables can set this; there must be no
        # callable attribute suggesting a runtime setter.
        suspicious = [
            name for name in dir(settings)
            if "live_trading" in name.lower() and name != "live_trading_enabled"
        ]
        self.assertEqual(suspicious, [])


class OrchestratorRefusesWhenLiveTradingDisabledTests(unittest.IsolatedAsyncioTestCase):
    async def test_orchestrator_refuses_to_execute_when_live_trading_disabled(self):
        class _StubBinanceService(BinanceService):
            def __init__(self):
                super().__init__(use_testnet=True)

        orchestrator = TradingOrchestrator(binance_service=_StubBinanceService())
        proposal = TradeProposal(
            user_id="u1", symbol="BTCUSDT", action="BUY", signal_id="s1", signal_confidence=0.9,
            entry_price=50_000.0, stop_loss=49_000.0, take_profit=52_000.0, quantity=0.01,
            proposed_risk_percent=1.0,
        )
        from app.risk_engine.engine import RiskContext

        ctx = RiskContext(
            user_min_confidence=0.5, user_max_daily_loss_percent=5.0, user_max_risk_per_trade_percent=2.0,
            user_max_open_trades=5, user_max_trades_per_day=None, current_daily_loss_percent=0.0,
            current_daily_trades=0, current_open_trades=0, last_trade_at=None, cooldown_seconds=300,
            circuit_breaker_tripped=False, emergency_stop_active=False, signal_confidence=0.9,
            signal_data_freshness_seconds=0, max_allowed_data_staleness_seconds=300,
            proposed_risk_percent=1.0, duplicate_open_signal=False,
        )

        with self.assertRaises(LiveTradingDisabledError):
            await orchestrator.execute_if_approved(proposal, ctx)


class BinanceServiceNoCredentialSurfaceTests(unittest.TestCase):
    def test_constructor_accepts_no_api_key_or_secret_parameter(self):
        sig = inspect.signature(BinanceService.__init__)
        param_names = set(sig.parameters.keys())
        for forbidden in ("api_key", "api_secret", "apikey", "apisecret", "secret", "key"):
            self.assertNotIn(forbidden, param_names, f"BinanceService.__init__ must not accept '{forbidden}'")

    def test_constructor_only_accepts_use_testnet(self):
        sig = inspect.signature(BinanceService.__init__)
        param_names = [p for p in sig.parameters if p != "self"]
        self.assertEqual(param_names, ["use_testnet"])

    def test_authenticated_methods_raise_not_implemented_not_accept_credentials(self):
        """Every authenticated-Binance-action method must exist as an
        explicit NotImplementedError placeholder — never silently
        implemented in a way that would require this class to hold a
        credential."""
        service = BinanceService(use_testnet=True)
        authenticated_methods = [
            "fetch_account_permissions", "get_balance_usd", "get_symbol_filters",
            "place_order", "get_open_orders", "cancel_order",
        ]
        for name in authenticated_methods:
            self.assertTrue(hasattr(service, name), f"BinanceService.{name} should exist as a placeholder")

    def test_validate_key_is_safe_to_use_rejects_withdrawal_permission(self):
        import asyncio

        service = BinanceService(use_testnet=True)
        unsafe = BinanceAccountPermissions(can_trade=True, can_withdraw=True, can_deposit=False)
        with self.assertRaises(BinancePermissionError):
            asyncio.run(service.validate_key_is_safe_to_use(unsafe))

    def test_validate_key_is_safe_to_use_rejects_missing_trade_permission(self):
        import asyncio

        service = BinanceService(use_testnet=True)
        no_trade = BinanceAccountPermissions(can_trade=False, can_withdraw=False, can_deposit=False)
        with self.assertRaises(BinancePermissionError):
            asyncio.run(service.validate_key_is_safe_to_use(no_trade))

    def test_validate_key_is_safe_to_use_accepts_trade_only_key(self):
        import asyncio

        service = BinanceService(use_testnet=True)
        safe = BinanceAccountPermissions(can_trade=True, can_withdraw=False, can_deposit=False)
        result = asyncio.run(service.validate_key_is_safe_to_use(safe))
        self.assertEqual(result, safe)

    def test_validate_key_is_safe_to_use_takes_no_credential_argument(self):
        """The safety check must operate on an already-computed
        permission summary, never on a key/secret — confirms the
        signature has no credential-shaped parameter."""
        sig = inspect.signature(BinanceService.validate_key_is_safe_to_use)
        param_names = set(sig.parameters.keys())
        for forbidden in ("api_key", "api_secret", "apikey", "apisecret", "secret", "key"):
            self.assertNotIn(forbidden, param_names)


class BinanceServiceAuthenticatedMethodsRaiseTests(unittest.IsolatedAsyncioTestCase):
    async def test_fetch_account_permissions_raises_not_implemented(self):
        service = BinanceService(use_testnet=True)
        with self.assertRaises(NotImplementedError):
            await service.fetch_account_permissions()

    async def test_get_balance_usd_raises_not_implemented(self):
        service = BinanceService(use_testnet=True)
        with self.assertRaises(NotImplementedError):
            await service.get_balance_usd()

    async def test_place_order_raises_not_implemented(self):
        from app.services.binance_service import OrderRequest

        service = BinanceService(use_testnet=True)
        order = OrderRequest(symbol="BTCUSDT", side="BUY", quantity=0.01)
        with self.assertRaises(NotImplementedError):
            await service.place_order(order)

    async def test_get_open_orders_raises_not_implemented(self):
        service = BinanceService(use_testnet=True)
        with self.assertRaises(NotImplementedError):
            await service.get_open_orders()

    async def test_cancel_order_raises_not_implemented(self):
        service = BinanceService(use_testnet=True)
        with self.assertRaises(NotImplementedError):
            await service.cancel_order("BTCUSDT", "order123")


class NoCredentialAcceptingHttpSurfaceTests(unittest.TestCase):
    """Static checks over the actual router/schema source — confirms
    there is no request schema field or router parameter shaped like a
    credential anywhere in the API layer."""

    def test_binance_schemas_has_no_credential_field(self):
        backend_root = pathlib.Path(__file__).resolve().parents[2]
        source = (backend_root / "app" / "schemas" / "binance_schemas.py").read_text()
        forbidden_patterns = [r"api_key", r"api_secret", r"apiSecret", r"apiKey"]
        for pattern in forbidden_patterns:
            self.assertIsNone(
                re.search(pattern, source, re.IGNORECASE),
                f"binance_schemas.py must not reference '{pattern}'",
            )

    def test_binance_router_has_no_post_endpoint_accepting_credentials(self):
        backend_root = pathlib.Path(__file__).resolve().parents[2]
        source = (backend_root / "app" / "api" / "routers" / "binance_router.py").read_text()
        forbidden_patterns = [r"api_key", r"api_secret", r"LinkBinanceRequest"]
        for pattern in forbidden_patterns:
            self.assertIsNone(
                re.search(pattern, source, re.IGNORECASE),
                f"binance_router.py must not reference '{pattern}'",
            )

    def test_binance_link_model_file_does_not_exist(self):
        """The old server-side-stored-secret model must be gone, not
        just unused."""
        backend_root = pathlib.Path(__file__).resolve().parents[2]
        model_path = backend_root / "app" / "models" / "binance_link.py"
        self.assertFalse(model_path.exists(), "binance_link.py (server-held credential model) must be removed")


class NoHardcodedSecretsScanTests(unittest.TestCase):
    """Scans the backend source tree for anything that looks like a
    hard-coded Binance-shaped secret. This is a heuristic safety net,
    not a substitute for the architectural guarantee above (no code
    path accepts one in the first place) — but it catches accidental
    paste-ins during development that the architecture alone wouldn't."""

    # Binance API keys/secrets are 64-character alphanumeric strings.
    # We look for a 64-char run assigned to a suspiciously-named
    # variable, keeping the pattern narrow to avoid false positives on
    # things like SHA-256 hex digests used elsewhere in the codebase
    # (git commit hashes, content hashes) by requiring a credential-
    # shaped variable name immediately before it.
    _SUSPICIOUS_ASSIGNMENT = re.compile(
        r"(api_key|api_secret|binance_key|binance_secret)\s*=\s*[\"'][A-Za-z0-9]{40,}[\"']",
        re.IGNORECASE,
    )

    def test_no_hardcoded_looking_binance_credential_in_backend_source(self):
        backend_root = pathlib.Path(__file__).resolve().parents[2]
        offenders = []
        for path in backend_root.rglob("*.py"):
            if "__pycache__" in str(path) or "/tests/" in str(path):
                continue
            text = path.read_text(errors="ignore")
            if self._SUSPICIOUS_ASSIGNMENT.search(text):
                offenders.append(str(path))
        self.assertEqual(offenders, [], f"Possible hard-coded credential found in: {offenders}")


if __name__ == "__main__":
    unittest.main()
