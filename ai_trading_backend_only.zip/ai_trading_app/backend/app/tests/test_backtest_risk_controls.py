"""Risk controls, cooldown, and duplicate-protection tests within the
backtest replay path (Phase 4 spec item 8: "Risk controls", "Cooldown",
"Duplicate protection").

These confirm the exact same `risk_engine.evaluate_trade_proposal` gate
Phase 3 enforces live is ALSO enforced correctly against SIMULATED
historical time during a backtest — the specific correctness property
that required adding the optional `now` parameter to
`evaluate_trade_proposal` and the `now_fn` hooks to `TradingPipeline`/
`PaperExecutionEngine` (see those modules' docstrings for why the real
wall clock would have silently broken these exact checks).
"""

from __future__ import annotations

import unittest
from datetime import datetime, timezone

from app.backtesting.backtest_repository import BacktestRepository, DEFAULT_ACCOUNT_ID
from app.backtesting.clock import SimulatedClock
from app.backtesting.fixtures import make_multi_timeframe_fixture
from app.backtesting.replay_engine import run_multi_symbol_backtest
from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.pipeline import RiskLimits
from app.risk_engine.engine import RiskContext, evaluate_trade_proposal
from app.signal_engine.config import SignalEngineConfig


class RiskEngineSimulatedTimeTests(unittest.TestCase):
    """Directly exercises `evaluate_trade_proposal`'s `now` parameter —
    the mechanical fix that makes cooldown correct under replay."""

    def _base_ctx(self, **overrides) -> RiskContext:
        defaults = dict(
            user_min_confidence=0.5, user_max_daily_loss_percent=5.0, user_max_risk_per_trade_percent=2.0,
            user_max_open_trades=5, user_max_trades_per_day=None, current_daily_loss_percent=0.0,
            current_daily_trades=0, current_open_trades=0, last_trade_at=None, cooldown_seconds=300,
            circuit_breaker_tripped=False, emergency_stop_active=False, signal_confidence=0.8,
            signal_data_freshness_seconds=0, max_allowed_data_staleness_seconds=300,
            proposed_risk_percent=1.0, duplicate_open_signal=False,
        )
        defaults.update(overrides)
        return RiskContext(**defaults)

    def test_cooldown_evaluated_against_supplied_now_not_wall_clock(self):
        historical_now = datetime(2024, 1, 15, tzinfo=timezone.utc)
        last_trade_at = datetime(2024, 1, 15, tzinfo=timezone.utc) - __import__("datetime").timedelta(seconds=60)
        ctx = self._base_ctx(last_trade_at=last_trade_at, cooldown_seconds=300)

        # Cooldown should still be ACTIVE 60s after last_trade_at with a
        # 300s cooldown, when judged against the SAME historical instant.
        result = evaluate_trade_proposal(ctx, now=historical_now)
        self.assertFalse(result.approved)
        self.assertTrue(any("Cooldown active" in r for r in result.reasons))

        # If this had used the real wall clock instead (today, 2026),
        # "elapsed" would be measured in YEARS, and cooldown would
        # incorrectly never block anything historical.
        far_future_reasons_would_differ = evaluate_trade_proposal(ctx, now=historical_now + __import__("datetime").timedelta(seconds=301))
        self.assertTrue(far_future_reasons_would_differ.approved or "Cooldown active" not in " ".join(far_future_reasons_would_differ.reasons))

    def test_default_now_still_uses_wall_clock_for_backward_compatibility(self):
        """Phase 3's existing (live/paper) call sites never pass `now`
        — confirms omitting it still behaves exactly as before."""
        ctx = self._base_ctx(last_trade_at=None)
        result = evaluate_trade_proposal(ctx)  # no now= at all
        self.assertTrue(result.approved)


class BacktestCooldownEnforcementTests(unittest.IsolatedAsyncioTestCase):
    async def test_cooldown_blocks_immediate_reentry_after_close_in_backtest(self):
        """End-to-end: after a position closes during replay, the very
        next candle must NOT be allowed to immediately reopen a
        position for the same symbol while still inside the configured
        cooldown window — verified against the repository's actual
        recorded risk events, not just inferred from trade count."""
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        # Long cooldown relative to the 1h candle interval so it's
        # observable within this fixture's short series.
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None, cooldown_seconds=3600 * 6)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        trades = sorted(results["BTCUSDT"].trades, key=lambda t: t.position.opened_at)
        for i in range(1, len(trades)):
            gap = (trades[i].position.opened_at - trades[i - 1].position.closed_at).total_seconds()
            self.assertGreaterEqual(
                gap, risk_limits.cooldown_seconds,
                f"Trade {i} opened only {gap}s after trade {i-1} closed, cooldown={risk_limits.cooldown_seconds}s",
            )


class BacktestDuplicateProtectionTests(unittest.IsolatedAsyncioTestCase):
    async def test_duplicate_open_for_same_client_order_id_is_noop(self):
        """Same idempotency guarantee Phase 3 tests against SQLite,
        verified against `BacktestRepository`."""
        from app.paper_trading.engine import PaperExecutionEngine
        from app.paper_trading.models import PositionSide

        clock = SimulatedClock(start=datetime(2024, 1, 1, tzinfo=timezone.utc))
        repo = BacktestRepository(clock=clock)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        engine = PaperExecutionEngine(repository=repo, config=paper_config, now_fn=clock.now)
        await repo.get_or_create_account(starting_balance=paper_config.starting_balance_usd)

        first = await engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="dup-signal",
            signal_confidence=0.7, account_id=DEFAULT_ACCOUNT_ID,
        )
        second = await engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="dup-signal",
            signal_confidence=0.7, account_id=DEFAULT_ACCOUNT_ID,
        )
        self.assertIsNotNone(first)
        self.assertIsNone(second)  # idempotent no-op, same contract as PaperTradingRepository

        open_positions = await repo.get_open_positions(DEFAULT_ACCOUNT_ID)
        self.assertEqual(len(open_positions), 1)

    async def test_no_duplicate_open_position_for_same_symbol_across_full_replay(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        # Reconstruct: at every point in time, count concurrently open
        # positions for BTCUSDT — must never exceed 1.
        events = []
        for t in results["BTCUSDT"].trades:
            events.append((t.position.opened_at, 1))
            events.append((t.position.closed_at, -1))
        events.sort(key=lambda e: e[0])
        running = 0
        for _, delta in events:
            running += delta
            self.assertLessEqual(running, 1, "More than one concurrent open BTCUSDT position detected")


class BacktestRiskLimitEnforcementTests(unittest.IsolatedAsyncioTestCase):
    async def test_max_open_trades_never_exceeded_across_replay(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        eth = make_multi_timeframe_fixture(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.25, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=200.0)
        max_open = 1
        risk_limits = RiskLimits(min_confidence=0.25, max_open_trades=max_open, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc, "ETHUSDT": eth},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        all_trades = [t for res in results.values() for t in res.trades]
        events = []
        for t in all_trades:
            events.append((t.position.opened_at, 1))
            events.append((t.position.closed_at, -1))
        events.sort(key=lambda e: e[0])
        running = 0
        peak = 0
        for _, delta in events:
            running += delta
            peak = max(peak, running)
        self.assertLessEqual(peak, max_open, f"Peak concurrent open trades {peak} exceeded max_open_trades={max_open}")

    async def test_emergency_stop_blocks_all_new_trades_in_backtest(self):
        """Emergency stop set on the shared backtest repository before
        the replay begins must block every subsequent trade attempt —
        confirms the flag (read via `repo.get_flag`, same call the live
        pipeline makes) is honored identically under replay."""
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        clock = SimulatedClock()
        repo = BacktestRepository(clock=clock)
        await repo.set_flag("emergency_stop_active", True)

        from app.backtesting.replay_engine import BacktestRunner

        runner = BacktestRunner(
            symbol="BTCUSDT", primary_timeframe="1h", candles_by_tf=btc, btc_candles=btc.get("1h"),
            repository=repo, clock=clock, paper_config=paper_config, risk_limits=risk_limits,
            signal_config=config,
        )
        result = await runner.run()
        self.assertEqual(len(result.trades), 0, "Emergency stop should have blocked every trade attempt")


if __name__ == "__main__":
    unittest.main()
