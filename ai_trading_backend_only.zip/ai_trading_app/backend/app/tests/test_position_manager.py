import os
import unittest
from datetime import datetime, timedelta, timezone

from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.models import ExitReason, PositionSide
from app.paper_trading.position_manager import compute_trailing_stop, evaluate_exit
from app.tests.paper_trading_fixtures import build_paper_stack, make_temp_db_path


class PositionManagerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db_path = make_temp_db_path()
        self.config = PaperTradingConfig(
            starting_balance_usd=10_000.0,
            trade_amount_usd=500.0,
            trailing_stop_activation_percent=1.5,
            trailing_stop_distance_percent=1.0,
            max_holding_seconds=3600,
            early_exit_min_reversal_confidence=0.5,
        )
        self.db, self.repo, self.engine, self.pm, _ = build_paper_stack(self.db_path, paper_config=self.config)
        self.account = await self.repo.get_or_create_account(starting_balance=self.config.starting_balance_usd)

    async def asyncTearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    async def _open(self, symbol="BTCUSDT", side=PositionSide.LONG, entry=50_000.0, sl=49_000.0, tp=55_000.0, signal_id="s1"):
        return await self.engine.open_position(
            symbol=symbol, side=side, reference_price=entry, stop_loss=sl, take_profit=tp,
            signal_id=signal_id, signal_confidence=0.7, account_id=self.account.id,
        )

    # --- Take profit / stop loss ---

    async def test_take_profit_triggers_close(self):
        position = await self._open()
        result = await self.pm.manage_position(position, current_price=56_000.0)
        self.assertIsNotNone(result)
        self.assertEqual(result.exit_reason, ExitReason.TAKE_PROFIT)

    async def test_stop_loss_triggers_close(self):
        position = await self._open()
        result = await self.pm.manage_position(position, current_price=48_500.0)
        self.assertIsNotNone(result)
        self.assertEqual(result.exit_reason, ExitReason.STOP_LOSS)

    async def test_price_between_sl_and_tp_stays_open(self):
        position = await self._open()
        result = await self.pm.manage_position(position, current_price=50_100.0)
        self.assertIsNone(result)

    async def test_short_take_profit_direction_correct(self):
        position = await self._open(side=PositionSide.SHORT, entry=50_000.0, sl=51_000.0, tp=45_000.0)
        result = await self.pm.manage_position(position, current_price=44_000.0)
        self.assertEqual(result.exit_reason, ExitReason.TAKE_PROFIT)

    async def test_short_stop_loss_direction_correct(self):
        position = await self._open(side=PositionSide.SHORT, entry=50_000.0, sl=51_000.0, tp=45_000.0)
        result = await self.pm.manage_position(position, current_price=51_500.0)
        self.assertEqual(result.exit_reason, ExitReason.STOP_LOSS)

    async def test_stop_loss_checked_before_take_profit_when_both_could_apply(self):
        # Pathological SL/TP (SL above TP) shouldn't happen in practice,
        # but the priority order itself is what's under test: pure
        # function, no DB needed.
        from app.paper_trading.models import PaperPosition, PositionStatus

        position = PaperPosition(
            id="x", account_id="a", symbol="BTCUSDT", side=PositionSide.LONG,
            status=PositionStatus.OPEN, entry_price=100.0, quantity=1.0,
            stop_loss=100.0, take_profit=90.0,  # inverted on purpose
            entry_fee=0.0, signal_id="s", signal_confidence_at_entry=0.7,
            opened_at=datetime.now(timezone.utc), client_order_id="c1",
        )
        decision = evaluate_exit(
            position, current_price=95.0, now=datetime.now(timezone.utc),
            reversal_signal_action=None, reversal_signal_confidence=0.0, config=self.config,
        )
        self.assertEqual(decision.reason, ExitReason.STOP_LOSS)

    # --- Trailing stop ---

    async def test_trailing_stop_not_active_below_activation_threshold(self):
        position = await self._open()
        stop, active = compute_trailing_stop(position, 50_300.0, self.config)  # +0.6%, below 1.5% activation
        self.assertFalse(active)

    async def test_trailing_stop_activates_above_threshold(self):
        position = await self._open()
        stop, active = compute_trailing_stop(position, 50_800.0, self.config)  # +1.6%
        self.assertTrue(active)
        self.assertIsNotNone(stop)

    async def test_trailing_stop_ratchets_up_never_down_for_long(self):
        position = await self._open()
        stop1, _ = compute_trailing_stop(position, 51_000.0, self.config)
        position.trailing_stop_price = stop1
        position.trailing_stop_active = True
        stop2, _ = compute_trailing_stop(position, 52_000.0, self.config)
        self.assertGreater(stop2, stop1)
        position.trailing_stop_price = stop2  # simulate the manager persisting the ratcheted stop
        # Price pulls back but stays above the stop -- the stop must NOT retreat.
        stop3, _ = compute_trailing_stop(position, 51_500.0, self.config)
        self.assertEqual(stop3, stop2)

    async def test_trailing_stop_exit_closes_position(self):
        position = await self._open()
        await self.pm.manage_position(position, current_price=51_000.0)  # activates trailing stop
        updated = await self.repo.get_position(position.id)
        self.assertTrue(updated.trailing_stop_active)

        result = await self.pm.manage_position(updated, current_price=updated.trailing_stop_price - 1)
        self.assertIsNotNone(result)
        self.assertEqual(result.exit_reason, ExitReason.TRAILING_STOP)

    async def test_trailing_stop_for_short_moves_down_only(self):
        position = await self._open(side=PositionSide.SHORT, entry=50_000.0, sl=51_000.0, tp=40_000.0)
        stop1, _ = compute_trailing_stop(position, 49_000.0, self.config)  # price dropped 2%, favorable for short
        position.trailing_stop_price = stop1
        position.trailing_stop_active = True
        stop2, _ = compute_trailing_stop(position, 48_000.0, self.config)  # further favorable move
        self.assertLess(stop2, stop1)

    # --- Max holding time ---

    async def test_max_holding_time_triggers_close(self):
        position = await self._open()
        old_position = position.__class__(
            **{**position.__dict__, "opened_at": datetime.now(timezone.utc) - timedelta(hours=2)}
        )
        result = await self.pm.manage_position(old_position, current_price=50_100.0)
        self.assertIsNotNone(result)
        self.assertEqual(result.exit_reason, ExitReason.MAX_HOLDING_TIME)

    async def test_no_max_holding_time_when_unconfigured(self):
        no_limit_config = PaperTradingConfig(max_holding_seconds=None)
        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path, paper_config=no_limit_config)
        position = await engine2.open_position(
            symbol="ETHUSDT", side=PositionSide.LONG, reference_price=3000.0,
            stop_loss=2900.0, take_profit=3200.0, signal_id="sX", signal_confidence=0.7,
            account_id=self.account.id,
        )
        old_position = position.__class__(
            **{**position.__dict__, "opened_at": datetime.now(timezone.utc) - timedelta(days=30)}
        )
        result = await pm2.manage_position(old_position, current_price=3050.0)
        self.assertIsNone(result)

    # --- Early exit on signal reversal ---

    async def test_early_exit_on_strong_reversal(self):
        position = await self._open()
        result = await self.pm.manage_position(
            position, current_price=50_100.0, reversal_signal_action="SELL", reversal_signal_confidence=0.7
        )
        self.assertIsNotNone(result)
        self.assertEqual(result.exit_reason, ExitReason.EARLY_EXIT_SIGNAL_REVERSAL)

    async def test_no_early_exit_on_weak_reversal(self):
        position = await self._open()
        result = await self.pm.manage_position(
            position, current_price=50_100.0, reversal_signal_action="SELL", reversal_signal_confidence=0.1
        )
        self.assertIsNone(result)

    async def test_no_early_exit_when_signal_agrees_with_position(self):
        position = await self._open()  # LONG
        result = await self.pm.manage_position(
            position, current_price=50_100.0, reversal_signal_action="BUY", reversal_signal_confidence=0.9
        )
        self.assertIsNone(result)

    async def test_protective_exit_takes_priority_over_reversal(self):
        # Both a stop-loss AND a strong reversal are true simultaneously
        # -- stop loss must win (checked first).
        position = await self._open()
        result = await self.pm.manage_position(
            position, current_price=48_000.0, reversal_signal_action="SELL", reversal_signal_confidence=0.9
        )
        self.assertEqual(result.exit_reason, ExitReason.STOP_LOSS)

    # --- Never martingale / average down ---

    async def test_position_manager_never_increases_quantity(self):
        """No method on PositionManager accepts a quantity delta or
        'add to position' concept -- this is enforced by the API
        surface itself (there's no such method), verified here by
        confirming quantity is immutable across a full manage cycle."""
        position = await self._open()
        original_quantity = position.quantity
        await self.pm.manage_position(position, current_price=50_100.0)
        refreshed = await self.repo.get_position(position.id)
        self.assertEqual(refreshed.quantity, original_quantity)
        self.assertFalse(hasattr(self.pm, "average_down"))
        self.assertFalse(hasattr(self.pm, "add_to_position"))
        self.assertFalse(hasattr(self.pm, "increase_position"))

    # --- Emergency close all ---

    async def test_emergency_close_all_closes_every_open_position(self):
        await self._open(symbol="BTCUSDT", signal_id="s1")
        await self._open(symbol="ETHUSDT", entry=3000.0, sl=2900.0, tp=3200.0, signal_id="s2")

        closed = await self.pm.emergency_close_all(
            current_prices={"BTCUSDT": 50_500.0, "ETHUSDT": 3050.0}
        )
        self.assertEqual(len(closed), 2)
        for c in closed:
            self.assertEqual(c.exit_reason, ExitReason.EMERGENCY_STOP)

        remaining = await self.repo.get_open_positions()
        self.assertEqual(len(remaining), 0)

    async def test_emergency_close_skips_symbol_with_no_price_rather_than_fabricating_one(self):
        await self._open(symbol="BTCUSDT", signal_id="s1")
        await self._open(symbol="ETHUSDT", entry=3000.0, sl=2900.0, tp=3200.0, signal_id="s2")

        closed = await self.pm.emergency_close_all(current_prices={"BTCUSDT": 50_500.0})  # ETHUSDT missing

        self.assertEqual(len(closed), 1)
        self.assertEqual(closed[0].symbol, "BTCUSDT")

        remaining = await self.repo.get_open_positions()
        self.assertEqual(len(remaining), 1)
        self.assertEqual(remaining[0].symbol, "ETHUSDT")


if __name__ == "__main__":
    unittest.main()
