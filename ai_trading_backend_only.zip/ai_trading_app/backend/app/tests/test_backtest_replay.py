"""Chronological replay + no-look-ahead + indicator-timing tests
(Phase 4 spec item 8: "Chronological replay", "No future data",
"Indicator timing")."""

from __future__ import annotations

import unittest

from app.backtesting.clock import SimulatedClock
from app.backtesting.fixtures import make_multi_timeframe_fixture, make_simple_uptrend
from app.backtesting.replay_engine import ReplayMarketData, run_multi_symbol_backtest
from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.pipeline import RiskLimits
from app.signal_engine.config import SignalEngineConfig


class SimulatedClockTests(unittest.TestCase):
    def test_clock_cannot_move_backwards(self):
        from datetime import datetime, timedelta, timezone

        clock = SimulatedClock(start=datetime(2024, 1, 1, tzinfo=timezone.utc))
        clock.advance_to(datetime(2024, 1, 2, tzinfo=timezone.utc))
        with self.assertRaises(ValueError):
            clock.advance_to(datetime(2024, 1, 1, tzinfo=timezone.utc))

    def test_clock_requires_timezone_aware(self):
        from datetime import datetime

        clock = SimulatedClock()
        with self.assertRaises(ValueError):
            clock.advance_to(datetime(2024, 1, 1))  # naive datetime


class ReplayMarketDataNoLookAheadTests(unittest.IsolatedAsyncioTestCase):
    async def test_bounded_candles_never_include_future(self):
        candles = make_simple_uptrend(count=100)
        data = {"BTCUSDT": {"1h": candles}}
        md = ReplayMarketData(primary_timeframe="1h", candles_by_symbol_tf=data)

        md.advance("BTCUSDT", 49)  # "now" is candle index 49
        bounded = await md.get_candles("BTCUSDT", "1h")

        self.assertEqual(len(bounded), 50)  # indices 0..49 inclusive
        self.assertEqual(bounded[-1].close_time, candles[49].close_time)
        # Absolutely no candle after index 49 may appear.
        for c in bounded:
            self.assertLessEqual(c.close_time, candles[49].close_time)

    async def test_advancing_cursor_reveals_exactly_one_more_candle(self):
        candles = make_simple_uptrend(count=100)
        data = {"BTCUSDT": {"1h": candles}}
        md = ReplayMarketData(primary_timeframe="1h", candles_by_symbol_tf=data)

        md.advance("BTCUSDT", 10)
        first = await md.get_candles("BTCUSDT", "1h")
        md.advance("BTCUSDT", 11)
        second = await md.get_candles("BTCUSDT", "1h")

        self.assertEqual(len(second), len(first) + 1)
        self.assertEqual(second[:-1], first)

    async def test_multi_timeframe_bounded_by_primary_cursor_time(self):
        fixture = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        md = ReplayMarketData(primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": fixture})

        md.advance("BTCUSDT", 60)
        cutoff = fixture["1h"][60].close_time
        multi = await md.get_candles_multi_timeframe("BTCUSDT", ("15m", "1h", "4h"))
        for tf, series in multi.items():
            for c in series:
                self.assertLessEqual(
                    c.close_time, cutoff, f"{tf} candle at {c.close_time} leaks past cutoff {cutoff}"
                )

    async def test_get_price_never_a_future_price(self):
        candles = make_simple_uptrend(count=50)
        md = ReplayMarketData(primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": {"1h": candles}})
        md.advance("BTCUSDT", 20)
        price = await md.get_price("BTCUSDT")
        self.assertEqual(price, candles[20].close)


class ChronologicalReplayTests(unittest.IsolatedAsyncioTestCase):
    async def test_equity_curve_timestamps_strictly_non_decreasing(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        eth = make_multi_timeframe_fixture(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc, "ETHUSDT": eth},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        for symbol, result in results.items():
            timestamps = [ts for ts, _ in result.equity_curve]
            self.assertEqual(timestamps, sorted(timestamps), f"{symbol} equity curve timestamps not sorted")

    async def test_trades_open_before_they_close(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        eth = make_multi_timeframe_fixture(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc, "ETHUSDT": eth},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        any_trades = False
        for result in results.values():
            for trade in result.trades:
                any_trades = True
                p = trade.position
                self.assertIsNotNone(p.closed_at)
                self.assertLessEqual(p.opened_at, p.closed_at)
        self.assertTrue(any_trades, "test fixture produced zero trades — test is not exercising anything")

    async def test_trades_chronologically_ordered_in_result(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        eth = make_multi_timeframe_fixture(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc, "ETHUSDT": eth},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        for result in results.values():
            opened_times = [t.position.opened_at for t in result.trades]
            self.assertEqual(opened_times, sorted(opened_times))

    async def test_no_two_open_positions_same_symbol_simultaneously(self):
        """The pipeline enforces at most one open position per symbol —
        this test verifies that guarantee actually holds across an
        entire chronological replay, not just in isolated unit tests of
        the pipeline itself."""
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        trades = sorted(results["BTCUSDT"].trades, key=lambda t: t.position.opened_at)
        for i in range(1, len(trades)):
            prev_close = trades[i - 1].position.closed_at
            curr_open = trades[i].position.opened_at
            self.assertLessEqual(
                prev_close, curr_open,
                f"Trade {i} opened at {curr_open} before trade {i-1} closed at {prev_close}",
            )


class IndicatorTimingTests(unittest.IsolatedAsyncioTestCase):
    async def test_signal_at_index_only_uses_candles_up_to_index(self):
        """Directly verifies that `build_composite_signal` invoked
        through the replay's bounded market data at index N produces
        the identical result as calling it directly on
        candles[0:N+1] — i.e. the replay path adds no hidden extra
        (past OR future) data."""
        from app.signal_engine.composite import build_composite_signal
        from app.signal_engine.config import DEFAULT_CONFIG

        fixture = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        md = ReplayMarketData(primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": fixture})

        index = 130
        md.advance("BTCUSDT", index)
        bounded_multi = await md.get_candles_multi_timeframe("BTCUSDT", ("15m", "1h", "4h"))

        direct_signal = build_composite_signal(
            symbol="BTCUSDT", primary_timeframe="1h",
            candles_by_timeframe={tf: [c for c in series if c.close_time <= fixture["1h"][index].close_time] for tf, series in fixture.items()},
            config=DEFAULT_CONFIG,
        )
        replay_signal = build_composite_signal(
            symbol="BTCUSDT", primary_timeframe="1h", candles_by_timeframe=bounded_multi, config=DEFAULT_CONFIG,
        )
        self.assertEqual(direct_signal.action, replay_signal.action)
        self.assertEqual(direct_signal.score, replay_signal.score)


if __name__ == "__main__":
    unittest.main()
