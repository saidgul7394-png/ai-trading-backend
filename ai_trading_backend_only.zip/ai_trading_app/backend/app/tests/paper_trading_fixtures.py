"""Shared fixtures for Phase 3 paper-trading tests: a temp-file SQLite
database per test (never `:memory:`, so restart-recovery tests can
genuinely open a second, independent connection to the same file) and a
fake, deterministic `MarketDataService` double."""

from __future__ import annotations

import os
import tempfile

from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.db import Database
from app.paper_trading.engine import PaperExecutionEngine
from app.paper_trading.position_manager import PositionManager
from app.paper_trading.repository import PaperTradingRepository
from app.signal_engine.config import SignalEngineConfig
from app.signal_engine.service import SignalGenerationService


def make_temp_db_path() -> str:
    fd, path = tempfile.mkstemp(suffix=".sqlite3")
    os.close(fd)
    os.remove(path)  # Database() creates it fresh; we just want a unique path
    return path


class FakeMarketDataService:
    """Duck-typed stand-in for `services.market_data.service.MarketDataService`.
    Never generates a price itself — every value comes from the
    deterministic candle datasets the test passes in, matching the "no
    random/fake market data" rule even in test doubles."""

    def __init__(self, candles_by_symbol_tf: dict, prices: dict, *, fail_symbols: frozenset = frozenset()):
        self._data = candles_by_symbol_tf
        self.symbols = tuple(candles_by_symbol_tf.keys())
        self._prices = dict(prices)
        self._fail_symbols = fail_symbols

    async def ensure_fresh_or_backfill(self, symbol, interval):
        if symbol in self._fail_symbols:
            raise ConnectionError(f"simulated market-data failure for {symbol}")
        return None

    async def get_candles_multi_timeframe(self, symbol, intervals):
        return {tf: self._data.get(symbol, {}).get(tf, []) for tf in intervals}

    async def get_candles(self, symbol, interval, limit=None):
        return self._data.get(symbol, {}).get(interval, [])

    async def get_order_book(self, symbol, depth=20):
        raise RuntimeError("order book not available in fake")

    async def freshness_seconds(self, symbol, interval):
        return 15

    async def get_price(self, symbol):
        if symbol in self._fail_symbols:
            raise ConnectionError(f"simulated price fetch failure for {symbol}")
        return self._prices[symbol]

    def set_price(self, symbol: str, price: float) -> None:
        self._prices[symbol] = price


def build_signal_service(market_data: FakeMarketDataService, *, lenient: bool = True) -> SignalGenerationService:
    config = (
        SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        if lenient
        else SignalEngineConfig()
    )
    return SignalGenerationService(market_data=market_data, config=config)


def build_paper_stack(db_path: str, *, paper_config: PaperTradingConfig | None = None):
    """Returns (db, repo, engine, position_manager, config) wired
    together against a fresh SQLite file at db_path."""
    config = paper_config or PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
    db = Database(db_path)
    repo = PaperTradingRepository(db)
    engine = PaperExecutionEngine(repository=repo, config=config)
    position_manager = PositionManager(repository=repo, engine=engine, config=config)
    return db, repo, engine, position_manager, config
