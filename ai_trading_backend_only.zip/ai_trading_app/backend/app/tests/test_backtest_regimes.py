"""Tests for `regimes.py` — regime classification correctness and its
own no-look-ahead property (a regime label at index i must never
depend on candle i+1 or later)."""

from __future__ import annotations

import unittest

from app.backtesting.fixtures import make_multi_regime_symbol_series, make_multi_timeframe_fixture
from app.backtesting.regimes import ALL_REGIME_KEYS, label_regimes, regime_keys_for_label


class RegimeClassificationTests(unittest.TestCase):
    def test_all_seven_required_regime_keys_are_reachable(self):
        """Item 3 requires exactly these seven regimes to be testable
        separately — confirms the fixture + classifier combination
        actually produces every one of them at least once."""
        eth = make_multi_regime_symbol_series(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        btc = make_multi_regime_symbol_series(symbol="BTCUSDT", base_price=40_000.0, segment_length=150)
        labels = label_regimes(eth, btc_candles=btc)

        seen = set()
        for label in labels:
            seen.update(regime_keys_for_label(label))

        for key in ALL_REGIME_KEYS:
            self.assertIn(key, seen, f"Regime '{key}' was never produced by the fixture — cannot be tested")

    def test_bull_segment_classified_as_bull(self):
        candles = make_multi_regime_symbol_series(segment_length=150)
        labels = label_regimes(candles)
        # Bull segment is candles[0:150]; check deep into it (past the
        # 30-candle lookback warmup).
        for i in range(60, 150):
            self.assertEqual(labels[i].trend, "bull", f"index {i} in the bull segment classified as {labels[i].trend}")

    def test_bear_segment_classified_as_bear(self):
        candles = make_multi_regime_symbol_series(segment_length=150)
        labels = label_regimes(candles)
        # Bear segment is candles[300:450].
        for i in range(360, 450):
            self.assertEqual(labels[i].trend, "bear", f"index {i} in the bear segment classified as {labels[i].trend}")

    def test_sideways_segment_classified_as_sideways(self):
        candles = make_multi_regime_symbol_series(segment_length=150)
        labels = label_regimes(candles)
        # Sideways segment is candles[150:300].
        for i in range(210, 300):
            self.assertEqual(labels[i].trend, "sideways", f"index {i} in the sideways segment classified as {labels[i].trend}")

    def test_early_candles_are_unknown_not_fabricated(self):
        candles = make_multi_regime_symbol_series(segment_length=150)
        labels = label_regimes(candles)
        # First 29 candles: not enough history for a 30-candle lookback.
        for i in range(29):
            self.assertEqual(labels[i].trend, "unknown")


class RegimeNoLookAheadTests(unittest.TestCase):
    def test_label_at_index_unaffected_by_truncating_series_after_it(self):
        """The defining no-look-ahead property: computing labels on the
        FULL series and on a series truncated right after index i must
        produce the identical label at index i."""
        candles = make_multi_regime_symbol_series(segment_length=150)
        full_labels = label_regimes(candles)

        check_index = 200
        truncated = candles[: check_index + 1]
        truncated_labels = label_regimes(truncated)

        self.assertEqual(full_labels[check_index], truncated_labels[check_index])

    def test_btc_trend_label_unaffected_by_future_btc_candles(self):
        eth = make_multi_regime_symbol_series(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        btc = make_multi_regime_symbol_series(symbol="BTCUSDT", base_price=40_000.0, segment_length=150)

        full_labels = label_regimes(eth, btc_candles=btc)

        check_index = 100
        truncated_btc = btc[: check_index + 1]
        truncated_eth = eth[: check_index + 1]
        truncated_labels = label_regimes(truncated_eth, btc_candles=truncated_btc)

        self.assertEqual(full_labels[check_index].btc_trend, truncated_labels[check_index].btc_trend)


if __name__ == "__main__":
    unittest.main()
