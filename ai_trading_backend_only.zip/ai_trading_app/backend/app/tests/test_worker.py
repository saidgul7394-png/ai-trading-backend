import asyncio
import os
import unittest

from app.paper_trading.pipeline import RiskLimits, TradingPipeline
from app.paper_trading.worker import BackgroundWorker
from app.tests.deterministic_dataset import multi_timeframe_dataset
from app.tests.paper_trading_fixtures import (
    FakeMarketDataService,
    build_paper_stack,
    build_signal_service,
    make_temp_db_path,
)


class WorkerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db_path = make_temp_db_path()
        self.db, self.repo, self.engine, self.pm, self.paper_config = build_paper_stack(self.db_path)
        self.account = await self.repo.get_or_create_account(starting_balance=self.paper_config.starting_balance_usd)

        btc_tf = multi_timeframe_dataset(symbol="BTCUSDT", trend_per_candle=5.0)
        eth_tf = multi_timeframe_dataset(symbol="ETHUSDT", trend_per_candle=5.0)
        self.prices = {"BTCUSDT": btc_tf["1h"][-1].close, "ETHUSDT": eth_tf["1h"][-1].close}
        self.market_data = FakeMarketDataService(
            {"BTCUSDT": btc_tf, "ETHUSDT": eth_tf}, self.prices, fail_symbols=frozenset({"ETHUSDT"})
        )
        self.signal_service = build_signal_service(self.market_data, lenient=True)
        self.pipeline = TradingPipeline(
            signal_service=self.signal_service, market_data=self.market_data, repository=self.repo,
            execution_engine=self.engine, position_manager=self.pm, paper_config=self.paper_config,
            risk_limits=RiskLimits(min_confidence=0.3, max_open_trades=5),
        )
        self.worker = BackgroundWorker(
            pipeline=self.pipeline, repository=self.repo, symbols=("BTCUSDT", "ETHUSDT"), interval_seconds=30
        )

    async def asyncTearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    async def test_run_once_evaluates_all_symbols(self):
        result = await self.worker.run_once()
        evaluated_symbols = {r["symbol"] for r in result["symbols_evaluated"]}
        self.assertIn("BTCUSDT", evaluated_symbols)

    async def test_one_symbol_failure_does_not_block_others(self):
        result = await self.worker.run_once()
        self.assertEqual(len(result["symbols_evaluated"]), 1)
        self.assertEqual(result["symbols_evaluated"][0]["symbol"], "BTCUSDT")
        self.assertEqual(len(result["symbols_failed"]), 1)
        self.assertEqual(result["symbols_failed"][0]["symbol"], "ETHUSDT")

    async def test_failed_symbol_never_opens_a_position(self):
        await self.worker.run_once()
        open_positions = await self.repo.get_open_positions()
        self.assertTrue(all(p.symbol != "ETHUSDT" for p in open_positions))

    async def test_successful_symbol_still_opens_a_position(self):
        await self.worker.run_once()
        open_positions = await self.repo.get_open_positions()
        self.assertTrue(any(p.symbol == "BTCUSDT" for p in open_positions))

    async def test_emergency_stop_prevents_new_evaluation_but_reports_state(self):
        await self.repo.set_flag("emergency_stop_active", True)
        result = await self.worker.run_once()
        self.assertTrue(result["emergency_stop_active"])
        self.assertEqual(result["symbols_evaluated"], [])
        self.assertEqual(result["symbols_failed"], [])

    async def test_position_management_runs_even_during_emergency_stop(self):
        # Open a position first (before emergency stop), then verify a
        # subsequent cycle with emergency stop active still manages
        # (e.g. could still hit its own SL/TP) rather than freezing it
        # unmanaged and unmonitored.
        await self.pipeline.evaluate_symbol("BTCUSDT", "1h")
        position = (await self.repo.get_open_positions())[0]

        await self.repo.set_flag("emergency_stop_active", True)
        self.market_data.set_price("BTCUSDT", position.take_profit + 1)

        await self.worker.run_once()
        remaining = await self.repo.get_open_positions()
        self.assertEqual(len(remaining), 0)  # TP still fired despite emergency stop

    async def test_heartbeat_records_success(self):
        await self.worker.run_once()
        # run_once() alone doesn't touch the heartbeat -- only the
        # _run_forever loop does. Verify that path directly.
        self.worker._interval_seconds = 0.02
        self.worker.start()
        await asyncio.sleep(0.1)
        await self.worker.stop()
        heartbeat = await self.repo.get_worker_heartbeat()
        self.assertGreater(heartbeat["total_cycles"], 0)

    async def test_worker_survives_full_cycle_exception_and_keeps_looping(self):
        # Use a worker scoped to only the always-succeeding symbol, so
        # the ONLY failure in this test is the injected transient one —
        # isolates "worker recovers from a crash" from "worker correctly
        # reports an expected per-symbol failure" (covered separately
        # above).
        clean_worker = BackgroundWorker(
            pipeline=self.pipeline, repository=self.repo, symbols=("BTCUSDT",), interval_seconds=0.02
        )
        call_count = {"n": 0}
        orig_get_flag = self.repo.get_flag

        async def flaky_get_flag(key):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise RuntimeError("simulated transient failure")
            return await orig_get_flag(key)

        self.repo.get_flag = flaky_get_flag

        clean_worker.start()
        await asyncio.sleep(0.15)
        await clean_worker.stop()
        self.repo.get_flag = orig_get_flag

        heartbeat = await self.repo.get_worker_heartbeat()
        self.assertGreaterEqual(heartbeat["total_cycles"], 2)
        # The failure was transient -- later cycles succeeded, so the
        # heartbeat should show recovery (0 consecutive failures), not a
        # permanently wedged state.
        self.assertEqual(heartbeat["consecutive_failures"], 0)

    async def test_partial_symbol_failure_is_recorded_in_heartbeat(self):
        self.worker._interval_seconds = 0.02
        self.worker.start()
        await asyncio.sleep(0.05)
        await self.worker.stop()

        heartbeat = await self.repo.get_worker_heartbeat()
        # ETHUSDT fails every cycle in this fixture, so the heartbeat
        # should reflect that as a recorded failure, not silently report
        # success while a symbol is broken.
        self.assertIsNotNone(heartbeat["last_error"])

    async def test_start_is_idempotent(self):
        self.worker.start()
        first_task = self.worker._task
        self.worker.start()  # calling again should be a no-op
        self.assertIs(self.worker._task, first_task)
        await self.worker.stop()

    async def test_stop_before_start_does_not_raise(self):
        fresh_worker = BackgroundWorker(
            pipeline=self.pipeline, repository=self.repo, symbols=("BTCUSDT",), interval_seconds=30
        )
        await fresh_worker.stop()  # should not raise

    async def test_is_running_reflects_state(self):
        self.assertFalse(self.worker.is_running)
        self.worker._interval_seconds = 1
        self.worker.start()
        self.assertTrue(self.worker.is_running)
        await self.worker.stop()
        self.assertFalse(self.worker.is_running)


if __name__ == "__main__":
    unittest.main()
