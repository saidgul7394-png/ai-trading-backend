import unittest
from datetime import datetime, timedelta, timezone

from app.services.market_data.models import (
    Candle,
    MalformedDataError,
    UnsupportedIntervalError,
    UnsupportedSymbolError,
    validate_interval,
    validate_symbol,
)

BASE = datetime(2025, 1, 1, tzinfo=timezone.utc)


def _valid_kwargs(**overrides):
    kwargs = dict(
        symbol="BTCUSDT",
        interval="1h",
        open_time=BASE,
        close_time=BASE + timedelta(hours=1),
        open=100.0,
        high=105.0,
        low=95.0,
        close=102.0,
        volume=10.0,
    )
    kwargs.update(overrides)
    return kwargs


class CandleValidationTests(unittest.TestCase):
    def test_valid_candle_constructs(self):
        candle = Candle(**_valid_kwargs())
        self.assertEqual(candle.close, 102.0)

    def test_high_below_low_rejected(self):
        with self.assertRaises(MalformedDataError):
            Candle(**_valid_kwargs(high=90.0, low=95.0))

    def test_open_outside_range_rejected(self):
        with self.assertRaises(MalformedDataError):
            Candle(**_valid_kwargs(open=200.0))  # above high

    def test_close_outside_range_rejected(self):
        with self.assertRaises(MalformedDataError):
            Candle(**_valid_kwargs(close=0.5))  # below low

    def test_negative_price_rejected(self):
        with self.assertRaises(MalformedDataError):
            Candle(**_valid_kwargs(open=-1.0, high=10, low=-2, close=5))

    def test_zero_price_rejected(self):
        with self.assertRaises(MalformedDataError):
            Candle(**_valid_kwargs(open=0.0, low=0.0))

    def test_negative_volume_rejected(self):
        with self.assertRaises(MalformedDataError):
            Candle(**_valid_kwargs(volume=-5.0))

    def test_close_time_before_open_time_rejected(self):
        with self.assertRaises(MalformedDataError):
            Candle(**_valid_kwargs(close_time=BASE - timedelta(minutes=1)))

    def test_typical_price_and_range_helpers(self):
        candle = Candle(**_valid_kwargs())
        self.assertAlmostEqual(candle.typical_price, (105.0 + 95.0 + 102.0) / 3.0)
        self.assertAlmostEqual(candle.range, 10.0)
        self.assertTrue(candle.is_bullish)  # close(102) > open(100)


class SymbolIntervalValidationTests(unittest.TestCase):
    def test_valid_symbol_normalized(self):
        self.assertEqual(validate_symbol("btcusdt", ("BTCUSDT",)), "BTCUSDT")

    def test_unlisted_symbol_rejected(self):
        with self.assertRaises(UnsupportedSymbolError):
            validate_symbol("DOGEUSDT", ("BTCUSDT", "ETHUSDT"))

    def test_valid_interval_passes(self):
        for interval in ("1m", "5m", "15m", "1h", "4h", "1d"):
            self.assertEqual(validate_interval(interval), interval)

    def test_invalid_interval_rejected(self):
        with self.assertRaises(UnsupportedIntervalError):
            validate_interval("3h")


if __name__ == "__main__":
    unittest.main()
