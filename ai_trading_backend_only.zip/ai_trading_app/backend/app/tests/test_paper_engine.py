import os
import unittest

from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.engine import PaperExecutionError
from app.paper_trading.models import ExitReason, PositionSide
from app.tests.paper_trading_fixtures import build_paper_stack, make_temp_db_path


class PaperEngineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db_path = make_temp_db_path()
        self.db, self.repo, self.engine, self.pm, self.config = build_paper_stack(self.db_path)
        self.account = await self.repo.get_or_create_account(starting_balance=self.config.starting_balance_usd)

    async def asyncTearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    async def test_open_position_uses_real_reference_price_not_fabricated(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        # Fill price must be derived from (near) the supplied reference
        # price -- never some other/random value.
        self.assertAlmostEqual(position.entry_price, 50_000.0, delta=50_000.0 * 0.01)

    async def test_buy_slippage_always_works_against_trader(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        self.assertGreater(position.entry_price, 50_000.0)  # buy fills higher

    async def test_short_entry_slippage_also_against_trader(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.SHORT, reference_price=50_000.0,
            stop_loss=51_000.0, take_profit=45_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        # SHORT entry = a SELL order -> fills lower (against the trader).
        self.assertLess(position.entry_price, 50_000.0)

    async def test_fee_is_proportional_to_notional(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        notional = position.entry_price * position.quantity
        self.assertAlmostEqual(position.entry_fee, notional * self.config.fee_rate, delta=0.01)

    async def test_position_size_from_trade_amount(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        notional = position.entry_price * position.quantity
        self.assertAlmostEqual(notional, self.config.trade_amount_usd, delta=1.0)

    async def test_balance_reserved_on_open(self):
        before = await self.repo.get_account()
        await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        after = await self.repo.get_account()
        self.assertLess(after.current_balance, before.current_balance)

    async def test_insufficient_balance_raises_and_never_opens(self):
        huge_config = PaperTradingConfig(trade_amount_usd=1_000_000.0)
        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path, paper_config=huge_config)
        with self.assertRaises(PaperExecutionError):
            await engine2.open_position(
                symbol="ETHUSDT", side=PositionSide.LONG, reference_price=3_000.0,
                stop_loss=2_900.0, take_profit=3_200.0, signal_id="s2", signal_confidence=0.7,
                account_id=self.account.id,
            )
        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 0)

    async def test_duplicate_open_is_idempotent_no_op(self):
        first = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        second = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        self.assertIsNotNone(first)
        self.assertIsNone(second)
        open_positions = await self.repo.get_open_positions()
        self.assertEqual(len(open_positions), 1)

    async def test_close_position_realized_pnl_accounts_for_fees_and_slippage(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        closed = await self.engine.close_position(
            position, reference_price=55_000.0, exit_reason=ExitReason.TAKE_PROFIT
        )
        gross = (closed.exit_price - position.entry_price) * position.quantity
        # Realized P&L must be strictly less than the gross move (fees +
        # slippage eat into it) -- never equal to a "frictionless" P&L.
        self.assertLess(closed.realized_pnl, gross)
        self.assertGreater(closed.realized_pnl, 0)  # still profitable overall

    async def test_close_position_short_pnl_sign_correct(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.SHORT, reference_price=50_000.0,
            stop_loss=51_000.0, take_profit=45_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        # Price drops -- a profitable move for a SHORT.
        closed = await self.engine.close_position(
            position, reference_price=45_000.0, exit_reason=ExitReason.TAKE_PROFIT
        )
        self.assertGreater(closed.realized_pnl, 0)

    async def test_losing_trade_produces_negative_pnl(self):
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        closed = await self.engine.close_position(
            position, reference_price=49_000.0, exit_reason=ExitReason.STOP_LOSS
        )
        self.assertLess(closed.realized_pnl, 0)

    async def test_balance_returned_plus_pnl_on_close(self):
        before = await self.repo.get_account()
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        after_open = await self.repo.get_account()
        self.assertLess(after_open.current_balance, before.current_balance)

        closed = await self.engine.close_position(
            position, reference_price=55_000.0, exit_reason=ExitReason.TAKE_PROFIT
        )
        after_close = await self.repo.get_account()
        # Balance should be roughly starting balance + realized P&L.
        self.assertAlmostEqual(
            after_close.current_balance, before.current_balance + closed.realized_pnl, delta=0.01
        )

    async def test_concurrent_close_only_one_wins(self):
        import asyncio

        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=self.account.id,
        )
        results = await asyncio.gather(
            self.engine.close_position(position, reference_price=55_000.0, exit_reason=ExitReason.TAKE_PROFIT),
            self.engine.close_position(position, reference_price=55_000.0, exit_reason=ExitReason.TAKE_PROFIT),
            self.engine.close_position(position, reference_price=55_000.0, exit_reason=ExitReason.TAKE_PROFIT),
        )
        winners = [r for r in results if r is not None]
        self.assertEqual(len(winners), 1)

    async def test_never_fabricates_a_price_beyond_slippage_bound(self):
        """Regression guard: the fill price must always be within a
        small, config-bounded distance of the real reference price --
        never an arbitrary/random value."""
        reference = 12345.6789
        position = await self.engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=reference,
            stop_loss=reference * 0.98, take_profit=reference * 1.05, signal_id="s1",
            signal_confidence=0.7, account_id=self.account.id,
        )
        max_expected_deviation = reference * (self.config.slippage_fraction * 2)  # generous bound
        self.assertLessEqual(abs(position.entry_price - reference), max_expected_deviation)


if __name__ == "__main__":
    unittest.main()
