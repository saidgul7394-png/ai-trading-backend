"""Fees/slippage arithmetic and TP/SL/trailing-stop/early-exit
correctness within the backtest replay path (Phase 4 spec item 8:
"Fees/slippage", "TP/SL/trailing/early exits", "Position sizing").

These tests exercise the backtest-specific INTRABAR exit-checking
logic added in `replay_engine._check_intrabar_exit` (the one piece of
genuinely new trading logic in Phase 4 — everything else reuses Phase
3's engine/position_manager unmodified), plus confirm the unmodified
`PaperExecutionEngine` fee/slippage math produces identical results
whether called directly or through a backtest replay.
"""

from __future__ import annotations

import unittest
from datetime import datetime, timedelta, timezone

from app.backtesting.backtest_repository import BacktestRepository, DEFAULT_ACCOUNT_ID
from app.backtesting.clock import SimulatedClock
from app.backtesting.fixtures import make_multi_timeframe_fixture, make_simple_uptrend
from app.backtesting.replay_engine import _check_intrabar_exit, run_multi_symbol_backtest
from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.engine import PaperExecutionEngine
from app.paper_trading.models import ExitReason, PaperPosition, PositionSide, PositionStatus
from app.paper_trading.pipeline import RiskLimits
from app.services.market_data.models import Candle
from app.signal_engine.config import SignalEngineConfig


def _candle(open_, high, low, close, *, symbol="BTCUSDT", interval="1h", t=None):
    t = t or datetime(2024, 1, 1, tzinfo=timezone.utc)
    return Candle(
        symbol=symbol, interval=interval, open_time=t, close_time=t + timedelta(hours=1),
        open=open_, high=high, low=low, close=close, volume=100.0, is_closed=True,
    )


def _make_position(*, side=PositionSide.LONG, entry=100.0, stop=95.0, tp=110.0, trailing_price=None, trailing_active=False):
    return PaperPosition(
        id="p1", account_id=DEFAULT_ACCOUNT_ID, symbol="BTCUSDT", side=side, status=PositionStatus.OPEN,
        entry_price=entry, quantity=1.0, stop_loss=stop, take_profit=tp, entry_fee=0.1,
        signal_id="s1", signal_confidence_at_entry=0.7, opened_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
        client_order_id="c1", trailing_stop_price=trailing_price, trailing_stop_active=trailing_active,
    )


class IntrabarExitLogicTests(unittest.TestCase):
    """Pure-function tests for `_check_intrabar_exit` — no DB, no
    asyncio, just the decision function itself."""

    def setUp(self):
        self.config = PaperTradingConfig()

    def test_long_stop_loss_hit_by_low(self):
        position = _make_position(side=PositionSide.LONG, entry=100.0, stop=95.0, tp=110.0)
        candle = _candle(open_=98.0, high=99.0, low=94.0, close=97.0)  # low pierces stop
        self.assertEqual(_check_intrabar_exit(position, candle, self.config), ExitReason.STOP_LOSS)

    def test_long_stop_loss_not_hit_when_low_above_stop(self):
        position = _make_position(side=PositionSide.LONG, entry=100.0, stop=95.0, tp=110.0)
        candle = _candle(open_=98.0, high=99.0, low=96.0, close=97.0)  # low stays above stop
        self.assertIsNone(_check_intrabar_exit(position, candle, self.config))

    def test_short_stop_loss_hit_by_high(self):
        position = _make_position(side=PositionSide.SHORT, entry=100.0, stop=105.0, tp=90.0)
        candle = _candle(open_=102.0, high=106.0, low=101.0, close=103.0)  # high pierces stop
        self.assertEqual(_check_intrabar_exit(position, candle, self.config), ExitReason.STOP_LOSS)

    def test_long_take_profit_hit_by_high(self):
        position = _make_position(side=PositionSide.LONG, entry=100.0, stop=90.0, tp=110.0)
        candle = _candle(open_=105.0, high=111.0, low=104.0, close=108.0)
        self.assertEqual(_check_intrabar_exit(position, candle, self.config), ExitReason.TAKE_PROFIT)

    def test_stop_loss_takes_priority_over_take_profit_in_same_candle(self):
        """A candle whose range spans BOTH stop and target is a
        genuinely ambiguous ordering question — this test locks in the
        deliberately pessimistic assumption documented in
        `_check_intrabar_exit`: the stop is assumed hit first."""
        position = _make_position(side=PositionSide.LONG, entry=100.0, stop=95.0, tp=110.0)
        candle = _candle(open_=100.0, high=112.0, low=94.0, close=105.0)  # spans both
        self.assertEqual(_check_intrabar_exit(position, candle, self.config), ExitReason.STOP_LOSS)

    def test_trailing_stop_hit_by_low_when_active(self):
        position = _make_position(
            side=PositionSide.LONG, entry=100.0, stop=90.0, tp=200.0,
            trailing_price=103.0, trailing_active=True,
        )
        candle = _candle(open_=104.0, high=105.0, low=102.0, close=104.0)  # low pierces trailing stop
        self.assertEqual(_check_intrabar_exit(position, candle, self.config), ExitReason.TRAILING_STOP)

    def test_trailing_stop_ignored_when_not_active(self):
        position = _make_position(
            side=PositionSide.LONG, entry=100.0, stop=90.0, tp=200.0,
            trailing_price=103.0, trailing_active=False,
        )
        candle = _candle(open_=104.0, high=105.0, low=102.0, close=104.0)
        self.assertIsNone(_check_intrabar_exit(position, candle, self.config))

    def test_no_exit_when_price_stays_inside_range(self):
        position = _make_position(side=PositionSide.LONG, entry=100.0, stop=90.0, tp=120.0)
        candle = _candle(open_=101.0, high=103.0, low=99.0, close=102.0)
        self.assertIsNone(_check_intrabar_exit(position, candle, self.config))


class FeeSlippageParityTests(unittest.IsolatedAsyncioTestCase):
    """Confirms the backtest replay's fee/slippage math is IDENTICAL to
    calling `PaperExecutionEngine` directly — i.e. the backtest never
    re-implements or approximates fill math, it reuses Phase 3's engine
    verbatim."""

    async def test_backtest_repository_fill_math_matches_direct_engine_call(self):
        clock = SimulatedClock(start=datetime(2024, 1, 1, tzinfo=timezone.utc))
        repo = BacktestRepository(clock=clock)
        config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0, fee_rate=0.001, slippage_bps=5.0)
        engine = PaperExecutionEngine(repository=repo, config=config, now_fn=clock.now)
        await repo.get_or_create_account(starting_balance=config.starting_balance_usd)

        position = await engine.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
            account_id=DEFAULT_ACCOUNT_ID,
        )
        # Same slippage-always-against-trader guarantee Phase 3 tests verify directly.
        self.assertGreater(position.entry_price, 50_000.0)
        expected_fill = 50_000.0 * 1.0005  # 5 bps against the trader on a BUY
        self.assertAlmostEqual(position.entry_price, expected_fill, places=6)

        expected_quantity = config.trade_amount_usd / expected_fill
        self.assertAlmostEqual(position.quantity, expected_quantity, places=10)

        expected_fee = expected_quantity * expected_fill * config.fee_rate
        self.assertAlmostEqual(position.entry_fee, expected_fee, places=8)

    async def test_insufficient_balance_raises_in_backtest_same_as_live(self):
        from app.paper_trading.engine import PaperExecutionError

        clock = SimulatedClock(start=datetime(2024, 1, 1, tzinfo=timezone.utc))
        repo = BacktestRepository(clock=clock)
        config = PaperTradingConfig(starting_balance_usd=100.0, trade_amount_usd=500.0)
        engine = PaperExecutionEngine(repository=repo, config=config, now_fn=clock.now)
        await repo.get_or_create_account(starting_balance=config.starting_balance_usd)

        with self.assertRaises(PaperExecutionError):
            await engine.open_position(
                symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
                stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.7,
                account_id=DEFAULT_ACCOUNT_ID,
            )


class PositionSizingTests(unittest.IsolatedAsyncioTestCase):
    async def test_position_size_derives_from_configured_trade_amount(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        for trade in results["BTCUSDT"].trades:
            notional = trade.position.entry_price * trade.position.quantity
            # Within a few bps of trade_amount_usd (slippage moves entry_price
            # slightly, which is expected and part of the realism model).
            self.assertAlmostEqual(notional, paper_config.trade_amount_usd, delta=paper_config.trade_amount_usd * 0.01)

    async def test_no_position_size_increase_method_exists_in_backtest_path(self):
        """Mirrors Phase 3's own guarantee test — confirms the backtest
        path uses the exact same `PositionManager`/`PaperExecutionEngine`
        classes that have no averaging-down code path."""
        from app.paper_trading.position_manager import PositionManager

        self.assertFalse(hasattr(PositionManager, "average_down"))
        self.assertFalse(hasattr(PositionManager, "add_to_position"))
        self.assertFalse(hasattr(PaperExecutionEngine, "average_down"))
        self.assertFalse(hasattr(PaperExecutionEngine, "add_to_position"))


class TakeProfitStopLossTrailingIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def test_exit_reasons_only_ever_known_values(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        eth = make_multi_timeframe_fixture(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc, "ETHUSDT": eth},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        valid_reasons = {e for e in ExitReason}
        any_trades = False
        for result in results.values():
            for trade in result.trades:
                any_trades = True
                self.assertIn(trade.position.exit_reason, valid_reasons)
        self.assertTrue(any_trades)

    async def test_stop_loss_exit_price_matches_configured_stop(self):
        """When a trade closes via STOP_LOSS, the reference price fed
        into the (unmodified) execution engine must be exactly the
        position's own stop_loss level — confirming the intrabar check
        hands off to the real engine correctly rather than fabricating
        a different exit price."""
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)

        results = await run_multi_symbol_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc},
            paper_config=paper_config, risk_limits=risk_limits, signal_config=config,
        )
        for trade in results["BTCUSDT"].trades:
            if trade.position.exit_reason == ExitReason.STOP_LOSS:
                direction_factor = 1.0 if trade.position.side == PositionSide.LONG else -1.0
                # exit_price incorporates slippage against the trader on
                # top of the stop_loss reference price, per PaperExecutionEngine.
                expected_direction = -1.0 if trade.position.side == PositionSide.LONG else 1.0
                self.assertTrue(
                    (trade.position.exit_price - trade.position.stop_loss) * expected_direction >= -1e-6
                )


if __name__ == "__main__":
    unittest.main()
