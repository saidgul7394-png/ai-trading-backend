import asyncio
import unittest
from datetime import datetime, timedelta, timezone

from app.services.market_data.candle_store import CandleStore
from app.services.market_data.models import Candle, StaleDataError


def _candle(symbol, interval, open_time, close, open_=None):
    open_ = open_ if open_ is not None else close
    return Candle(
        symbol=symbol,
        interval=interval,
        open_time=open_time,
        close_time=open_time + timedelta(hours=1),
        open=open_,
        high=max(open_, close) + 1,
        low=min(open_, close) - 1,
        close=close,
        volume=100.0,
    )


def run(coro):
    return asyncio.run(coro)


class CandleStoreTests(unittest.TestCase):
    def test_bootstrap_then_read_back(self):
        store = CandleStore()
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        candles = [_candle("BTCUSDT", "1h", base + timedelta(hours=i), 100 + i) for i in range(5)]

        run(store.bootstrap("BTCUSDT", "1h", candles))
        result = run(store.get_candles("BTCUSDT", "1h"))

        self.assertEqual(len(result), 5)
        self.assertEqual(result[0].close, 100)
        self.assertEqual(result[-1].close, 104)

    def test_bootstrap_dedupes_and_sorts(self):
        store = CandleStore()
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        c1 = _candle("BTCUSDT", "1h", base, 100)
        c1_dup = _candle("BTCUSDT", "1h", base, 999)  # same open_time, should be deduped
        c2 = _candle("BTCUSDT", "1h", base + timedelta(hours=1), 101)

        run(store.bootstrap("BTCUSDT", "1h", [c2, c1_dup, c1]))
        result = run(store.get_candles("BTCUSDT", "1h"))

        self.assertEqual(len(result), 2)
        self.assertEqual(result[0].open_time, c1.open_time)

    def test_upsert_appends_new_candle(self):
        store = CandleStore()
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        run(store.bootstrap("BTCUSDT", "1h", [_candle("BTCUSDT", "1h", base, 100)]))
        run(store.upsert(_candle("BTCUSDT", "1h", base + timedelta(hours=1), 105)))

        result = run(store.get_candles("BTCUSDT", "1h"))
        self.assertEqual(len(result), 2)
        self.assertEqual(result[-1].close, 105)

    def test_upsert_replaces_same_open_time(self):
        store = CandleStore()
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        run(store.bootstrap("BTCUSDT", "1h", [_candle("BTCUSDT", "1h", base, 100)]))
        run(store.upsert(_candle("BTCUSDT", "1h", base, 150)))  # replaces, doesn't append

        result = run(store.get_candles("BTCUSDT", "1h"))
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].close, 150)

    def test_max_candles_enforced(self):
        store = CandleStore(max_candles=3)
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        candles = [_candle("BTCUSDT", "1h", base + timedelta(hours=i), 100 + i) for i in range(10)]
        run(store.bootstrap("BTCUSDT", "1h", candles))

        result = run(store.get_candles("BTCUSDT", "1h"))
        self.assertEqual(len(result), 3)
        self.assertEqual(result[-1].close, 109)  # kept the most recent

    def test_freshness_seconds_none_when_empty(self):
        store = CandleStore()
        self.assertIsNone(run(store.freshness_seconds("BTCUSDT", "1h")))

    def test_freshness_seconds_computed_from_latest_close(self):
        store = CandleStore()
        recent_open = datetime.now(timezone.utc) - timedelta(minutes=5)
        run(store.bootstrap("BTCUSDT", "1h", [_candle("BTCUSDT", "1h", recent_open, 100)]))

        freshness = run(store.freshness_seconds("BTCUSDT", "1h"))
        # close_time = open_time + 1h, so freshness should be negative-ish
        # small (candle "closes" in the future relative to open) — what
        # matters here is it's a number, not None, and roughly in range.
        self.assertIsInstance(freshness, int)

    def test_assert_fresh_raises_when_no_data(self):
        store = CandleStore()
        with self.assertRaises(StaleDataError):
            run(store.assert_fresh("BTCUSDT", "1h"))

    def test_assert_fresh_raises_when_stale(self):
        store = CandleStore()
        old_open = datetime.now(timezone.utc) - timedelta(hours=10)
        run(store.bootstrap("BTCUSDT", "1h", [_candle("BTCUSDT", "1h", old_open, 100)]))
        with self.assertRaises(StaleDataError):
            run(store.assert_fresh("BTCUSDT", "1h", max_staleness_multiplier=3.0))

    def test_assert_fresh_passes_when_current(self):
        store = CandleStore()
        recent_open = datetime.now(timezone.utc) - timedelta(minutes=1)
        run(store.bootstrap("BTCUSDT", "1h", [_candle("BTCUSDT", "1h", recent_open, 100)]))
        # Should not raise.
        run(store.assert_fresh("BTCUSDT", "1h", max_staleness_multiplier=3.0))

    def test_has_gap_detects_missing_candle(self):
        store = CandleStore()
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        c1 = _candle("BTCUSDT", "1h", base, 100)
        c2 = _candle("BTCUSDT", "1h", base + timedelta(hours=3), 101)  # 3h gap on a 1h series
        run(store.bootstrap("BTCUSDT", "1h", [c1, c2]))

        self.assertTrue(run(store.has_gap("BTCUSDT", "1h")))

    def test_has_gap_false_for_contiguous_series(self):
        store = CandleStore()
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        c1 = _candle("BTCUSDT", "1h", base, 100)
        c2 = _candle("BTCUSDT", "1h", base + timedelta(hours=1), 101)
        run(store.bootstrap("BTCUSDT", "1h", [c1, c2]))

        self.assertFalse(run(store.has_gap("BTCUSDT", "1h")))

    def test_series_are_isolated_per_symbol_and_interval(self):
        store = CandleStore()
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        run(store.bootstrap("BTCUSDT", "1h", [_candle("BTCUSDT", "1h", base, 100)]))
        run(store.bootstrap("ETHUSDT", "1h", [_candle("ETHUSDT", "1h", base, 3000)]))
        run(store.bootstrap("BTCUSDT", "15m", [_candle("BTCUSDT", "15m", base, 99)]))

        self.assertEqual(len(run(store.get_candles("BTCUSDT", "1h"))), 1)
        self.assertEqual(len(run(store.get_candles("ETHUSDT", "1h"))), 1)
        self.assertEqual(len(run(store.get_candles("BTCUSDT", "15m"))), 1)
        self.assertEqual(run(store.get_candles("BTCUSDT", "1h"))[0].close, 100)
        self.assertEqual(run(store.get_candles("ETHUSDT", "1h"))[0].close, 3000)


if __name__ == "__main__":
    unittest.main()
