import unittest
from datetime import datetime, timezone

from app.signal_engine.composite import build_composite_signal
from app.signal_engine.config import SignalEngineConfig
from app.tests.deterministic_dataset import (
    make_conflicting_candles,
    make_flat_candles,
    make_insufficient_candles,
    make_trend_candles,
    multi_timeframe_dataset,
)


class DirectionalSignalTests(unittest.TestCase):
    def test_strong_uptrend_produces_buy(self):
        candles_by_tf = multi_timeframe_dataset(symbol="BTCUSDT", trend_per_candle=5.0)
        btc_candles = candles_by_tf["1h"]  # symbol IS BTCUSDT, self-confirmation is fine

        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe=candles_by_tf,
            btc_candles=btc_candles,
            data_freshness_seconds=10,
        )

        self.assertEqual(signal.action, "BUY")
        self.assertGreater(signal.confidence, 0)
        self.assertGreaterEqual(len(signal.factors), 5)
        self.assertGreater(signal.take_profit, signal.entry_price)
        self.assertLess(signal.stop_loss, signal.entry_price)
        self.assertGreater(signal.risk_reward_ratio, 0)

    def test_strong_downtrend_produces_sell(self):
        candles_by_tf = multi_timeframe_dataset(symbol="ETHUSDT", trend_per_candle=-5.0)
        btc_candles = make_trend_candles(symbol="BTCUSDT", interval="1h", count=120, trend_per_candle=-5.0)

        signal = build_composite_signal(
            symbol="ETHUSDT",
            primary_timeframe="1h",
            candles_by_timeframe=candles_by_tf,
            btc_candles=btc_candles,
            data_freshness_seconds=10,
        )

        self.assertEqual(signal.action, "SELL")
        self.assertLess(signal.take_profit, signal.entry_price)
        self.assertGreater(signal.stop_loss, signal.entry_price)

    def test_flat_range_bound_market_produces_hold(self):
        flat = make_flat_candles(count=120)
        candles_by_tf = {"1h": flat, "15m": flat, "4h": flat}

        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe=candles_by_tf,
            btc_candles=flat,
            data_freshness_seconds=10,
        )

        self.assertEqual(signal.action, "HOLD")
        self.assertFalse(signal.eligible_for_auto_trade)


class NeverSingleIndicatorTests(unittest.TestCase):
    def test_insufficient_history_forces_hold(self):
        thin = make_insufficient_candles(count=10)
        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe={"1h": thin},
            data_freshness_seconds=5,
        )
        self.assertEqual(signal.action, "HOLD")
        self.assertIn("Insufficient market data", signal.reasons[0])
        self.assertFalse(signal.eligible_for_auto_trade)

    def test_min_factor_gate_blocks_directional_call(self):
        # Enough candles for SOME indicators but a config demanding more
        # independent factors than are actually available should still
        # force HOLD, never a BUY/SELL built on a thin factor set.
        candles = make_trend_candles(count=65, trend_per_candle=5.0)
        strict_config = SignalEngineConfig(min_candles_required=60, min_factors_for_directional_signal=50)

        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe={"1h": candles},
            data_freshness_seconds=5,
            config=strict_config,
        )
        self.assertEqual(signal.action, "HOLD")
        self.assertIn("independent factors", signal.reasons[0])


class ConflictDetectionTests(unittest.TestCase):
    def test_strongly_conflicting_factors_force_hold(self):
        candles = make_conflicting_candles(count=120)
        signal = build_composite_signal(
            symbol="ETHUSDT",
            primary_timeframe="1h",
            candles_by_timeframe={"1h": candles},
            data_freshness_seconds=5,
        )
        # Either it's detected as an explicit conflict, or the opposing
        # factors cancel out into the HOLD band — both are an acceptable
        # "no clear consensus" outcome; what must NEVER happen is a
        # confident directional call out of a dataset built to disagree.
        self.assertEqual(signal.action, "HOLD")


class StaleDataTests(unittest.TestCase):
    def test_stale_data_forces_hold_regardless_of_trend(self):
        candles = make_trend_candles(count=120, trend_per_candle=20.0)
        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe={"1h": candles},
            data_freshness_seconds=99_999,  # way older than 3x1h staleness window
        )
        self.assertEqual(signal.action, "HOLD")
        self.assertIn("stale", signal.reasons[0].lower())
        self.assertFalse(signal.eligible_for_auto_trade)

    def test_fresh_data_does_not_trigger_staleness_hold(self):
        candles = make_trend_candles(count=120, trend_per_candle=20.0)
        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe={"1h": candles},
            data_freshness_seconds=30,
        )
        self.assertNotIn("stale", " ".join(signal.reasons).lower())


class MultiTimeframeConfirmationTests(unittest.TestCase):
    def test_agreeing_timeframes_produce_confirming_factor(self):
        candles_by_tf = multi_timeframe_dataset(symbol="BTCUSDT", trend_per_candle=5.0)
        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe=candles_by_tf,
            btc_candles=candles_by_tf["1h"],
            data_freshness_seconds=10,
        )
        mtf_factors = [f for f in signal.factors if f.name == "Multi-Timeframe Confirmation"]
        self.assertEqual(len(mtf_factors), 1)
        self.assertGreater(mtf_factors[0].leaning, 0)

    def test_btc_trend_factor_present_for_altcoin(self):
        candles_by_tf = multi_timeframe_dataset(symbol="ETHUSDT", trend_per_candle=5.0)
        btc_candles = make_trend_candles(symbol="BTCUSDT", interval="1h", count=120, trend_per_candle=5.0)
        signal = build_composite_signal(
            symbol="ETHUSDT",
            primary_timeframe="1h",
            candles_by_timeframe=candles_by_tf,
            btc_candles=btc_candles,
            data_freshness_seconds=10,
        )
        btc_factors = [f for f in signal.factors if f.name == "BTC Trend"]
        self.assertEqual(len(btc_factors), 1)
        self.assertIn("market-wide", btc_factors[0].value)


class RequiredFieldsTests(unittest.TestCase):
    def test_signal_has_all_required_output_fields(self):
        candles_by_tf = multi_timeframe_dataset(symbol="BTCUSDT", trend_per_candle=5.0)
        signal = build_composite_signal(
            symbol="BTCUSDT",
            primary_timeframe="1h",
            candles_by_timeframe=candles_by_tf,
            btc_candles=candles_by_tf["1h"],
            data_freshness_seconds=12,
        )
        self.assertIn(signal.action, ("BUY", "SELL", "HOLD"))
        self.assertIsInstance(signal.confidence, float)
        self.assertIsInstance(signal.entry_price, float)
        self.assertIsInstance(signal.stop_loss, float)
        self.assertIsInstance(signal.take_profit, float)
        self.assertIsInstance(signal.risk_reward_ratio, float)
        self.assertTrue(signal.reasons)
        self.assertEqual(signal.timeframe, "1h")
        self.assertIsInstance(signal.generated_at, datetime)
        self.assertEqual(signal.data_freshness_seconds, 12)

    def test_signal_is_deterministic_given_same_inputs(self):
        candles_by_tf = multi_timeframe_dataset(symbol="BTCUSDT", trend_per_candle=5.0)
        fixed_now = datetime(2025, 6, 1, tzinfo=timezone.utc)

        def run():
            return build_composite_signal(
                symbol="BTCUSDT",
                primary_timeframe="1h",
                candles_by_timeframe=candles_by_tf,
                btc_candles=candles_by_tf["1h"],
                data_freshness_seconds=10,
                now=fixed_now,
            )

        s1, s2 = run(), run()
        self.assertEqual(s1.action, s2.action)
        self.assertEqual(s1.confidence, s2.confidence)
        self.assertEqual(s1.entry_price, s2.entry_price)
        self.assertEqual(s1.stop_loss, s2.stop_loss)
        self.assertEqual(s1.take_profit, s2.take_profit)


if __name__ == "__main__":
    unittest.main()
