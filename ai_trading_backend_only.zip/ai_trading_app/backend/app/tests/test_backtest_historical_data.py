"""Tests for `historical_data.py` — specifically that this environment's
lack of network egress / httpx is reported HONESTLY as
"REAL HISTORICAL VALIDATION BLOCKED", never silently swapped for
synthetic data. Also covers the CSV cache round-trip and gap detection.
"""

from __future__ import annotations

import shutil
import tempfile
import unittest
from datetime import datetime, timezone

from app.backtesting.fixtures import make_simple_uptrend
from app.backtesting.historical_data import (
    HistoricalDataCache,
    HistoricalDataUnavailableError,
    try_fetch_real_historical_data,
)


class HistoricalDataCacheTests(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_save_and_load_roundtrip_preserves_candle_data(self):
        cache = HistoricalDataCache(self.tmpdir)
        candles = make_simple_uptrend(count=20)
        cache.save("BTCUSDT", "1h", candles)
        loaded = cache.load("BTCUSDT", "1h")

        self.assertIsNotNone(loaded)
        self.assertEqual(len(loaded), len(candles))
        for original, restored in zip(candles, loaded):
            self.assertEqual(original.open_time, restored.open_time)
            self.assertEqual(original.close_time, restored.close_time)
            self.assertAlmostEqual(original.open, restored.open)
            self.assertAlmostEqual(original.high, restored.high)
            self.assertAlmostEqual(original.low, restored.low)
            self.assertAlmostEqual(original.close, restored.close)
            self.assertAlmostEqual(original.volume, restored.volume)

    def test_load_missing_symbol_returns_none_not_error(self):
        cache = HistoricalDataCache(self.tmpdir)
        self.assertIsNone(cache.load("NOSUCHSYMBOL", "1h"))


class RealDataHonestlyBlockedTests(unittest.IsolatedAsyncioTestCase):
    """This sandbox genuinely has no network egress and no `httpx`
    installed (see Phase 4 final verification notes) — these tests
    lock in that `try_fetch_real_historical_data` reports that
    honestly rather than crashing uncaught or silently returning
    fabricated data."""

    async def test_try_fetch_reports_errors_never_raises(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            data, errors = await try_fetch_real_historical_data(
                symbols=("BTCUSDT",), intervals=("1h",),
                start=datetime(2024, 1, 1, tzinfo=timezone.utc), end=datetime(2024, 1, 5, tzinfo=timezone.utc),
                cache=HistoricalDataCache(tmp),
            )
        self.assertIn("BTCUSDT", data)
        self.assertEqual(data["BTCUSDT"], {})  # no interval succeeded
        self.assertTrue(len(errors) > 0)
        self.assertTrue(any("network" in e.lower() or "httpx" in e.lower() or "dependency" in e.lower() for e in errors))

    async def test_cached_data_is_used_without_hitting_network(self):
        """If a symbol/interval is already cached, it must be served
        from cache — no network attempt required. Confirms the cache
        path works independently of network availability."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            cache = HistoricalDataCache(tmp)
            candles = make_simple_uptrend(count=30)
            cache.save("BTCUSDT", "1h", candles)

            data, errors = await try_fetch_real_historical_data(
                symbols=("BTCUSDT",), intervals=("1h",),
                start=datetime(2024, 1, 1, tzinfo=timezone.utc), end=datetime(2024, 1, 5, tzinfo=timezone.utc),
                cache=cache,
            )
        self.assertEqual(len(data["BTCUSDT"]["1h"]), 30)
        # No error should be recorded for the cached BTCUSDT/1h pair
        # specifically (the client-construction error may still appear
        # generically, but must not block cache-hit pairs).
        self.assertNotIn("BTCUSDT 1h", " ".join(errors))


if __name__ == "__main__":
    unittest.main()
