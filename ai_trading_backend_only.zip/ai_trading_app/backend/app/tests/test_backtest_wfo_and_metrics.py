"""Walk-forward window separation, OOS isolation, and metrics accuracy
tests (Phase 4 spec item 8: "WFO window separation", "OOS isolation",
"Metrics accuracy").
"""

from __future__ import annotations

import unittest
from dataclasses import replace
from datetime import datetime, timezone

from app.backtesting.fixtures import make_multi_timeframe_fixture, make_simple_uptrend
from app.backtesting.metrics import compute_performance_metrics
from app.backtesting.replay_engine import ReplayResult, TradeRecord
from app.backtesting.walk_forward import (
    ParameterSet,
    build_walk_forward_windows,
    detect_suspicious_overfitting,
    run_walk_forward_backtest,
    split_oos_holdout,
)
from app.paper_trading.config import PaperTradingConfig
from app.paper_trading.models import ExitReason, PaperPosition, PositionSide, PositionStatus
from app.paper_trading.pipeline import RiskLimits
from app.signal_engine.config import SignalEngineConfig


class WalkForwardWindowSeparationTests(unittest.TestCase):
    def test_windows_never_overlap_and_progress_chronologically(self):
        candles = make_simple_uptrend(count=1000)
        windows = build_walk_forward_windows(candles, train_candles=200, validation_candles=80, test_candles=80)
        self.assertGreater(len(windows), 1, "test needs at least 2 windows to verify non-overlap")

        for w in windows:
            # Within one window: train -> validation -> test, strictly
            # non-overlapping and chronologically ordered.
            self.assertLessEqual(w.train[0], w.train[1])
            self.assertEqual(w.train[1], w.validation[0])
            self.assertEqual(w.validation[1], w.test[0])
            self.assertLess(w.train[0], w.test[1])

    def test_windows_roll_forward_by_step(self):
        candles = make_simple_uptrend(count=1000)
        windows = build_walk_forward_windows(
            candles, train_candles=200, validation_candles=80, test_candles=80, step_candles=80
        )
        for i in range(1, len(windows)):
            self.assertLess(windows[i - 1].train[0], windows[i].train[0])

    def test_train_never_includes_data_from_validation_or_test(self):
        candles = make_simple_uptrend(count=600)
        windows = build_walk_forward_windows(candles, train_candles=150, validation_candles=60, test_candles=60)
        for w in windows:
            train_candles_slice = [c for c in candles if w.train[0] <= c.open_time < w.train[1]]
            for c in train_candles_slice:
                self.assertLess(c.open_time, w.validation[0], "train candle leaked into validation period")
                self.assertLess(c.open_time, w.test[0], "train candle leaked into test period")

    def test_rejects_non_positive_window_sizes(self):
        candles = make_simple_uptrend(count=100)
        with self.assertRaises(ValueError):
            build_walk_forward_windows(candles, train_candles=0, validation_candles=10, test_candles=10)
        with self.assertRaises(ValueError):
            build_walk_forward_windows(candles, train_candles=10, validation_candles=10, test_candles=-5)

    def test_never_shuffles_input(self):
        """The function must not reorder its input at all — verified by
        confirming the input list object's order is byte-identical
        before and after the call."""
        candles = make_simple_uptrend(count=300)
        original_order = list(candles)
        build_walk_forward_windows(candles, train_candles=100, validation_candles=50, test_candles=50)
        self.assertEqual(candles, original_order)


class OosIsolationTests(unittest.TestCase):
    def test_oos_holdout_is_the_chronological_tail(self):
        candles = make_simple_uptrend(count=500)
        dev, oos = split_oos_holdout(candles, oos_fraction=0.2)
        self.assertEqual(len(dev) + len(oos), len(candles))
        self.assertEqual(dev, candles[: len(dev)])
        self.assertEqual(oos, candles[len(dev):])
        # every dev candle strictly precedes every oos candle
        self.assertLessEqual(dev[-1].close_time, oos[0].open_time)

    def test_oos_fraction_bounds_enforced(self):
        candles = make_simple_uptrend(count=100)
        with self.assertRaises(ValueError):
            split_oos_holdout(candles, oos_fraction=0.0)
        with self.assertRaises(ValueError):
            split_oos_holdout(candles, oos_fraction=1.0)
        with self.assertRaises(ValueError):
            split_oos_holdout(candles, oos_fraction=1.5)

    def test_too_few_candles_raises_rather_than_silently_degrading(self):
        candles = make_simple_uptrend(count=5)
        with self.assertRaises(ValueError):
            split_oos_holdout(candles, oos_fraction=0.2)

    def test_walk_forward_windows_never_drawn_from_oos_slice(self):
        """Full-stack check: every walk-forward window's test segment
        (the latest data any window ever touches) must end at or before
        the OOS holdout begins."""
        candles = make_simple_uptrend(count=1000)
        dev, oos = split_oos_holdout(candles, oos_fraction=0.2)
        windows = build_walk_forward_windows(dev, train_candles=200, validation_candles=80, test_candles=80)
        oos_start = oos[0].open_time
        for w in windows:
            self.assertLessEqual(w.test[1], oos_start, f"Window {w.index}'s test segment extends into the OOS holdout")


class WalkForwardParameterVersioningTests(unittest.TestCase):
    def test_identical_config_produces_identical_hash(self):
        signal_config = SignalEngineConfig()
        paper_config = PaperTradingConfig()
        ps1 = ParameterSet(label="a", signal_config=signal_config, risk_limits_kwargs={"min_confidence": 0.65}, paper_config=paper_config)
        ps2 = ParameterSet(label="b", signal_config=signal_config, risk_limits_kwargs={"min_confidence": 0.65}, paper_config=paper_config)
        # Label differs but content_hash must depend only on the actual
        # configuration, not the human-readable label.
        self.assertEqual(ps1.content_hash, ps2.content_hash)

    def test_different_config_produces_different_hash(self):
        paper_config = PaperTradingConfig()
        ps1 = ParameterSet(label="a", signal_config=SignalEngineConfig(buy_threshold=0.25), risk_limits_kwargs={"min_confidence": 0.65}, paper_config=paper_config)
        ps2 = ParameterSet(label="a", signal_config=SignalEngineConfig(buy_threshold=0.35), risk_limits_kwargs={"min_confidence": 0.65}, paper_config=paper_config)
        self.assertNotEqual(ps1.content_hash, ps2.content_hash)

    def test_mark_parameters_tuned_flips_flag_permanently(self):
        from app.backtesting.walk_forward import WalkForwardReport

        ps = ParameterSet(label="a", signal_config=SignalEngineConfig(), risk_limits_kwargs={}, paper_config=PaperTradingConfig())
        report = WalkForwardReport(parameter_set=ps)
        self.assertTrue(report.oos_still_untouched)
        report.mark_parameters_tuned("raised buy_threshold after seeing validation results")
        self.assertFalse(report.oos_still_untouched)
        self.assertEqual(len(report.tuning_log), 1)
        # No way back to True — re-marking only appends to the log.
        report.mark_parameters_tuned("tuned again")
        self.assertFalse(report.oos_still_untouched)
        self.assertEqual(len(report.tuning_log), 2)


class WalkForwardIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def test_full_walk_forward_run_produces_isolated_windows_and_oos(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        eth = make_multi_timeframe_fixture(symbol="ETHUSDT", base_price=2500.0, segment_length=150)
        signal_config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)
        ps = ParameterSet(label="wf-test", signal_config=signal_config, risk_limits_kwargs={"min_confidence": 0.3}, paper_config=paper_config)

        report = await run_walk_forward_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc, "ETHUSDT": eth},
            parameter_set=ps, risk_limits=risk_limits,
            train_candles=200, validation_candles=80, test_candles=80, oos_fraction=0.2,
        )
        self.assertGreater(len(report.windows), 0)
        self.assertIsNotNone(report.oos_result)
        self.assertTrue(report.oos_still_untouched)

        # Every window's test-segment trades must have opened strictly
        # within that window's test time boundaries.
        for wr in report.windows:
            for trade in wr.test_result.trades:
                self.assertGreaterEqual(trade.position.opened_at, wr.window.test[0])
                self.assertLess(trade.position.opened_at, wr.window.test[1])

        # OOS trades must all have opened at or after every window's
        # test segment has ended (i.e. strictly after the walk-forward
        # development period).
        last_test_end = max(wr.window.test[1] for wr in report.windows)
        for trade in report.oos_result.trades:
            self.assertGreaterEqual(trade.position.opened_at, last_test_end)

    async def test_overfitting_detector_flags_thin_windows(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        signal_config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)
        ps = ParameterSet(label="wf-test2", signal_config=signal_config, risk_limits_kwargs={}, paper_config=paper_config)

        report = await run_walk_forward_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc},
            parameter_set=ps, risk_limits=risk_limits,
            train_candles=200, validation_candles=80, test_candles=80, oos_fraction=0.2,
        )
        warnings = detect_suspicious_overfitting(report)
        # With this little synthetic data, at least the thin-window
        # warning should fire — confirms the detector is actually wired
        # up and reachable end-to-end, not just unit-tested in isolation.
        self.assertTrue(any("too few" in w for w in warnings) or len(report.windows) == 0)

    async def test_tuned_parameters_flag_surfaces_in_overfitting_warnings(self):
        btc = make_multi_timeframe_fixture(symbol="BTCUSDT", segment_length=150)
        signal_config = SignalEngineConfig(min_confidence_for_auto_trade=0.3, min_risk_reward_ratio=1.0)
        paper_config = PaperTradingConfig(starting_balance_usd=10_000.0, trade_amount_usd=500.0)
        risk_limits = RiskLimits(min_confidence=0.3, max_open_trades=5, max_trades_per_day=None)
        ps = ParameterSet(label="wf-test3", signal_config=signal_config, risk_limits_kwargs={}, paper_config=paper_config)

        report = await run_walk_forward_backtest(
            primary_timeframe="1h", candles_by_symbol_tf={"BTCUSDT": btc},
            parameter_set=ps, risk_limits=risk_limits,
            train_candles=200, validation_candles=80, test_candles=80, oos_fraction=0.2,
        )
        report.mark_parameters_tuned("raised confidence threshold after inspecting validation window 0")
        warnings = detect_suspicious_overfitting(report)
        self.assertTrue(any("tuned" in w.lower() for w in warnings))


class MetricsAccuracyTests(unittest.TestCase):
    """Hand-computed expected values against synthetic trade records —
    the core correctness check for item 4's arithmetic."""

    def _trade(self, *, pnl: float, side=PositionSide.LONG, entry=100.0, stop=95.0, opened_at=None, closed_at=None, mfe=0.0, mae=0.0, fee_in=0.0, fee_out=0.0):
        opened_at = opened_at or datetime(2024, 1, 1, tzinfo=timezone.utc)
        closed_at = closed_at or datetime(2024, 1, 1, 1, tzinfo=timezone.utc)
        position = PaperPosition(
            id="p", account_id="a", symbol="BTCUSDT", side=side, status=PositionStatus.CLOSED,
            entry_price=entry, quantity=1.0, stop_loss=stop, take_profit=entry + 20, entry_fee=fee_in,
            signal_id="s", signal_confidence_at_entry=0.7, opened_at=opened_at, client_order_id="c",
            exit_price=entry + pnl, exit_reason=ExitReason.TAKE_PROFIT if pnl > 0 else ExitReason.STOP_LOSS,
            realized_pnl=pnl, exit_fee=fee_out, closed_at=closed_at,
        )
        return TradeRecord(position=position, regime_keys_at_entry=[], mfe_percent=mfe, mae_percent=mae)

    def test_win_rate_and_counts(self):
        trades = [self._trade(pnl=10), self._trade(pnl=-5), self._trade(pnl=20), self._trade(pnl=-3)]
        m = compute_performance_metrics(trades)
        self.assertEqual(m.total_trades, 4)
        self.assertEqual(m.winning_trades, 2)
        self.assertEqual(m.losing_trades, 2)
        self.assertAlmostEqual(m.win_rate_percent, 50.0)

    def test_profit_factor_matches_hand_computation(self):
        trades = [self._trade(pnl=10), self._trade(pnl=-5), self._trade(pnl=20), self._trade(pnl=-3)]
        m = compute_performance_metrics(trades)
        # gross_profit = 30, gross_loss = 8 -> profit_factor = 3.75
        self.assertAlmostEqual(m.gross_profit, 30.0)
        self.assertAlmostEqual(m.gross_loss, 8.0)
        self.assertAlmostEqual(m.profit_factor, 3.75)

    def test_profit_factor_none_when_no_losses(self):
        trades = [self._trade(pnl=10), self._trade(pnl=5)]
        m = compute_performance_metrics(trades)
        self.assertIsNone(m.profit_factor)

    def test_expectancy_matches_hand_computation(self):
        trades = [self._trade(pnl=10), self._trade(pnl=-5), self._trade(pnl=20), self._trade(pnl=-3)]
        m = compute_performance_metrics(trades)
        # net_pnl = 22, total_trades = 4 -> expectancy = 5.5
        self.assertAlmostEqual(m.net_pnl, 22.0)
        self.assertAlmostEqual(m.expectancy, 5.5)

    def test_average_win_and_loss(self):
        trades = [self._trade(pnl=10), self._trade(pnl=-5), self._trade(pnl=20), self._trade(pnl=-3)]
        m = compute_performance_metrics(trades)
        self.assertAlmostEqual(m.average_win, 15.0)  # (10+20)/2
        self.assertAlmostEqual(m.average_loss, -4.0)  # (-5-3)/2

    def test_max_drawdown_matches_hand_computation(self):
        # Equity path: 0 -> 10 -> 5 -> 15 -> 0 -> 20
        # peak sequence: 10,10,15,15,20 ; drawdown sequence: 0,5,0,15,0
        trades = [
            self._trade(pnl=10), self._trade(pnl=-5), self._trade(pnl=10),
            self._trade(pnl=-15), self._trade(pnl=20),
        ]
        m = compute_performance_metrics(trades)
        self.assertAlmostEqual(m.max_drawdown_absolute, 15.0)

    def test_consecutive_wins_and_losses(self):
        trades = [
            self._trade(pnl=1), self._trade(pnl=1), self._trade(pnl=-1),
            self._trade(pnl=-1), self._trade(pnl=-1), self._trade(pnl=1),
        ]
        m = compute_performance_metrics(trades)
        self.assertEqual(m.max_consecutive_wins, 2)
        self.assertEqual(m.max_consecutive_losses, 3)

    def test_r_multiple_matches_hand_computation(self):
        # entry=100, stop=95 -> initial_risk = 5 * qty(1) = 5. pnl=10 -> R=2.0
        trades = [self._trade(pnl=10, entry=100.0, stop=95.0)]
        m = compute_performance_metrics(trades)
        self.assertAlmostEqual(m.average_r_multiple, 2.0)

    def test_long_short_breakdown(self):
        trades = [
            self._trade(pnl=10, side=PositionSide.LONG),
            self._trade(pnl=-5, side=PositionSide.LONG),
            self._trade(pnl=8, side=PositionSide.SHORT),
        ]
        m = compute_performance_metrics(trades)
        self.assertEqual(m.long_trades, 2)
        self.assertEqual(m.short_trades, 1)
        self.assertAlmostEqual(m.long_net_pnl, 5.0)
        self.assertAlmostEqual(m.short_net_pnl, 8.0)
        self.assertAlmostEqual(m.long_win_rate_percent, 50.0)
        self.assertAlmostEqual(m.short_win_rate_percent, 100.0)

    def test_total_fees_summed_correctly(self):
        trades = [self._trade(pnl=10, fee_in=1.0, fee_out=1.5), self._trade(pnl=-5, fee_in=0.5, fee_out=0.5)]
        m = compute_performance_metrics(trades)
        self.assertAlmostEqual(m.total_fees, 3.5)

    def test_empty_trade_list_returns_zeroed_metrics_not_error(self):
        m = compute_performance_metrics([])
        self.assertEqual(m.total_trades, 0)
        self.assertEqual(m.win_rate_percent, 0.0)
        self.assertIsNone(m.profit_factor)

    def test_mfe_mae_averages(self):
        trades = [self._trade(pnl=1, mfe=2.0, mae=-1.0), self._trade(pnl=1, mfe=4.0, mae=-3.0)]
        m = compute_performance_metrics(trades)
        self.assertAlmostEqual(m.average_mfe_percent, 3.0)
        self.assertAlmostEqual(m.average_mae_percent, -2.0)


if __name__ == "__main__":
    unittest.main()
