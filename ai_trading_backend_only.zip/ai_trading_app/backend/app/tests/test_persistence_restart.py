"""Verifies the Phase 3 requirement: 'verify application restart does
not lose open paper positions'. Each test here deliberately constructs
a brand-new `Database`/`PaperTradingRepository`/engine/position-manager
stack pointed at the same on-disk SQLite file used by an earlier
"session" — nothing is shared in memory between the two, which is the
same boundary an actual process restart crosses.
"""

import os
import unittest
from datetime import datetime, timezone

from app.paper_trading.models import ExitReason, PositionSide
from app.tests.paper_trading_fixtures import build_paper_stack, make_temp_db_path


class RestartRecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db_path = make_temp_db_path()

    async def asyncTearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    async def test_open_positions_survive_restart(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        account = await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await engine1.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.8,
            account_id=account.id,
        )
        await engine1.open_position(
            symbol="ETHUSDT", side=PositionSide.SHORT, reference_price=3_000.0,
            stop_loss=3_100.0, take_profit=2_800.0, signal_id="s2", signal_confidence=0.75,
            account_id=account.id,
        )

        # --- restart boundary: fresh objects, same file ---
        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)

        recovered = await repo2.get_open_positions()
        self.assertEqual(len(recovered), 2)
        self.assertEqual({p.symbol for p in recovered}, {"BTCUSDT", "ETHUSDT"})

    async def test_account_balance_survives_restart(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        account = await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await engine1.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.8,
            account_id=account.id,
        )
        balance_before_restart = (await repo1.get_account()).current_balance

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        recovered_account = await repo2.get_account()

        self.assertEqual(recovered_account.current_balance, balance_before_restart)
        self.assertNotEqual(recovered_account.current_balance, recovered_account.starting_balance)

    async def test_recovered_position_can_be_closed_normally(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        account = await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        opened = await engine1.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.8,
            account_id=account.id,
        )

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        recovered = (await repo2.get_open_positions())[0]
        self.assertEqual(recovered.id, opened.id)

        closed = await pm2.manage_position(recovered, current_price=56_000.0)
        self.assertIsNotNone(closed)
        self.assertEqual(closed.exit_reason, ExitReason.TAKE_PROFIT)

        still_open = await repo2.get_open_positions()
        self.assertEqual(len(still_open), 0)

    async def test_cooldown_state_survives_restart(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await repo1.set_cooldown("BTCUSDT", action="BUY", until=datetime.now(timezone.utc))

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        cooldown = await repo2.get_cooldown_until("BTCUSDT")
        self.assertIsNotNone(cooldown)

    async def test_emergency_stop_flag_survives_restart(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await repo1.set_flag("emergency_stop_active", True)

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        self.assertTrue(await repo2.get_flag("emergency_stop_active"))

    async def test_emergency_stop_remains_active_until_explicitly_cleared(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await repo1.set_flag("emergency_stop_active", True)

        # Multiple "restarts" in a row -- flag must stay set across all
        # of them until something explicitly clears it.
        for _ in range(3):
            db_n, repo_n, _, _, _ = build_paper_stack(self.db_path)
            self.assertTrue(await repo_n.get_flag("emergency_stop_active"))

        db_final, repo_final, _, _, _ = build_paper_stack(self.db_path)
        await repo_final.set_flag("emergency_stop_active", False)

        db_after, repo_after, _, _, _ = build_paper_stack(self.db_path)
        self.assertFalse(await repo_after.get_flag("emergency_stop_active"))

    async def test_closed_trade_history_survives_restart(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        account = await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        position = await engine1.open_position(
            symbol="BTCUSDT", side=PositionSide.LONG, reference_price=50_000.0,
            stop_loss=49_000.0, take_profit=55_000.0, signal_id="s1", signal_confidence=0.8,
            account_id=account.id,
        )
        await engine1.close_position(position, reference_price=55_000.0, exit_reason=ExitReason.TAKE_PROFIT)

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        history = await repo2.get_trade_history()
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0].symbol, "BTCUSDT")

        stats = await repo2.get_trade_stats()
        self.assertEqual(stats.total_trades, 1)
        self.assertEqual(stats.winning_trades, 1)

    async def test_signal_log_survives_restart(self):
        from app.paper_trading.models import SignalLogEntry
        import uuid

        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await repo1.log_signal(
            SignalLogEntry(
                id=str(uuid.uuid4()), symbol="BTCUSDT", timeframe="1h", action="BUY",
                confidence=0.8, eligible_for_auto_trade=True, rejection_reason=None,
                generated_at=datetime.now(timezone.utc), factors=[],
            )
        )

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        last_action = await repo2.get_last_signal_action("BTCUSDT")
        self.assertEqual(last_action, "BUY")

    async def test_risk_events_survive_restart(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await repo1.log_risk_event("RISK_BLOCK", symbol="BTCUSDT", payload={"reasons": ["test"]})

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        events = await repo2.get_recent_risk_events()
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["event_type"], "RISK_BLOCK")

    async def test_worker_heartbeat_survives_restart(self):
        db1, repo1, engine1, pm1, config = build_paper_stack(self.db_path)
        await repo1.get_or_create_account(starting_balance=config.starting_balance_usd)
        await repo1.record_worker_success()
        await repo1.record_worker_success()

        db2, repo2, engine2, pm2, _ = build_paper_stack(self.db_path)
        heartbeat = await repo2.get_worker_heartbeat()
        self.assertEqual(heartbeat["total_cycles"], 2)

    async def test_schema_migration_is_idempotent_across_restarts(self):
        """Opening the same DB file repeatedly must never fail or
        duplicate schema objects — this is what lets the app restart
        (or the worker reconnect) any number of times safely."""
        for _ in range(5):
            db_n, repo_n, _, _, config = build_paper_stack(self.db_path)
            await repo_n.get_or_create_account(starting_balance=config.starting_balance_usd)

        db_final, repo_final, _, _, _ = build_paper_stack(self.db_path)
        account = await repo_final.get_account()
        self.assertIsNotNone(account)


if __name__ == "__main__":
    unittest.main()
