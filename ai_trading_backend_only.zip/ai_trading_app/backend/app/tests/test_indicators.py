import unittest

from app.services.market_data.models import InsufficientDataError
from app.signal_engine import indicators as ind
from app.tests.deterministic_dataset import make_flat_candles, make_trend_candles


class SmaEmaTests(unittest.TestCase):
    def test_sma_matches_manual_average(self):
        values = [1.0, 2.0, 3.0, 4.0, 5.0]
        self.assertAlmostEqual(ind.sma(values, 5), 3.0)
        self.assertAlmostEqual(ind.sma(values, 3), (3.0 + 4.0 + 5.0) / 3.0)

    def test_sma_insufficient_data_raises(self):
        with self.assertRaises(InsufficientDataError):
            ind.sma([1.0, 2.0], 5)

    def test_ema_seed_is_sma_of_first_period(self):
        values = [10.0] * 5 + [20.0]
        series = ind.ema_series(values, 5)
        self.assertAlmostEqual(series[0], 10.0)  # seeded by SMA of first 5 (all 10.0)

    def test_ema_reacts_faster_than_sma_to_new_data(self):
        # Flat at 100 for a while, then a jump — EMA should move further
        # toward the new value than SMA does, given the same window.
        values = [100.0] * 20 + [200.0]
        e = ind.ema(values, 10)
        s = ind.sma(values, 10)
        self.assertGreater(e, s)

    def test_ema_is_deterministic(self):
        values = [float(i) for i in range(1, 40)]
        self.assertEqual(ind.ema(values, 12), ind.ema(values, 12))


class RsiTests(unittest.TestCase):
    def test_rsi_all_gains_is_100(self):
        values = [float(i) for i in range(1, 30)]  # strictly increasing
        self.assertAlmostEqual(ind.rsi(values, 14), 100.0)

    def test_rsi_all_losses_is_0(self):
        values = [float(30 - i) for i in range(30)]  # strictly decreasing
        self.assertAlmostEqual(ind.rsi(values, 14), 0.0)

    def test_rsi_flat_series_is_50(self):
        values = [100.0] * 30
        self.assertAlmostEqual(ind.rsi(values, 14), 50.0, delta=1.0)

    def test_rsi_bounds(self):
        candles = make_trend_candles(count=100, trend_per_candle=15.0)
        closes = [c.close for c in candles]
        value = ind.rsi(closes, 14)
        self.assertGreaterEqual(value, 0.0)
        self.assertLessEqual(value, 100.0)

    def test_rsi_insufficient_data(self):
        with self.assertRaises(InsufficientDataError):
            ind.rsi([1.0, 2.0, 3.0], 14)


class MacdTests(unittest.TestCase):
    def test_macd_uptrend_is_positive_histogram_eventually(self):
        # A purely linear trend converges to a ~zero histogram (the
        # signal line catches up to a constant MACD line); an
        # accelerating trend keeps widening the fast/slow EMA spread,
        # which is what a real persistent-histogram bullish MACD looks
        # like in practice.
        candles = make_trend_candles(count=120, trend_per_candle=1.0, acceleration=0.5, wave_amplitude=0.0)
        closes = [c.close for c in candles]
        result = ind.macd(closes)
        self.assertGreater(result.histogram, 0)

    def test_macd_downtrend_is_negative_histogram(self):
        candles = make_trend_candles(count=120, trend_per_candle=-1.0, acceleration=-0.5, wave_amplitude=0.0)
        closes = [c.close for c in candles]
        result = ind.macd(closes)
        self.assertLess(result.histogram, 0)

    def test_macd_insufficient_data(self):
        with self.assertRaises(InsufficientDataError):
            ind.macd([float(i) for i in range(10)])

    def test_macd_rejects_invalid_periods(self):
        with self.assertRaises(ValueError):
            ind.macd([float(i) for i in range(50)], fast=26, slow=12)


class BollingerTests(unittest.TestCase):
    def test_bollinger_middle_is_sma(self):
        values = [float(i) for i in range(1, 25)]
        bands = ind.bollinger_bands(values, period=20)
        self.assertAlmostEqual(bands.middle, ind.sma(values, 20))

    def test_bollinger_upper_above_lower(self):
        candles = make_trend_candles(count=60)
        closes = [c.close for c in candles]
        bands = ind.bollinger_bands(closes)
        self.assertGreater(bands.upper, bands.lower)

    def test_bollinger_zero_variance_bands_collapse(self):
        values = [50.0] * 25
        bands = ind.bollinger_bands(values, period=20)
        self.assertAlmostEqual(bands.upper, bands.lower)

    def test_bollinger_insufficient_data(self):
        with self.assertRaises(InsufficientDataError):
            ind.bollinger_bands([1.0, 2.0, 3.0], period=20)


class AtrVolatilityTests(unittest.TestCase):
    def test_atr_is_positive_for_moving_market(self):
        candles = make_trend_candles(count=60)
        value = ind.atr(candles, 14)
        self.assertGreater(value, 0)

    def test_atr_insufficient_data(self):
        with self.assertRaises(InsufficientDataError):
            ind.atr(make_trend_candles(count=5), 14)

    def test_volatility_percent_scales_with_price(self):
        cheap = make_trend_candles(count=60, base_price=1.0, trend_per_candle=0.001, wave_amplitude=0.01)
        expensive = make_trend_candles(count=60, base_price=50_000.0, trend_per_candle=20, wave_amplitude=150)
        cheap_vol = ind.volatility_percent(cheap)
        expensive_vol = ind.volatility_percent(expensive)
        # Both should be well-formed percentages regardless of absolute price scale.
        self.assertGreater(cheap_vol, 0)
        self.assertGreater(expensive_vol, 0)


class VolumeMomentumTests(unittest.TestCase):
    def test_volume_spike_detected(self):
        volumes = [100.0] * 20 + [500.0]
        analysis = ind.volume_analysis(volumes, lookback=20, spike_threshold=2.0)
        self.assertTrue(analysis.is_spike)
        self.assertAlmostEqual(analysis.ratio, 5.0)

    def test_volume_no_spike(self):
        volumes = [100.0] * 21
        analysis = ind.volume_analysis(volumes, lookback=20, spike_threshold=2.0)
        self.assertFalse(analysis.is_spike)

    def test_volume_insufficient_data(self):
        with self.assertRaises(InsufficientDataError):
            ind.volume_analysis([100.0, 200.0], lookback=20)

    def test_momentum_positive_for_uptrend(self):
        candles = make_trend_candles(count=30, trend_per_candle=30.0, wave_amplitude=0.0)
        closes = [c.close for c in candles]
        self.assertGreater(ind.momentum_percent(closes, 10), 0)

    def test_momentum_negative_for_downtrend(self):
        candles = make_trend_candles(count=30, trend_per_candle=-30.0, wave_amplitude=0.0)
        closes = [c.close for c in candles]
        self.assertLess(ind.momentum_percent(closes, 10), 0)


class SupportResistanceStructureTests(unittest.TestCase):
    def test_support_below_resistance(self):
        candles = make_trend_candles(count=60)
        sr = ind.support_resistance(candles, lookback=50)
        self.assertLess(sr.support, sr.resistance)

    def test_market_structure_uptrend_detected(self):
        # Wave amplitude must dominate the per-candle trend step enough
        # to create real local swing highs/lows for the detector to find
        # (a trend that simply outpaces its own noise never pulls back,
        # so no swing points exist to compare) — the underlying drift
        # still nets out to a clear uptrend over the full window.
        candles = make_trend_candles(count=60, trend_per_candle=5.0, wave_amplitude=100.0, wave_period=10)
        self.assertEqual(ind.market_structure(candles, lookback=50), "uptrend")

    def test_market_structure_downtrend_detected(self):
        candles = make_trend_candles(count=60, trend_per_candle=-5.0, wave_amplitude=100.0, wave_period=10)
        self.assertEqual(ind.market_structure(candles, lookback=50), "downtrend")

    def test_market_structure_range_for_flat_market(self):
        candles = make_flat_candles(count=60)
        self.assertEqual(ind.market_structure(candles, lookback=50), "range")

    def test_market_structure_insufficient_data(self):
        with self.assertRaises(InsufficientDataError):
            ind.market_structure(make_trend_candles(count=10), lookback=50)


class OrderBookImbalanceTests(unittest.TestCase):
    def test_balanced_book_is_zero(self):
        self.assertAlmostEqual(ind.order_book_imbalance([10, 10], [10, 10]), 0.0)

    def test_bid_heavy_book_is_positive(self):
        value = ind.order_book_imbalance([100, 100], [10, 10])
        self.assertGreater(value, 0)
        self.assertLessEqual(value, 1.0)

    def test_ask_heavy_book_is_negative(self):
        value = ind.order_book_imbalance([10, 10], [100, 100])
        self.assertLess(value, 0)
        self.assertGreaterEqual(value, -1.0)

    def test_empty_book_is_zero(self):
        self.assertEqual(ind.order_book_imbalance([], []), 0.0)


class DeterminismTests(unittest.TestCase):
    """Re-running the exact same computation must always produce the
    exact same result — this is the crux of 'deterministic, no LLM'."""

    def test_full_indicator_pass_is_reproducible(self):
        def run():
            candles = make_trend_candles(count=120)
            closes = [c.close for c in candles]
            volumes = [c.volume for c in candles]
            return (
                ind.sma(closes, 20),
                ind.ema(closes, 20),
                ind.rsi(closes),
                ind.macd(closes).histogram,
                ind.bollinger_bands(closes).percent_b,
                ind.atr(candles),
                ind.volume_analysis(volumes).ratio,
                ind.momentum_percent(closes),
                ind.market_structure(candles, lookback=50),
            )

        self.assertEqual(run(), run())


if __name__ == "__main__":
    unittest.main()
