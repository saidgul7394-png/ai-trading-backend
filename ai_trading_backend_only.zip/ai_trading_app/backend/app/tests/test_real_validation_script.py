"""Tests for `run_real_validation.py` — confirms the Phase 4.1 CLI
script's core async logic honestly reports a blocked real-data run
(this sandbox's actual condition) rather than crashing or fabricating
results, and that on success it would write every expected report
file. Does not (and cannot, in this sandbox) test the real-data-success
path end-to-end — that requires genuine network access; see
`test_orchestrator_success_path_writes_all_expected_files` below for
how the file-writing logic is covered by exercising it directly
against the orchestrator's already-tested synthetic-fallback path
(test-only, never used by the script itself).
"""

from __future__ import annotations

import asyncio
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

_SCRIPT_PATH = Path(__file__).resolve().parents[2] / "run_real_validation.py"


def _load_script_module():
    spec = importlib.util.spec_from_file_location("run_real_validation", _SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RealValidationScriptBlockedPathTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(_SCRIPT_PATH.exists(), f"run_real_validation.py not found at {_SCRIPT_PATH}")
        self.module = _load_script_module()

    def test_async_main_reports_blocked_and_writes_manifest_without_crashing(self):
        with tempfile.TemporaryDirectory() as tmp:
            saved_argv = sys.argv
            try:
                sys.argv = [
                    "run_real_validation.py", "--symbols", "BTCUSDT", "--days", "5",
                    "--output-dir", tmp, "--cache-dir", str(Path(tmp) / "cache"),
                ]
                parsed = self.module.parse_args()
            finally:
                sys.argv = saved_argv

            return_code = asyncio.run(self.module._main_async(parsed))

            # In this sandbox (no network, no httpx), this MUST be the
            # honest blocked exit code — never 0 with fabricated results.
            self.assertEqual(return_code, 1)

            manifests = list(Path(tmp).glob("*/run_manifest.json"))
            self.assertEqual(len(manifests), 1)
            manifest = json.loads(manifests[0].read_text())
            self.assertEqual(manifest["data_provenance"], "real_data_blocked")
            self.assertFalse(manifest["real_data_used"])
            self.assertTrue(len(manifest["blocked_reasons"]) > 0)

            # No overall_report.json or trade journal should exist —
            # blocked means blocked, not "blocked but here are some
            # numbers anyway".
            self.assertEqual(len(list(Path(tmp).glob("*/overall_report.json"))), 0)
            self.assertEqual(len(list(Path(tmp).glob("*/trade_journal.csv"))), 0)

    def test_parameters_default_to_codebase_shipped_defaults_not_tuned(self):
        """Locks in Phase 4.1 requirement 7: the script's own argparse
        defaults must equal the codebase's shipped RiskLimits/
        PaperTradingConfig defaults, not some other value chosen to look
        favorable."""
        saved_argv = sys.argv
        try:
            sys.argv = ["run_real_validation.py", "--symbols", "BTCUSDT"]
            args = self.module.parse_args()
        finally:
            sys.argv = saved_argv

        sys.path.insert(0, str(_SCRIPT_PATH.parent))
        from app.paper_trading.pipeline import RiskLimits
        from app.paper_trading.config import PaperTradingConfig

        default_risk = RiskLimits()
        default_paper = PaperTradingConfig()

        self.assertEqual(args.min_confidence, default_risk.min_confidence)
        self.assertEqual(args.max_daily_loss_percent, default_risk.max_daily_loss_percent)
        self.assertEqual(args.max_risk_per_trade_percent, default_risk.max_risk_per_trade_percent)
        self.assertEqual(args.max_open_trades, default_risk.max_open_trades)
        self.assertEqual(args.starting_balance_usd, default_paper.starting_balance_usd)
        self.assertEqual(args.trade_amount_usd, default_paper.trade_amount_usd)


class DependencyVerificationTests(unittest.TestCase):
    def setUp(self):
        self.module = _load_script_module()

    def test_verify_dependencies_detects_missing_packages_in_this_sandbox(self):
        """This sandbox genuinely lacks fastapi/httpx/etc — confirms
        the detector finds them missing rather than false-reporting
        success."""
        missing = self.module.verify_or_install_dependencies(skip_install=True)
        self.assertIn("fastapi==0.115.0", missing)
        self.assertIn("httpx==0.27.2", missing)


if __name__ == "__main__":
    unittest.main()
