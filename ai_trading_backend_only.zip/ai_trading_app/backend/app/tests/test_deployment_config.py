"""Phase 5 — deployment/configuration tests.

These exist to make the Phase 5 deployment-safety requirements
MECHANICALLY enforced rather than only documented in DEPLOYMENT.md:
  - .env is actually gitignored, in both the Flutter root and backend/
  - no credential (Binance or otherwise) can leak into logs, config,
    or the git-tracked source tree
  - CORS configuration behaves correctly in dev vs production
  - /health and /health/ready exist with the expected response shape
  - production config can never resolve to a localhost/placeholder URL
  - live trading remains hard-disabled by default
  - the systemd/Docker deployment configs never run more than one
    Uvicorn worker process (which would duplicate the background
    paper-trading worker against the same SQLite file)

None of these require fastapi/httpx to be installed - they operate on
plain source text and the config module, matching every other test in
this suite's "environment-independent" convention (see
test_credential_safety.py for the established pattern this file
follows).
"""

from __future__ import annotations

import importlib
import os
import pathlib
import re
import unittest


def _repo_root() -> pathlib.Path:
    # backend/app/tests/test_deployment_config.py -> repo root is
    # three parents up from this file's directory (tests -> app ->
    # backend -> repo root).
    return pathlib.Path(__file__).resolve().parents[3]


def _backend_root() -> pathlib.Path:
    return pathlib.Path(__file__).resolve().parents[2]


class EnvFileIgnoredTests(unittest.TestCase):
    """`.env` must never be committed, at either the Flutter root or
    backend/ - checked directly against .gitignore's content rather
    than via `git check-ignore`, since this sandbox has no git
    repository initialized (see other Phase tests' conventions)."""

    def _gitignore_lines(self) -> list[str]:
        gitignore_path = _repo_root() / ".gitignore"
        self.assertTrue(gitignore_path.exists(), ".gitignore must exist at the repo root")
        return [line.strip() for line in gitignore_path.read_text().splitlines()]

    def test_flutter_root_env_is_ignored(self):
        lines = self._gitignore_lines()
        self.assertIn(".env", lines, "root .env must be gitignored")

    def test_backend_env_is_ignored(self):
        lines = self._gitignore_lines()
        self.assertIn("backend/.env", lines, "backend/.env must be gitignored")

    def test_local_and_production_env_variants_are_ignored(self):
        """Phase 5 introduces .env.local / .env.production as things a
        developer might copy to `.env` - if someone instead renames
        one of THESE files directly, it must still never be committed."""
        lines = self._gitignore_lines()
        self.assertIn(".env.local", lines)
        self.assertIn(".env.production", lines)

    def test_no_actual_env_file_exists_in_the_repo(self):
        """A real .env file (not .env.example/.env.local.example/etc.)
        should never actually be present in a checked-out copy of this
        repo - if one exists, something upstream (packaging, a stray
        commit) put a real config file where only templates belong."""
        for candidate in (_repo_root() / ".env", _backend_root() / ".env"):
            self.assertFalse(
                candidate.exists(),
                f"A real .env file exists at {candidate} - this should never be committed/shipped.",
            )

    def test_sqlite_artifacts_are_ignored(self):
        lines = self._gitignore_lines()
        self.assertIn("backend/*.sqlite3", lines)


class NoCredentialLeakageTests(unittest.TestCase):
    """Scans the actual template/example config files (the ones that
    ARE meant to be committed) for anything Binance-credential-shaped
    - these are exactly the files most likely to accidentally grow a
    "just paste your key here" field if someone isn't careful."""

    _FORBIDDEN_PATTERNS = [
        re.compile(r"^binance_api_key\s*=", re.IGNORECASE | re.MULTILINE),
        re.compile(r"^binance_api_secret\s*=", re.IGNORECASE | re.MULTILINE),
        re.compile(r"^binance[_-]?secret\s*=", re.IGNORECASE | re.MULTILINE),
    ]

    def _assert_file_has_no_binance_credential_fields(self, path: pathlib.Path):
        self.assertTrue(path.exists(), f"{path} should exist")
        text = path.read_text()
        for pattern in self._FORBIDDEN_PATTERNS:
            self.assertIsNone(
                pattern.search(text),
                f"{path} must not DEFINE a Binance credential field ({pattern.pattern}). "
                "A prose warning mentioning the forbidden name (e.g. 'do NOT add "
                "BINANCE_API_KEY') is fine and expected - only an actual "
                "KEY=value assignment is flagged.",
            )

    def test_backend_env_example_has_no_binance_credential_fields(self):
        self._assert_file_has_no_binance_credential_fields(_backend_root() / ".env.example")

    def test_flutter_env_examples_have_no_binance_credential_fields(self):
        for name in (".env.example", ".env.local.example", ".env.production.example"):
            path = _repo_root() / name
            if path.exists():
                self._assert_file_has_no_binance_credential_fields(path)

    def test_no_hardcoded_looking_secret_in_deploy_configs(self):
        """The deploy/ configs (systemd unit, Caddyfile, Dockerfile,
        compose file) must contain no literal secret value - only
        placeholders, env-file references, and paths."""
        pattern = re.compile(
            r"""(api_key|api_secret|password|secret)['\"]?\s*[:=]\s*['\"][A-Za-z0-9_\-]{16,}['\"]""",
            re.IGNORECASE,
        )
        deploy_dir = _backend_root() / "deploy"
        offenders = []
        for f in deploy_dir.iterdir():
            if not f.is_file():
                continue
            text = f.read_text(errors="ignore")
            if pattern.search(text):
                offenders.append(str(f))
        self.assertEqual(offenders, [], f"Possible hardcoded secret in: {offenders}")

    def test_binance_router_still_has_no_credential_accepting_endpoint(self):
        """Reconfirms the Phase 4.2 guarantee is still intact after
        Phase 5's changes - this backend must still have zero code
        paths that accept a Binance key/secret."""
        source = (_backend_root() / "app" / "api" / "routers" / "binance_router.py").read_text()
        for pattern in (r"api_key", r"api_secret", r"LinkBinanceRequest"):
            self.assertIsNone(
                re.search(pattern, source, re.IGNORECASE),
                f"binance_router.py must not reference '{pattern}'",
            )

    def test_stale_server_side_binance_endpoints_removed_from_flutter(self):
        """The pre-4.2 server-credential endpoint constants
        (binanceLinkKey/binanceUnlink/binanceAccount/binanceBalance)
        must stay removed from the Flutter API constants."""
        path = _repo_root() / "lib" / "core" / "constants" / "api_constants.dart"
        text = path.read_text()
        for stale_name in ("binanceLinkKey", "binanceUnlink", "binanceAccount", "binanceBalance"):
            self.assertNotIn(stale_name, text, f"Stale endpoint constant '{stale_name}' should have been removed")


class CorsConfigurationTests(unittest.TestCase):
    def setUp(self):
        # Ensure a clean settings cache and environment for each test -
        # get_settings() is lru_cache'd, so stale env vars from a
        # previous test would otherwise leak into this one.
        os.environ.pop("CORS_ALLOWED_ORIGINS", None)
        os.environ.pop("ENVIRONMENT", None)
        import app.core.config as config_module

        importlib.reload(config_module)
        self.config = config_module

    def tearDown(self):
        os.environ.pop("CORS_ALLOWED_ORIGINS", None)
        os.environ.pop("ENVIRONMENT", None)

    def test_cors_origins_empty_by_default(self):
        self.config.get_settings.cache_clear()
        self.assertEqual(self.config.cors_origins_list(), [])

    def test_cors_origins_parses_comma_separated_list(self):
        os.environ["CORS_ALLOWED_ORIGINS"] = "https://a.example.com,https://b.example.com"
        self.config.get_settings.cache_clear()
        self.assertEqual(
            self.config.cors_origins_list(),
            ["https://a.example.com", "https://b.example.com"],
        )

    def test_cors_origins_strips_whitespace_and_drops_empty_entries(self):
        os.environ["CORS_ALLOWED_ORIGINS"] = " https://a.example.com , , https://b.example.com ,"
        self.config.get_settings.cache_clear()
        self.assertEqual(
            self.config.cors_origins_list(),
            ["https://a.example.com", "https://b.example.com"],
        )

    def test_is_production_false_by_default(self):
        self.config.get_settings.cache_clear()
        self.assertFalse(self.config.is_production())

    def test_is_production_true_when_environment_is_production(self):
        os.environ["ENVIRONMENT"] = "production"
        self.config.get_settings.cache_clear()
        self.assertTrue(self.config.is_production())

    def test_main_py_gates_localhost_cors_on_development_only(self):
        """Reads main.py's source directly (fastapi isn't installed in
        this sandbox, so main.py cannot be imported here) and confirms
        the localhost CORS fallback is conditioned on
        environment == "development", never applied unconditionally."""
        source = (_backend_root() / "app" / "main.py").read_text()
        self.assertIn('settings.environment == "development"', source)
        self.assertIn("cors_origins_list()", source)


class HealthEndpointShapeTests(unittest.TestCase):
    """main.py cannot be imported in this sandbox (no fastapi
    installed), so these tests verify the endpoint definitions exist
    with the expected shape by reading the source directly - the same
    technique already used for main.py's CORS gating above and
    elsewhere in this test suite for fastapi-dependent files."""

    def setUp(self):
        self.source = (_backend_root() / "app" / "main.py").read_text()

    def test_health_endpoint_exists(self):
        self.assertIn('@app.get("/health"', self.source)

    def test_health_ready_endpoint_exists(self):
        self.assertIn('@app.get("/health/ready"', self.source)

    def test_health_reports_live_trading_status(self):
        self.assertIn("live_trading_enabled", self.source)

    def test_health_ready_checks_database_market_data_and_worker(self):
        for expected in ("database_reachable", "market_data_stream_healthy", "paper_trading_worker_running"):
            self.assertIn(expected, self.source)

    def test_health_ready_returns_503_when_not_ready(self):
        self.assertIn("503", self.source)

    def test_health_ready_never_touches_binance_credentials(self):
        # Locate just the health_ready function body and confirm it
        # contains no credential-shaped reference.
        match = re.search(r"async def health_ready.*?(?=\n@app\.|\Z)", self.source, re.DOTALL)
        self.assertIsNotNone(match, "could not locate health_ready function body")
        body = match.group(0)
        for forbidden in ("api_key", "api_secret", "binance_key", "binance_secret"):
            self.assertNotIn(forbidden, body.lower())


class ProductionLocalhostGuardTests(unittest.TestCase):
    """Flutter-side guard: since fastapi/dart tooling can't run in
    this sandbox, these tests check the guard's SOURCE LOGIC by
    re-implementing the exact same heuristic in Python against the
    same inputs the Dart implementation documents, as a cross-check
    that the documented behavior in api_constants.dart matches what
    main.dart actually calls. This does not replace `flutter test`
    (see test/core/... for the real Dart-side tests) - it is a
    sandbox-only sanity cross-check.
    """

    def setUp(self):
        self.api_constants_source = (
            _repo_root() / "lib" / "core" / "constants" / "api_constants.dart"
        ).read_text()
        self.main_dart_source = (_repo_root() / "lib" / "main.dart").read_text()

    def test_is_likely_production_unsafe_getter_exists(self):
        self.assertIn("isLikelyProductionUnsafe", self.api_constants_source)

    def test_guard_checks_placeholder_domain(self):
        self.assertIn("_placeholderBaseUrl", self.api_constants_source)
        self.assertIn("if (url == _placeholderBaseUrl) return true;", self.api_constants_source)

    def test_guard_checks_localhost_and_loopback(self):
        self.assertIn("'localhost'", self.api_constants_source)
        self.assertIn("'127.0.0.1'", self.api_constants_source)

    def test_guard_checks_emulator_host_alias(self):
        self.assertIn("'10.0.2.2'", self.api_constants_source)

    def test_guard_checks_private_lan_ranges(self):
        self.assertIn("192.168.", self.api_constants_source)
        self.assertIn(r"^172\.(1[6-9]|2\d|3[01])\.", self.api_constants_source)

    def test_main_dart_invokes_guard_only_in_release_mode(self):
        self.assertIn("kReleaseMode", self.main_dart_source)
        self.assertIn("_guardAgainstUnsafeProductionBaseUrl", self.main_dart_source)
        # The guard function itself must early-return for non-release
        # builds - confirms debug/profile builds are exempt (pointing
        # a debug build at a local dev backend is the normal workflow).
        match = re.search(
            r"void _guardAgainstUnsafeProductionBaseUrl\(\).*?(?=\n\w|\Z)",
            self.main_dart_source,
            re.DOTALL,
        )
        self.assertIsNotNone(match)
        self.assertIn("if (!kReleaseMode) return;", match.group(0))

    def test_guard_throws_rather_than_just_logging(self):
        match = re.search(
            r"void _guardAgainstUnsafeProductionBaseUrl\(\).*?(?=\n\w|\Z)",
            self.main_dart_source,
            re.DOTALL,
        )
        self.assertIsNotNone(match)
        self.assertIn("throw StateError", match.group(0))


class LiveTradingRemainsDisabledTests(unittest.TestCase):
    def setUp(self):
        os.environ.pop("LIVE_TRADING_ENABLED", None)
        import app.core.config as config_module

        importlib.reload(config_module)
        self.config = config_module
        self.config.get_settings.cache_clear()

    def tearDown(self):
        os.environ.pop("LIVE_TRADING_ENABLED", None)

    def test_live_trading_enabled_defaults_false(self):
        self.assertFalse(self.config.get_settings().live_trading_enabled)

    def test_env_example_ships_live_trading_disabled(self):
        text = (_backend_root() / ".env.example").read_text()
        self.assertIn("LIVE_TRADING_ENABLED=false", text)

    def test_deploy_script_does_not_set_live_trading_enabled_true(self):
        """The deployment script must never set this to true on the
        operator's behalf - only a human manually editing .env can."""
        text = (_backend_root() / "deploy" / "deploy.sh").read_text()
        self.assertNotIn("LIVE_TRADING_ENABLED=true", text)

    def test_no_remote_endpoint_can_enable_live_trading(self):
        """Scans every router file for anything that writes to
        live_trading_enabled - there must be none; only server-side
        environment configuration can set this."""
        routers_dir = _backend_root() / "app" / "api" / "routers"
        offenders = []
        for f in routers_dir.glob("*.py"):
            text = f.read_text()
            if re.search(r"live_trading_enabled\s*=", text):
                offenders.append(str(f))
        self.assertEqual(offenders, [], f"A router appears to set live_trading_enabled: {offenders}")


class NoDuplicateWorkerConfigurationTests(unittest.TestCase):
    """Confirms the deployment configs never run more than one Uvicorn
    worker process against the same SQLite-backed paper-trading
    worker - see ai-trading-backend.service's and Dockerfile's own
    inline comments on why this matters."""

    def test_systemd_unit_does_not_set_workers_flag(self):
        text = (_backend_root() / "deploy" / "ai-trading-backend.service").read_text()
        # The ONLY occurrences of "--workers" must be in explanatory
        # comment lines (a real flag usage would appear on the
        # ExecStart continuation lines without a leading '#').
        for line in text.splitlines():
            if "--workers" in line:
                self.assertTrue(
                    line.strip().startswith("#"),
                    f"Found a non-comment --workers usage in systemd unit: {line!r}",
                )

    def test_dockerfile_cmd_does_not_set_workers_flag(self):
        text = (_backend_root() / "deploy" / "Dockerfile").read_text()
        cmd_match = re.search(r'^CMD \[.*\]$', text, re.MULTILINE)
        self.assertIsNotNone(cmd_match, "Dockerfile must have a CMD instruction")
        self.assertNotIn("--workers", cmd_match.group(0))

    def test_main_py_has_exactly_one_background_worker_instantiation(self):
        text = (_backend_root() / "app" / "main.py").read_text()
        self.assertEqual(text.count("BackgroundWorker("), 1)
        self.assertEqual(text.count("background_worker.start()"), 1)


if __name__ == "__main__":
    unittest.main()
