"""Deterministic synthetic candle generators for tests.

No `random` module usage anywhere here — every series is built from a
closed-form formula (linear trend + sine wave) so re-running the test
suite always produces byte-identical candles and therefore identical
indicator/signal outputs. This is what the Phase 2 spec means by "a
deterministic test dataset so results are reproducible".
"""

from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone

from app.services.market_data.models import Candle, INTERVAL_SECONDS

EPOCH = datetime(2025, 1, 1, tzinfo=timezone.utc)


def _candle_from_close(
    symbol: str,
    interval: str,
    index: int,
    prev_close: float,
    close: float,
    volume: float,
) -> Candle:
    open_time = EPOCH + timedelta(seconds=INTERVAL_SECONDS[interval] * index)
    close_time = open_time + timedelta(seconds=INTERVAL_SECONDS[interval])
    open_price = prev_close
    wick = abs(close - open_price) * 0.3 + 0.01
    high = max(open_price, close) + wick
    low = min(open_price, close) - wick
    return Candle(
        symbol=symbol,
        interval=interval,
        open_time=open_time,
        close_time=close_time,
        open=open_price,
        high=high,
        low=low,
        close=close,
        volume=volume,
        is_closed=True,
    )


def make_trend_candles(
    *,
    symbol: str = "BTCUSDT",
    interval: str = "1h",
    count: int = 120,
    base_price: float = 50_000.0,
    trend_per_candle: float = 20.0,
    wave_amplitude: float = 150.0,
    wave_period: int = 12,
    base_volume: float = 100.0,
    acceleration: float = 0.0,
) -> list[Candle]:
    """A steadily uptrending (trend_per_candle > 0) or downtrending
    (< 0) series with a small oscillation layered on top so RSI/MACD/
    Bollinger see realistic back-and-forth rather than a straight line.
    `acceleration` adds an i^2 term for tests that need a persistently
    widening (not just linearly drifting) moving-average spread.
    """
    closes = []
    for i in range(count):
        wave = wave_amplitude * math.sin(2 * math.pi * i / wave_period)
        closes.append(base_price + trend_per_candle * i + acceleration * i * i + wave)

    candles = []
    prev_close = closes[0] - trend_per_candle
    for i, close in enumerate(closes):
        volume = base_volume + 10 * math.sin(2 * math.pi * i / 7)
        candles.append(_candle_from_close(symbol, interval, i, prev_close, close, max(volume, 1.0)))
        prev_close = close
    return candles


def make_flat_candles(
    *,
    symbol: str = "BTCUSDT",
    interval: str = "1h",
    count: int = 120,
    base_price: float = 50_000.0,
    noise_amplitude: float = 25.0,
    base_volume: float = 100.0,
) -> list[Candle]:
    """A range-bound (non-trending) series — used to exercise the
    "market_structure == range" and low-conviction / HOLD paths."""
    closes = []
    for i in range(count):
        closes.append(base_price + noise_amplitude * math.sin(2 * math.pi * i / 6))

    candles = []
    prev_close = closes[0]
    for i, close in enumerate(closes):
        candles.append(_candle_from_close(symbol, interval, i, prev_close, close, base_volume))
        prev_close = close
    return candles


def make_conflicting_candles(
    *, symbol: str = "ETHUSDT", interval: str = "1h", count: int = 120, base_price: float = 3_000.0
) -> list[Candle]:
    """Constructed so different indicators disagree: a slow long-term
    uptrend (bullish EMA/SMA/market-structure) combined with a sharp
    recent RSI-overbought spike and a bearish MACD roll-over — used to
    exercise the conflict-detection HOLD path."""
    closes = []
    for i in range(count):
        long_trend = base_price + 8.0 * i
        if i >= count - 6:
            # Sharp recent spike up then a fast rollover — pushes RSI to
            # overbought while the short EMA cross flips bearish, against
            # the still-bullish long-term SMA/market structure.
            spike_index = i - (count - 6)
            spike = [220, 260, 180, 60, -80, -160][spike_index]
            closes.append(long_trend + spike)
        else:
            closes.append(long_trend)

    candles = []
    prev_close = closes[0] - 8.0
    for i, close in enumerate(closes):
        volume = 100.0 + (300.0 if i >= count - 3 else 0.0)  # volume spike into the rollover
        candles.append(_candle_from_close(symbol, interval, i, prev_close, close, volume))
        prev_close = close
    return candles


def make_insufficient_candles(*, symbol: str = "BTCUSDT", interval: str = "1h", count: int = 10) -> list[Candle]:
    """Too few candles for most indicators — exercises InsufficientDataError
    / HOLD-on-insufficient-data paths."""
    return make_trend_candles(symbol=symbol, interval=interval, count=count)


def multi_timeframe_dataset(
    *,
    symbol: str = "BTCUSDT",
    trend_per_candle: float = 20.0,
    wave_amplitude: float = 100.0,
    wave_period: int = 10,
    counts: dict[str, int] | None = None,
) -> dict[str, list[Candle]]:
    """One consistent trend rendered across several timeframes, so
    multi-timeframe confirmation agrees by construction. Default wave
    parameters are tuned relative to the default trend so real local
    swing highs/lows form (needed for market_structure to register a
    trend rather than "range") while the net drift still dominates.
    """
    counts = counts or {"15m": 120, "1h": 120, "4h": 120}
    return {
        tf: make_trend_candles(
            symbol=symbol,
            interval=tf,
            count=n,
            trend_per_candle=trend_per_candle,
            wave_amplitude=wave_amplitude,
            wave_period=wave_period,
        )
        for tf, n in counts.items()
    }
