"""Serves Open Trades, Trade History, and Trade Details from the Phase 3
paper-trading store. `mode` is always "paper" here — this router will
also surface live trades once Phase 4 implements real Binance order
placement, at which point `mode` distinguishes the two.
"""

from fastapi import APIRouter, Depends, HTTPException

from ...core.dependencies import get_market_data_service, get_paper_repository
from ...paper_trading.models import PaperPosition
from ...paper_trading.repository import DEFAULT_ACCOUNT_ID, PaperTradingRepository
from ...schemas.trade_schemas import TradeSchema
from ...services.market_data.service import MarketDataService

router = APIRouter(prefix="/v1/trades", tags=["trades"])


async def _to_schema(position: PaperPosition, market_data: MarketDataService) -> TradeSchema:
    unrealized_pnl = 0.0
    unrealized_pnl_percent = 0.0
    if position.status.value == "OPEN":
        try:
            price = await market_data.get_price(position.symbol)
            unrealized_pnl = position.unrealized_pnl(price)
            unrealized_pnl_percent = position.unrealized_pnl_percent(price)
        except Exception:  # noqa: BLE001 — price unavailable, report 0 rather than fabricate
            pass

    return TradeSchema(
        id=position.id,
        binance_order_id=position.client_order_id,  # paper trades never touch Binance; this is the paper order id
        symbol=position.symbol,
        side="long" if position.side.value == "LONG" else "short",
        status=position.status.value.lower(),
        mode="paper",
        entry_price=position.entry_price,
        quantity=position.quantity,
        stop_loss=position.stop_loss,
        take_profit=position.take_profit,
        exit_price=position.exit_price,
        exit_reason=position.exit_reason.value.lower() if position.exit_reason else "none",
        unrealized_pnl=unrealized_pnl,
        unrealized_pnl_percent=unrealized_pnl_percent,
        realized_pnl=position.realized_pnl,
        opened_at=position.opened_at,
        closed_at=position.closed_at,
        signal_id=position.signal_id,
        signal_confidence_at_entry=position.signal_confidence_at_entry,
    )


@router.get("/open", response_model=list[TradeSchema])
async def get_open_trades(
    repo: PaperTradingRepository = Depends(get_paper_repository),
    market_data: MarketDataService = Depends(get_market_data_service),
):
    positions = await repo.get_open_positions(DEFAULT_ACCOUNT_ID)
    return [await _to_schema(p, market_data) for p in positions]


@router.get("/history", response_model=list[TradeSchema])
async def get_trade_history(
    page: int = 0,
    page_size: int = 50,
    repo: PaperTradingRepository = Depends(get_paper_repository),
    market_data: MarketDataService = Depends(get_market_data_service),
):
    positions = await repo.get_trade_history(DEFAULT_ACCOUNT_ID, limit=page_size)
    return [await _to_schema(p, market_data) for p in positions]


@router.get("/{trade_id}", response_model=TradeSchema)
async def get_trade(
    trade_id: str,
    repo: PaperTradingRepository = Depends(get_paper_repository),
    market_data: MarketDataService = Depends(get_market_data_service),
):
    position = await repo.get_position(trade_id)
    if position is None:
        raise HTTPException(status_code=404, detail="Trade not found")
    return await _to_schema(position, market_data)


@router.post("/{trade_id}/close", response_model=TradeSchema)
async def close_trade(
    trade_id: str,
    repo: PaperTradingRepository = Depends(get_paper_repository),
    market_data: MarketDataService = Depends(get_market_data_service),
):
    """Manual close — bypasses the entry-side risk gate (exits are
    always allowed; only new entries are risk-gated), but still goes
    through the same engine.close_position path as every automatic
    exit, so fees/slippage/idempotency are identical."""
    from ...paper_trading.engine import PaperExecutionEngine
    from ...paper_trading.config import DEFAULT_PAPER_CONFIG
    from ...paper_trading.models import ExitReason

    position = await repo.get_position(trade_id)
    if position is None:
        raise HTTPException(status_code=404, detail="Trade not found")
    if position.status.value != "OPEN":
        raise HTTPException(status_code=409, detail=f"Trade is not open (status={position.status.value})")

    try:
        price = await market_data.get_price(position.symbol)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=503, detail=f"Cannot close: price unavailable for {position.symbol}: {e}")

    engine = PaperExecutionEngine(repository=repo, config=DEFAULT_PAPER_CONFIG)
    closed = await engine.close_position(position, reference_price=price, exit_reason=ExitReason.MANUAL)
    if closed is None:
        raise HTTPException(status_code=409, detail="Trade was already being closed by another request")

    return await _to_schema(closed, market_data)
