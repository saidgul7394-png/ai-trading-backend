from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/v1/notifications", tags=["notifications"])


@router.get("")
async def get_notifications():
    raise HTTPException(status_code=501, detail="Not implemented in Phase 1 scaffold")
