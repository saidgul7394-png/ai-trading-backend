"""Risk status/emergency-stop endpoints. In Phase 3 scope these reflect
the paper-trading risk state (the only state that's real right now) —
functionally identical to `/v1/paper-trading/emergency-stop*`, kept as
a separate router because the Flutter app's Risk Management screen and
Emergency Stop screen were scaffolded against `/v1/risk/*` in Phase 1,
before paper trading existed. Once live trading exists, this router
becomes the one place that reflects BOTH paper and live risk state.
"""

from fastapi import APIRouter, Depends

from ...core.dependencies import get_paper_repository, get_trading_pipeline
from ...paper_trading.pipeline import TradingPipeline
from ...paper_trading.repository import DEFAULT_ACCOUNT_ID, PaperTradingRepository
from ...schemas.trade_schemas import EmergencyStopRequest, RiskStatusSchema

router = APIRouter(prefix="/v1/risk", tags=["risk"])


@router.get("/status", response_model=RiskStatusSchema)
async def get_risk_status(repo: PaperTradingRepository = Depends(get_paper_repository)):
    circuit_breaker = await repo.get_flag("circuit_breaker_tripped")
    emergency_stop = await repo.get_flag("emergency_stop_active")

    open_positions = await repo.get_open_positions(DEFAULT_ACCOUNT_ID)
    daily_trades = await repo.count_trades_opened_today(DEFAULT_ACCOUNT_ID)
    daily_loss_percent = await repo.realized_loss_today_percent(DEFAULT_ACCOUNT_ID)

    blocking_reasons: list[str] = []
    if circuit_breaker:
        blocking_reasons.append("Circuit breaker tripped")
    if emergency_stop:
        blocking_reasons.append("Emergency stop active")

    return RiskStatusSchema(
        circuit_breaker_tripped=circuit_breaker,
        emergency_stop_active=emergency_stop,
        daily_loss_used_percent=daily_loss_percent,
        max_daily_loss_percent=3.0,  # mirrors pipeline.RiskLimits default; Phase 4: per-user settings
        daily_trades_used=daily_trades,
        max_daily_trades=None,
        open_trades_count=len(open_positions),
        max_open_trades=3,
        cooldown_active=False,  # per-symbol, not meaningful as a single flag — see /paper-trading/positions
        blocking_reasons=blocking_reasons,
    )


@router.post("/emergency-stop")
async def trigger_emergency_stop(
    payload: EmergencyStopRequest,
    pipeline: TradingPipeline = Depends(get_trading_pipeline),
    repo: PaperTradingRepository = Depends(get_paper_repository),
):
    closed_symbols = await pipeline.trigger_emergency_stop(close_positions=payload.close_open_positions)
    active = await repo.get_flag("emergency_stop_active")
    return {"emergency_stop_active": active, "closed_symbols": closed_symbols}


@router.post("/emergency-stop/clear")
async def clear_emergency_stop(
    pipeline: TradingPipeline = Depends(get_trading_pipeline),
    repo: PaperTradingRepository = Depends(get_paper_repository),
):
    await pipeline.clear_emergency_stop()
    active = await repo.get_flag("emergency_stop_active")
    return {"emergency_stop_active": active}
