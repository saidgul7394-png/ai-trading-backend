from fastapi import APIRouter, Depends, HTTPException, Query

from ...core.dependencies import get_signal_service
from ...schemas.signal_schemas import LatestSignalsResponse, SignalFactorSchema, TradingSignalSchema
from ...services.market_data.models import (
    MarketDataError,
    UnsupportedIntervalError,
    UnsupportedSymbolError,
)
from ...signal_engine.composite import CompositeSignal
from ...signal_engine.service import SignalGenerationService

router = APIRouter(prefix="/v1/signals", tags=["signals"])

# The set of symbols this endpoint will compute signals for when no
# specific `symbol` filter is supplied. Kept in sync with
# core/config.py's default watch-list in a later phase; hardcoded here
# for Phase 2 so /latest has sensible default behavior.
DEFAULT_WATCHLIST = ("BTCUSDT", "ETHUSDT", "BNBUSDT")


def _to_schema(signal: CompositeSignal) -> TradingSignalSchema:
    return TradingSignalSchema(
        id=f"{signal.symbol}-{signal.timeframe}-{int(signal.generated_at.timestamp())}",
        symbol=signal.symbol,
        timeframe=signal.timeframe,
        action=signal.action,
        confidence=signal.confidence,
        strength="strong" if signal.confidence >= 0.66 else "moderate" if signal.confidence >= 0.33 else "weak",
        entry_price=signal.entry_price,
        stop_loss=signal.stop_loss,
        take_profit=signal.take_profit,
        risk_reward_ratio=signal.risk_reward_ratio,
        reasons=signal.reasons,
        contributing_factors=[
            SignalFactorSchema(name=f.name, value=f.value, weight=f.weight, leaning=f.leaning)
            for f in signal.factors
        ],
        generated_at=signal.generated_at,
        data_freshness_seconds=signal.data_freshness_seconds or 0,
        eligible_for_auto_trade=signal.eligible_for_auto_trade,
        rejection_reason=signal.rejection_reason,
    )


@router.get("/latest", response_model=LatestSignalsResponse)
async def get_latest_signals(
    symbol: str | None = Query(default=None),
    timeframe: str = Query(default="1h"),
    service: SignalGenerationService = Depends(get_signal_service),
):
    """Computes fresh signals on demand for the requested symbol (or the
    default watchlist). Phase 2 note: this computes synchronously per
    request; a later phase should move to a background worker loop that
    continuously refreshes a cache, with this endpoint just reading it —
    called out in README's suggested Phase 3.
    """
    symbols = [symbol] if symbol else list(DEFAULT_WATCHLIST)
    signals = []
    for sym in symbols:
        try:
            signal = await service.generate_signal(sym, timeframe)
            signals.append(_to_schema(signal))
        except (UnsupportedSymbolError, UnsupportedIntervalError) as e:
            if symbol:  # explicit single-symbol request — surface the error
                raise HTTPException(status_code=422, detail=str(e))
            continue  # skip unsupported symbols when serving the default watchlist
        except MarketDataError as e:
            if symbol:
                raise HTTPException(status_code=503, detail=f"Market data unavailable: {e}")
            continue

    return LatestSignalsResponse(signals=signals)
