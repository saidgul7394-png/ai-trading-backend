from fastapi import APIRouter, Depends, HTTPException

from ...core.dependencies import get_market_data_service
from ...schemas.market_schemas import (
    CandleSchema,
    CandlesResponse,
    OrderBookLevelSchema,
    OrderBookResponse,
    PriceResponse,
)
from ...services.market_data.models import (
    MarketDataError,
    UnsupportedIntervalError,
    UnsupportedSymbolError,
    validate_interval,
    validate_symbol,
)
from ...services.market_data.service import MarketDataService

router = APIRouter(prefix="/v1/market", tags=["market"])


@router.get("/prices", response_model=PriceResponse)
async def get_prices(
    symbol: str,
    market_data: MarketDataService = Depends(get_market_data_service),
):
    try:
        validate_symbol(symbol, market_data.symbols)
    except UnsupportedSymbolError as e:
        raise HTTPException(status_code=422, detail=str(e))

    # Live price is intentionally fetched directly (not cached) — it's
    # cheap (weight 1) and callers want the current tick, not the last
    # closed candle's close.
    try:
        price = await market_data.get_price(symbol)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=503, detail=f"Failed to fetch price: {e}")

    return PriceResponse(symbol=symbol.upper(), price=price)


@router.get("/candles", response_model=CandlesResponse)
async def get_candles(
    symbol: str,
    interval: str = "15m",
    limit: int = 200,
    market_data: MarketDataService = Depends(get_market_data_service),
):
    try:
        symbol = validate_symbol(symbol, market_data.symbols)
        interval = validate_interval(interval)
    except (UnsupportedSymbolError, UnsupportedIntervalError) as e:
        raise HTTPException(status_code=422, detail=str(e))

    candles = await market_data.get_candles(symbol, interval, limit=limit)
    if not candles:
        raise HTTPException(
            status_code=503,
            detail=f"No cached candles for {symbol} {interval} yet — backfill may still be running.",
        )

    freshness = await market_data.freshness_seconds(symbol, interval)

    return CandlesResponse(
        symbol=symbol,
        interval=interval,
        candles=[
            CandleSchema(
                open_time=c.open_time,
                close_time=c.close_time,
                open=c.open,
                high=c.high,
                low=c.low,
                close=c.close,
                volume=c.volume,
            )
            for c in candles
        ],
        freshness_seconds=freshness,
    )


@router.get("/orderbook", response_model=OrderBookResponse)
async def get_order_book(
    symbol: str,
    depth: int = 20,
    market_data: MarketDataService = Depends(get_market_data_service),
):
    try:
        validate_symbol(symbol, market_data.symbols)
    except UnsupportedSymbolError as e:
        raise HTTPException(status_code=422, detail=str(e))

    try:
        book = await market_data.get_order_book(symbol, depth=depth)
    except MarketDataError as e:
        raise HTTPException(status_code=503, detail=f"Order book unavailable: {e}")

    return OrderBookResponse(
        symbol=book.symbol,
        bids=[OrderBookLevelSchema(price=level.price, quantity=level.quantity) for level in book.bids],
        asks=[OrderBookLevelSchema(price=level.price, quantity=level.quantity) for level in book.asks],
        mid_price=book.mid_price,
    )
