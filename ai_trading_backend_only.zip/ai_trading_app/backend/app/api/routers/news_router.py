from fastapi import APIRouter, HTTPException, Query

router = APIRouter(prefix="/v1/news", tags=["news"])


@router.get("/latest")
async def get_latest_news(symbols: str | None = Query(default=None)):
    raise HTTPException(status_code=501, detail="Not implemented in Phase 1 scaffold")
