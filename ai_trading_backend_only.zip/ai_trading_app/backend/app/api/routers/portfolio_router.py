from datetime import datetime, timezone

from fastapi import APIRouter, Depends

from ...core.dependencies import get_market_data_service, get_paper_repository
from ...paper_trading.repository import DEFAULT_ACCOUNT_ID, PaperTradingRepository
from ...schemas.portfolio_schemas import PortfolioSummarySchema
from ...services.market_data.service import MarketDataService

router = APIRouter(prefix="/v1/portfolio", tags=["portfolio"])


@router.get("/summary", response_model=PortfolioSummarySchema)
async def get_portfolio_summary(
    repo: PaperTradingRepository = Depends(get_paper_repository),
    market_data: MarketDataService = Depends(get_market_data_service),
):
    account = await repo.get_or_create_account(starting_balance=10_000.0, account_id=DEFAULT_ACCOUNT_ID)
    open_positions = await repo.get_open_positions(DEFAULT_ACCOUNT_ID)
    stats = await repo.get_trade_stats(DEFAULT_ACCOUNT_ID)

    today = datetime.now(timezone.utc).date().isoformat()
    history = await repo.get_trade_history(DEFAULT_ACCOUNT_ID, limit=500)
    today_realized_pnl = sum(
        p.realized_pnl or 0.0 for p in history if p.closed_at and p.closed_at.date().isoformat() == today
    )

    today_unrealized_pnl = 0.0
    for position in open_positions:
        try:
            price = await market_data.get_price(position.symbol)
            today_unrealized_pnl += position.unrealized_pnl(price)
        except Exception:  # noqa: BLE001 — a stale/unavailable price just excludes that position, never fabricates one
            continue

    today_pnl = today_realized_pnl + today_unrealized_pnl
    today_pnl_percent = (today_pnl / account.starting_balance * 100.0) if account.starting_balance else 0.0

    avg_rr = 0.0
    if open_positions:
        rrs = []
        for p in open_positions:
            risk = abs(p.entry_price - p.stop_loss)
            reward = abs(p.take_profit - p.entry_price)
            if risk > 0:
                rrs.append(reward / risk)
        avg_rr = sum(rrs) / len(rrs) if rrs else 0.0

    return PortfolioSummarySchema(
        total_balance_usd=account.current_balance,
        available_balance_usd=account.current_balance,
        today_pnl_usd=today_pnl,
        today_pnl_percent=today_pnl_percent,
        all_time_pnl_usd=stats.total_realized_pnl,
        open_trades_count=len(open_positions),
        win_rate_percent=stats.win_rate_percent,
        total_trades=stats.total_trades,
        winning_trades=stats.winning_trades,
        losing_trades=stats.losing_trades,
        avg_risk_reward_ratio=avg_rr,
        last_updated=datetime.now(timezone.utc),
    )
