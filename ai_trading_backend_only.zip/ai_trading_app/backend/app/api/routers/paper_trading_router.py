from fastapi import APIRouter, Depends, HTTPException

from ...core.dependencies import get_background_worker, get_paper_repository, get_trading_pipeline
from ...paper_trading.models import PaperPosition
from ...paper_trading.pipeline import TradingPipeline
from ...paper_trading.repository import DEFAULT_ACCOUNT_ID, PaperTradingRepository
from ...paper_trading.worker import BackgroundWorker
from ...schemas.paper_trading_schemas import (
    EmergencyStopRequest,
    EmergencyStopResponse,
    PaperAccountSchema,
    PaperPositionSchema,
    PaperTradingDashboardResponse,
    TradeStatsSchema,
)

router = APIRouter(prefix="/v1/paper-trading", tags=["paper-trading"])


def _position_to_schema(position: PaperPosition, *, current_price: float | None = None) -> PaperPositionSchema:
    unrealized_pnl = None
    unrealized_pnl_percent = None
    if position.status.value == "OPEN" and current_price is not None:
        unrealized_pnl = position.unrealized_pnl(current_price)
        unrealized_pnl_percent = position.unrealized_pnl_percent(current_price)

    return PaperPositionSchema(
        id=position.id,
        symbol=position.symbol,
        side=position.side.value,
        status=position.status.value,
        entry_price=position.entry_price,
        quantity=position.quantity,
        stop_loss=position.stop_loss,
        take_profit=position.take_profit,
        trailing_stop_price=position.trailing_stop_price,
        trailing_stop_active=position.trailing_stop_active,
        exit_price=position.exit_price,
        exit_reason=position.exit_reason.value if position.exit_reason else None,
        realized_pnl=position.realized_pnl,
        unrealized_pnl=unrealized_pnl,
        unrealized_pnl_percent=unrealized_pnl_percent,
        entry_fee=position.entry_fee,
        exit_fee=position.exit_fee,
        signal_id=position.signal_id,
        signal_confidence_at_entry=position.signal_confidence_at_entry,
        opened_at=position.opened_at,
        closed_at=position.closed_at,
        max_holding_seconds=position.max_holding_seconds,
    )


@router.get("/dashboard", response_model=PaperTradingDashboardResponse)
async def get_dashboard(
    repo: PaperTradingRepository = Depends(get_paper_repository),
    worker: BackgroundWorker = Depends(get_background_worker),
):
    account = await repo.get_account(DEFAULT_ACCOUNT_ID)
    if account is None:
        raise HTTPException(status_code=503, detail="Paper account not initialized yet")

    open_positions = await repo.get_open_positions(DEFAULT_ACCOUNT_ID)
    stats = await repo.get_trade_stats(DEFAULT_ACCOUNT_ID)
    emergency_stop = await repo.get_flag("emergency_stop_active")
    heartbeat = await repo.get_worker_heartbeat()

    return PaperTradingDashboardResponse(
        account=PaperAccountSchema(
            id=account.id,
            starting_balance=account.starting_balance,
            current_balance=account.current_balance,
            created_at=account.created_at,
        ),
        open_positions=[_position_to_schema(p) for p in open_positions],
        stats=TradeStatsSchema(**stats.__dict__),
        worker_running=worker.is_running,
        emergency_stop_active=emergency_stop,
        last_worker_run_at=heartbeat.get("last_run_at"),
    )


@router.get("/positions/open", response_model=list[PaperPositionSchema])
async def get_open_positions(repo: PaperTradingRepository = Depends(get_paper_repository)):
    positions = await repo.get_open_positions(DEFAULT_ACCOUNT_ID)
    return [_position_to_schema(p) for p in positions]


@router.get("/positions/history", response_model=list[PaperPositionSchema])
async def get_trade_history(
    limit: int = 100,
    repo: PaperTradingRepository = Depends(get_paper_repository),
):
    positions = await repo.get_trade_history(DEFAULT_ACCOUNT_ID, limit=limit)
    return [_position_to_schema(p) for p in positions]


@router.get("/stats", response_model=TradeStatsSchema)
async def get_stats(repo: PaperTradingRepository = Depends(get_paper_repository)):
    stats = await repo.get_trade_stats(DEFAULT_ACCOUNT_ID)
    return TradeStatsSchema(**stats.__dict__)


@router.post("/refresh-now")
async def refresh_now(worker: BackgroundWorker = Depends(get_background_worker)):
    """Triggers one immediate pipeline cycle rather than waiting for the
    next scheduled interval — used by the Flutter app's pull-to-refresh."""
    result = await worker.run_once()
    return result


@router.post("/emergency-stop", response_model=EmergencyStopResponse)
async def trigger_emergency_stop(
    payload: EmergencyStopRequest,
    pipeline: TradingPipeline = Depends(get_trading_pipeline),
    repo: PaperTradingRepository = Depends(get_paper_repository),
):
    closed_symbols = await pipeline.trigger_emergency_stop(close_positions=payload.close_positions)
    active = await repo.get_flag("emergency_stop_active")
    return EmergencyStopResponse(emergency_stop_active=active, closed_symbols=closed_symbols)


@router.post("/emergency-stop/clear", response_model=EmergencyStopResponse)
async def clear_emergency_stop(
    pipeline: TradingPipeline = Depends(get_trading_pipeline),
    repo: PaperTradingRepository = Depends(get_paper_repository),
):
    await pipeline.clear_emergency_stop()
    active = await repo.get_flag("emergency_stop_active")
    return EmergencyStopResponse(emergency_stop_active=active, closed_symbols=[])
