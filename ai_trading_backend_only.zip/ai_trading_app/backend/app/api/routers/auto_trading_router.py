"""Auto-trading control for Phase 3 paper trading. `settings` here mirror
`paper_trading.pipeline.RiskLimits` / `paper_trading.config.PaperTradingConfig`
at the level currently exposed — full per-user persisted settings (the
`SettingsRepository` shape on the Flutter side) are Phase 4 scope once
there's an authenticated user to attach them to; Phase 3 has one
default paper account, so these endpoints report/control the single
running worker's state directly.
"""

from fastapi import APIRouter, Depends

from ...core.dependencies import get_background_worker, get_paper_repository
from ...paper_trading.config import DEFAULT_PAPER_CONFIG
from ...paper_trading.pipeline import DEFAULT_RISK_LIMITS
from ...paper_trading.repository import PaperTradingRepository
from ...paper_trading.worker import BackgroundWorker

router = APIRouter(prefix="/v1/auto-trading", tags=["auto-trading"])


@router.get("/settings")
async def get_settings_endpoint():
    return {
        "trade_amount_usd": DEFAULT_PAPER_CONFIG.trade_amount_usd,
        "min_confidence": DEFAULT_RISK_LIMITS.min_confidence,
        "max_daily_loss_percent": DEFAULT_RISK_LIMITS.max_daily_loss_percent,
        "max_risk_per_trade_percent": DEFAULT_RISK_LIMITS.max_risk_per_trade_percent,
        "max_open_trades": DEFAULT_RISK_LIMITS.max_open_trades,
        "max_trades_per_day": DEFAULT_RISK_LIMITS.max_trades_per_day,
        "cooldown_seconds": DEFAULT_RISK_LIMITS.cooldown_seconds,
        "trading_mode": "paper",
    }


@router.put("/settings")
async def update_settings_endpoint():
    # Phase 4: persist per-user RiskLimits/PaperTradingConfig overrides,
    # validated against core/config.py's hard ceilings before saving.
    # Not implemented in Phase 3 — the worker runs with the process-wide
    # defaults above.
    return {"detail": "Per-user settings persistence is Phase 4 scope; the worker currently uses fixed defaults."}


@router.post("/toggle")
async def toggle_auto_trading(
    enabled: bool,
    worker: BackgroundWorker = Depends(get_background_worker),
):
    if enabled:
        worker.start()
    else:
        await worker.stop()
    return {"auto_trading_enabled": worker.is_running}


@router.get("/status")
async def get_auto_trading_status(
    worker: BackgroundWorker = Depends(get_background_worker),
    repo: PaperTradingRepository = Depends(get_paper_repository),
):
    heartbeat = await repo.get_worker_heartbeat()
    emergency_stop = await repo.get_flag("emergency_stop_active")
    return {
        "auto_trading_enabled": worker.is_running,
        "trading_mode": "paper",
        "emergency_stop_active": emergency_stop,
        "last_run_at": heartbeat.get("last_run_at"),
        "total_cycles": heartbeat.get("total_cycles"),
        "consecutive_failures": heartbeat.get("consecutive_failures"),
    }
