"""Binance connection status endpoint.

Phase 4.2: this router has NO endpoint that accepts a Binance API key
or secret. There used to be a `/link` endpoint that received
credentials in a request body — it has been REMOVED, not just left
unimplemented, because leaving a credential-shaped request schema
reachable (even mid-development, even returning 501) is itself a risk:
it invites exactly the "paste your key here" pattern the product
requirement explicitly forbids, and it's an attack surface (TLS
termination, request logging, reverse-proxy access logs, error
tracker payloads) for a secret that should never leave the user's own
device in the first place.

The only endpoint here is a read-only status echo: the Flutter app
manages its own local Binance key entirely on-device (see
`lib/features/binance_connect/`) and may optionally report a
permission SUMMARY (never the key) here for display/audit purposes.
This backend cannot verify that summary independently, since it never
authenticates against Binance as the user's account — it only ever
calls Binance's public market-data endpoints (see
`services/market_data/`).
"""

from fastapi import APIRouter

from ...schemas.binance_schemas import BinanceConnectionStatusSchema

router = APIRouter(prefix="/v1/binance", tags=["binance"])


@router.get("/status", response_model=BinanceConnectionStatusSchema)
async def get_connection_status_placeholder() -> BinanceConnectionStatusSchema:
    """Always reports 'not_configured_on_device' from the backend's
    point of view — it has no channel to learn otherwise, by design.
    A future phase may let the Flutter client POST a locally-computed
    permission summary here for display purposes only; that is not
    implemented yet and, even when it is, will never carry a key or
    secret."""
    return BinanceConnectionStatusSchema(status="not_configured_on_device")
