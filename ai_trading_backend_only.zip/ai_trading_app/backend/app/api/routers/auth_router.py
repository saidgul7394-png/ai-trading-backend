from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ...core.security import create_access_token

router = APIRouter(prefix="/v1/auth", tags=["auth"])


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest):
    # Phase 2: look up user, verify_password, handle lockout/MFA.
    raise HTTPException(status_code=501, detail="Not implemented in Phase 1 scaffold")


@router.post("/refresh", response_model=TokenResponse)
async def refresh():
    raise HTTPException(status_code=501, detail="Not implemented in Phase 1 scaffold")
