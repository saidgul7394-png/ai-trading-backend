from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter(tags=["websocket"])


@router.websocket("/ws/signals")
async def signals_stream(websocket: WebSocket):
    """Pushes new CompositeSignal events to the client as the background
    signal-engine worker publishes them (via Redis pub/sub in Phase 2).
    Requires a valid session token as a query param or header — enforced
    the same way the REST auth dependency works (Phase 2).
    """
    await websocket.accept()
    try:
        # Phase 2: subscribe to Redis channel "signals:<user_id>",
        # forward each message as JSON.
        await websocket.send_json({"type": "info", "message": "Signal stream scaffold — Phase 2"})
        await websocket.close()
    except WebSocketDisconnect:
        pass
