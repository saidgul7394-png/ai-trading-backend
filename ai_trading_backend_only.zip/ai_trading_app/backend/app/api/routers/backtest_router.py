"""Backtesting API endpoints — Phase 4 item 9's backend counterpart:
gives the Flutter Backtesting/Performance screen real results instead
of hard-coded/demo values.

Same environment caveat as every other router in this codebase:
`fastapi` is not installed in this sandbox (no network egress to
pip-install it), so this file is syntax-checked and reviewed but not
execution-tested against a live server — identical to the existing
routers' documented caveat from Phase 2/3.

Every endpoint here calls `backtesting.orchestrator.run_backtest`
WITHOUT `allow_synthetic_fallback` — a request from the real Flutter
app can never silently receive synthetic data; if Binance historical
data can't be fetched, the response's `data_provenance` field reports
`"real_data_blocked"` and the report fields are null, which the
Flutter screen renders as an explicit blocked state (see
`backtest_screen.dart`).
"""

from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, HTTPException

from ...backtesting.orchestrator import run_backtest
from ...paper_trading.config import PaperTradingConfig
from ...paper_trading.pipeline import RiskLimits
from ...schemas.backtest_schemas import BacktestRunRequest, BacktestRunResponse

router = APIRouter(prefix="/v1/backtest", tags=["backtest"])


@router.post("/run", response_model=BacktestRunResponse)
async def run_backtest_endpoint(payload: BacktestRunRequest):
    if not payload.symbols:
        raise HTTPException(status_code=400, detail="symbols must not be empty")
    if payload.end <= payload.start:
        raise HTTPException(status_code=400, detail="end must be after start")

    risk_limits = RiskLimits(
        min_confidence=payload.min_confidence,
        max_daily_loss_percent=payload.max_daily_loss_percent,
        max_risk_per_trade_percent=payload.max_risk_per_trade_percent,
        max_open_trades=payload.max_open_trades,
    )
    paper_config = PaperTradingConfig(
        starting_balance_usd=payload.starting_balance_usd, trade_amount_usd=payload.trade_amount_usd,
    )

    outcome = await run_backtest(
        symbols=tuple(s.upper() for s in payload.symbols),
        primary_timeframe=payload.primary_timeframe,
        start=payload.start,
        end=payload.end,
        risk_limits=risk_limits,
        paper_config=paper_config,
        run_walk_forward=payload.run_walk_forward,
        train_candles=payload.train_candles,
        validation_candles=payload.validation_candles,
        test_candles=payload.test_candles,
        oos_fraction=payload.oos_fraction,
        # Deliberately no allow_synthetic_fallback here — see module docstring.
    )

    def _report_dict(report):
        if report is None:
            return None
        return asdict(report)

    return BacktestRunResponse(
        data_provenance=outcome.data_provenance,
        real_data_used=outcome.real_data_used,
        blocked_reasons=outcome.blocked_reasons,
        overall_report=_report_dict(outcome.overall_report),
        final_oos_report=_report_dict(outcome.final_oos_report),
        walk_forward_window_count=len(outcome.walk_forward_report.windows) if outcome.walk_forward_report else 0,
    )
