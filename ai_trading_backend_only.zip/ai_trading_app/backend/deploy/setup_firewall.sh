#!/usr/bin/env bash
# Firewall setup for the Oracle Cloud VM (Ubuntu). Run this ONCE,
# manually, on the actual server - it is not run by anything in this
# repository automatically.
#
# IMPORTANT ORACLE-SPECIFIC GOTCHA: Oracle Cloud has TWO firewall
# layers, and both must allow a port before traffic reaches it:
#   1. This script configures the OS-level firewall (ufw/iptables) —
#      only that.
#   2. Oracle's own cloud-level "Security List" / "Network Security
#      Group" (configured in the OCI web console, under your VCN's
#      subnet) must ALSO allow the same ports. This script cannot
#      configure that for you - see DEPLOYMENT.md's "Oracle Security
#      List" section for the exact console steps. Forgetting step 2
#      is the most common reason "the firewall is open but I still
#      can't connect" on Oracle Cloud specifically.
#
# What this opens:
#   22   (SSH)   - restricted further below where practical
#   80   (HTTP)  - only used for Let's Encrypt's ACME challenge
#   443  (HTTPS) - the actual API traffic, via Caddy
# Port 8000 (the backend itself) is deliberately NEVER opened here -
# Caddy reverse-proxies to it over localhost only (see Caddyfile and
# ai-trading-backend.service's --host 127.0.0.1), so it is never
# directly reachable from the internet even if this firewall step is
# skipped entirely. This script is defense in depth, not the only
# thing standing between port 8000 and the internet.

set -euo pipefail

echo "=== Installing ufw (if not already present) ==="
sudo apt-get update -y
sudo apt-get install -y ufw

echo "=== Setting default policies: deny incoming, allow outgoing ==="
sudo ufw default deny incoming
sudo ufw default allow outgoing

echo "=== Allowing SSH (22), HTTP (80), HTTPS (443) ==="
sudo ufw allow 22/tcp comment 'SSH'
sudo ufw allow 80/tcp comment 'HTTP (ACME challenge only, Caddy redirects to HTTPS)'
sudo ufw allow 443/tcp comment 'HTTPS (actual API traffic)'

# Optional, stronger SSH restriction: uncomment and replace with your
# own IP if it is static. Do NOT do this if your home/mobile IP
# changes (the prompt for this phase explicitly said not to assume a
# static IP) - a wrong static rule here can lock you out entirely.
#
# YOUR_STATIC_IP="203.0.113.42"
# sudo ufw delete allow 22/tcp
# sudo ufw allow from "$YOUR_STATIC_IP" to any port 22 proto tcp comment 'SSH from known IP only'
#
# A safer alternative if your IP is not static: keep SSH open to all
# (as this script does by default) but harden SSH itself instead -
# disable password auth (key-only), disable root login. See
# DEPLOYMENT.md's "SSH hardening (works with dynamic IPs)" section.

echo "=== Enabling ufw ==="
sudo ufw --force enable

echo "=== Current rules ==="
sudo ufw status verbose

echo
echo "Done. REMINDER: you still need to open 80 and 443 in Oracle's"
echo "cloud-level Security List / Network Security Group in the OCI"
echo "console - this script only configured the OS firewall. See"
echo "DEPLOYMENT.md's 'Oracle Security List' section."
