#!/usr/bin/env bash
# Deploys this backend onto a fresh Oracle Cloud Ubuntu VM. Run this ON
# THE SERVER (after cloning/copying this repo there), not on your
# development machine. This script has NOT been executed against a
# real Oracle server by anything that produced this repository - it is
# provided as exact, documented commands for YOU to run and verify;
# see DEPLOYMENT.md for the full walkthrough including manual steps
# this script cannot automate (Oracle console firewall rules, DNS).
#
# Prerequisites this script assumes:
#   - Ubuntu 22.04+ on the VM (Oracle's default free-tier image)
#   - You have already run setup_firewall.sh (or equivalent)
#   - This repository's `backend/` directory is present at
#     /opt/ai-trading-backend/backend (adjust DEPLOY_ROOT below if not)

set -euo pipefail

DEPLOY_ROOT="/opt/ai-trading-backend"
BACKEND_DIR="$DEPLOY_ROOT/backend"
SERVICE_USER="aitrading"

if [ "$(id -u)" -eq 0 ]; then
    echo "Run this as your normal sudo-capable user, not directly as root." >&2
    exit 1
fi

echo "=== Installing system packages (Python, venv, build tools) ==="
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip build-essential caddy

echo "=== Creating dedicated unprivileged service user ==="
if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
    sudo useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
    echo "Created system user '$SERVICE_USER'."
else
    echo "User '$SERVICE_USER' already exists, skipping."
fi

echo "=== Creating data directory for the SQLite database ==="
sudo mkdir -p "$BACKEND_DIR/data"
sudo chown -R "$SERVICE_USER:$SERVICE_USER" "$DEPLOY_ROOT"

echo "=== Creating Python virtual environment ==="
sudo -u "$SERVICE_USER" python3 -m venv "$BACKEND_DIR/.venv"

echo "=== Installing Python dependencies ==="
sudo -u "$SERVICE_USER" "$BACKEND_DIR/.venv/bin/pip" install --upgrade pip
sudo -u "$SERVICE_USER" "$BACKEND_DIR/.venv/bin/pip" install -r "$BACKEND_DIR/requirements.txt"

echo "=== Checking for .env ==="
if [ ! -f "$BACKEND_DIR/.env" ]; then
    echo
    echo "No .env found at $BACKEND_DIR/.env."
    echo "Copy .env.example to .env and fill in real values BEFORE continuing:"
    echo "    sudo -u $SERVICE_USER cp $BACKEND_DIR/.env.example $BACKEND_DIR/.env"
    echo "    sudo -u $SERVICE_USER nano $BACKEND_DIR/.env"
    echo
    echo "At minimum, set ENVIRONMENT=production and a real JWT_SECRET/"
    echo "SECRETS_ENCRYPTION_KEY (long random values, not the placeholders)."
    echo "Re-run this script after creating .env."
    exit 1
fi

echo "=== Verifying critical .env values are not left as placeholders ==="
if grep -q "changeme" "$BACKEND_DIR/.env"; then
    echo "ERROR: $BACKEND_DIR/.env still contains a 'changeme' placeholder value." >&2
    echo "Replace JWT_SECRET and SECRETS_ENCRYPTION_KEY with real random values before deploying." >&2
    exit 1
fi
if ! grep -qE "^ENVIRONMENT=production$" "$BACKEND_DIR/.env"; then
    echo "WARNING: ENVIRONMENT is not set to 'production' in .env." >&2
    echo "Development-mode CORS/logging defaults will apply. This is probably not what you want on a public server." >&2
fi

echo "=== Installing systemd service ==="
sudo cp "$BACKEND_DIR/deploy/ai-trading-backend.service" /etc/systemd/system/ai-trading-backend.service
sudo systemctl daemon-reload
sudo systemctl enable ai-trading-backend

echo "=== Installing Caddy config ==="
if grep -q "YOUR_DOMAIN_HERE" "$BACKEND_DIR/deploy/Caddyfile"; then
    echo
    echo "WARNING: $BACKEND_DIR/deploy/Caddyfile still has the placeholder"
    echo "'YOUR_DOMAIN_HERE'. Edit it to your real domain before copying it,"
    echo "otherwise Caddy cannot obtain a TLS certificate. Skipping Caddy"
    echo "config install for now - see DEPLOYMENT.md."
else
    sudo cp "$BACKEND_DIR/deploy/Caddyfile" /etc/caddy/Caddyfile
    sudo systemctl restart caddy
    echo "Caddy config installed and restarted."
fi

echo "=== Starting the backend service ==="
sudo systemctl restart ai-trading-backend
sleep 3
sudo systemctl status ai-trading-backend --no-pager || true

echo
echo "=== Deployment script complete ==="
echo "Check logs with:      journalctl -u ai-trading-backend -f"
echo "Check health with:    curl -s http://127.0.0.1:8000/health"
echo "Check readiness with: curl -s http://127.0.0.1:8000/health/ready"
echo
echo "REMEMBER: this script does not verify Oracle's cloud-level"
echo "Security List / Network Security Group rules, or DNS - see"
echo "DEPLOYMENT.md for those manual steps."
