# Phase 5 — Deployment Guide

Deploys the existing backend to an always-on server so the signal
engine, risk engine, and paper-trading loop keep running when your
phone/laptop is off.

**Honesty notice, up front:** the environment that produced this
guide has no network egress and cannot reach Oracle Cloud, run
`systemctl`, open a real port, or obtain a real TLS certificate. Every
command below is real and has been reviewed for correctness against
this codebase, but **none of it has been executed against a real
Oracle server**. You run these commands yourself, on your own VM, and
verify each step. See the bottom of this document for exactly what
Phase 5 verified in this environment versus what only you can verify.

This phase changes **nothing** about Signal Fusion, the Risk Engine,
Backtesting/WFO/OOS, the trading strategy, or the Binance credential
architecture. It is deployment-only.

---

## 1. What you're deploying, and what you're not

- **Deploying:** the FastAPI backend (`backend/app`) — signal engine,
  risk engine, paper-trading simulation loop, backtesting API, public
  Binance market-data fetching.
- **Not deploying, not changing:** live order execution stays
  disabled (`LIVE_TRADING_ENABLED=false`, hard-coded default, no
  remote way to flip it — see `app/services/trading_orchestrator.py`).
  Binance credentials never touch this server, before or after this
  phase — see section 6.

---

## 2. Oracle Cloud Free Tier — account & VM setup

These are manual, one-time steps in Oracle's web console. Written from
current knowledge of OCI's console; menu labels occasionally shift —
if something doesn't match exactly, search OCI's own docs for the
current wording, the underlying steps (create VCN → create instance →
open ports) don't change often.

1. Sign up at oracle.com/cloud/free (requires a card for identity
   verification; the Always Free resources themselves do not charge
   it — see section 10 for the honest limits of that claim).
2. Create a VM instance:
   - Shape: an **Always Free** shape — either the Ampere A1 (ARM,
     generous free allotment) or the older VM.Standard.E2.1.Micro
     (x86, 1GB RAM — tight but workable for this backend).
   - Image: **Ubuntu 22.04** (or newer LTS).
   - Generate/upload an SSH key pair during creation — you'll need the
     private key to log in.
3. Note the VM's public IP address once it's running.
4. **Oracle Security List** (the cloud-level firewall — separate from
   the OS firewall you'll configure in section 4):
   - Console → Networking → Virtual Cloud Networks → (your VCN) →
     Security Lists → (default security list)
   - Add ingress rules: TCP port 80 (source 0.0.0.0/0), TCP port 443
     (source 0.0.0.0/0). Port 22 (SSH) is usually open by default on
     the Oracle-created security list — confirm it's there.
   - **This step is easy to miss and is the most common reason
     "everything looks right but I still can't connect."** The OS
     firewall (ufw) and this cloud-level list both have to allow a
     port — either one blocking it is enough to block all traffic.
5. SSH in to confirm access before doing anything else:
   ```
   ssh -i /path/to/your/private_key ubuntu@<VM_PUBLIC_IP>
   ```

---

## 3. DNS

Caddy (section 5) needs a real domain name to get a free TLS
certificate — it cannot get one for a bare IP address.

- If you own a domain: add an A record pointing a subdomain (e.g.
  `trading.yourdomain.com`) at the VM's public IP.
- If you don't: a free dynamic-DNS provider like
  [DuckDNS](https://www.duckdns.org) or [No-IP](https://www.noip.com)
  gives you a free subdomain (e.g. `yourname.duckdns.org`) pointed at
  your IP — this works fine with Caddy and costs nothing.

Whichever you use, wait for DNS to actually propagate (`dig
your-domain` or `nslookup your-domain` should show the VM's IP) before
running Caddy — it will fail to get a certificate otherwise.

---

## 4. Firewall

Copy `backend/deploy/setup_firewall.sh` to the VM and run it:

```
scp -i /path/to/key backend/deploy/setup_firewall.sh ubuntu@<VM_IP>:~
ssh -i /path/to/key ubuntu@<VM_IP>
chmod +x setup_firewall.sh
./setup_firewall.sh
```

Read the script before running it — it documents exactly what it
opens and why, and the Oracle-Security-List gotcha from section 2
again inline.

---

## 5. Deploying the backend

1. Get this repository onto the VM. Simplest for a personal project —
   `scp` a zip of the `backend/` directory, or `git clone` if you push
   this repo somewhere:
   ```
   ssh -i /path/to/key ubuntu@<VM_IP> 'sudo mkdir -p /opt/ai-trading-backend && sudo chown ubuntu:ubuntu /opt/ai-trading-backend'
   scp -i /path/to/key -r backend ubuntu@<VM_IP>:/opt/ai-trading-backend/
   ```
2. Create your real `.env` on the server (never copy your local one
   if it has different values — generate fresh secrets for
   production):
   ```
   ssh -i /path/to/key ubuntu@<VM_IP>
   cd /opt/ai-trading-backend/backend
   cp .env.example .env
   nano .env
   ```
   At minimum: set `ENVIRONMENT=production`, generate real random
   values for `JWT_SECRET` and `SECRETS_ENCRYPTION_KEY` (e.g. `python3
   -c "import secrets; print(secrets.token_urlsafe(32))"`, run twice),
   and set `PAPER_TRADING_DB_PATH=/opt/ai-trading-backend/backend/data/paper_trading.sqlite3`.
3. Edit `deploy/Caddyfile`, replacing `YOUR_DOMAIN_HERE` with your
   real domain from section 3.
4. Run the deployment script:
   ```
   chmod +x deploy/deploy.sh
   ./deploy/deploy.sh
   ```
   It installs Python/Caddy, creates an unprivileged `aitrading`
   system user, sets up a venv, installs dependencies, installs and
   enables the systemd service, installs the Caddy config, and starts
   everything. It refuses to continue (with a clear error) if `.env`
   is missing or still has placeholder secrets.
5. Verify:
   ```
   curl -s https://your-domain/health | python3 -m json.tool
   curl -s https://your-domain/health/ready | python3 -m json.tool
   ```
   `/health` should show `"status": "ok"`. `/health/ready` should show
   `"status": "ready"` once the market-data stream has finished its
   initial backfill (may take a few seconds to a couple of minutes on
   first start — see `app/main.py`'s `lifespan` bootstrap).

---

## 6. Binance credentials — reconfirmed, unchanged, and a real limitation

Reconfirming the Phase 4.2 architecture, unchanged by this phase:

- The Binance API key and secret are entered and stored **only** on
  your device, via `flutter_secure_storage` (Android Keystore-backed).
- They are **never** sent to this backend, in this phase or any prior
  one. There is no request schema, no endpoint, no `.env` variable, no
  code path anywhere in `backend/app` capable of receiving one — this
  was true before Phase 5 and remains true after it (verified by the
  automated tests in `test_credential_safety.py`, which this phase
  does not touch).
- They are never written to logs, Git, the APK, or any AI/LLM request.

**The real architectural consequence of this, stated plainly:**
because the remote server never holds your Binance credentials, it
cannot independently sign and place a real Binance order while your
phone is completely offline — signing an authenticated Binance
request requires the secret, and the secret only ever exists on your
device. Right now this is moot: live order placement is not
implemented anywhere in this codebase yet (see section 7). But it
matters for **future** planning: a genuinely phone-independent
live-trading system would need a deliberate, separately-designed
mechanism for the device to authorize the server to trade on its
behalf (e.g. the device periodically issuing short-lived, scoped
credentials to the server, or the server holding its own
independently-created, separately-revocable API key rather than
reusing the device's). That redesign is explicitly **out of scope**
for Phase 5 and is not attempted here — this section exists so the
tradeoff is documented, not silently discovered later.

---

## 7. Live trading — still disabled

`LIVE_TRADING_ENABLED=false` in `.env.example` and as the hard-coded
default in `app/core/config.py`. `app/services/trading_orchestrator.py`
refuses to execute anything while this is false, and nothing in this
phase adds a way to set it to true remotely — only the server
operator's own `.env`, edited locally on the machine, can change it,
and even then `place_order` in `app/services/binance_service.py` is
still an unimplemented placeholder (see that file's docstring). No UI
change in this phase enables real orders.

---

## 8. Process management — restart-safety details

- **Auto-start on boot:** `systemctl enable ai-trading-backend` (done
  by `deploy.sh`) registers the service to start automatically when
  the VM reboots.
- **Auto-restart on crash:** `Restart=always` with `RestartSec=5` in
  the systemd unit. `StartLimitBurst=10` over `StartLimitIntervalSec=300`
  stops it from restart-looping forever if something is persistently
  broken (after 10 restarts in 5 minutes, systemd stops trying and you
  see it in `systemctl status`).
- **No duplicate workers after restart:** the background paper-trading
  worker (`app/paper_trading/worker.py`'s `BackgroundWorker`) is a
  single `asyncio.Task` created once per process in `app/main.py`'s
  `lifespan`. The systemd unit deliberately does **not** set Uvicorn's
  `--workers` flag (defaults to 1 process) — running more than one
  worker process would create multiple independent `BackgroundWorker`
  instances all writing to the same SQLite file and independently
  evaluating the same symbols, risking duplicate signal evaluation and
  double-opened positions. Do not add `--workers N` for N > 1 without
  first redesigning the worker/SQLite layer for multi-process safety —
  that redesign is not part of Phase 5.
- **Graceful shutdown:** systemd sends SIGTERM on stop/restart; Uvicorn
  forwards this into FastAPI's lifespan shutdown, which stops the
  background worker, closes the live market-data WebSocket stream, and
  closes the REST client cleanly (see `app/main.py`'s `lifespan`
  function) before the process exits. `TimeoutStopSec=30` gives this
  time to happen before systemd escalates to SIGKILL.
- **Logs:** `journalctl -u ai-trading-backend -f` (live tail) or
  `journalctl -u ai-trading-backend --since "1 hour ago"`.

---

## 9. Database (SQLite) — what's real here

The actually-exercised persistence layer is SQLite
(`app/paper_trading/db.py`), not the Postgres/SQLAlchemy scaffolding
in `app/db/` (that scaffolding is reviewed but never wired up to
anything that runs — see that module's own docstring). This phase
does not change that; setting up a real Postgres instance is **not**
required for this deployment.

- **Location:** wherever `PAPER_TRADING_DB_PATH` in `.env` points —
  the provided `.env.example` sets this to
  `/opt/ai-trading-backend/backend/data/paper_trading.sqlite3`, inside
  the directory the systemd unit's `ReadWritePaths` explicitly allows
  writes to (everything else the service can read is read-only, per
  `ProtectSystem=strict`).
- **Permissions:** owned by the unprivileged `aitrading` system user
  created by `deploy.sh`; not world-readable.
- **Persistence across restarts:** confirmed by Phase 3's own
  restart-recovery tests (`app/tests/test_worker.py` and related) —
  `main.py`'s startup logs "Recovered N open paper position(s) from
  prior run" when applicable, so this is directly observable in
  `journalctl` after a restart, not just asserted.
- **Backup strategy:** SQLite is a single file; back it up with a
  simple copy while the service is briefly stopped (SQLite can be
  read while running, but a stopped-service copy avoids any chance of
  copying mid-write):
  ```
  sudo systemctl stop ai-trading-backend
  sudo cp /opt/ai-trading-backend/backend/data/paper_trading.sqlite3 \
          /opt/ai-trading-backend/backend/data/paper_trading.sqlite3.bak-$(date +%F)
  sudo systemctl start ai-trading-backend
  ```
  Consider a cron job calling a small wrapper script if you want this
  automatic — not included here since backup retention/off-box storage
  is a personal preference this guide won't decide for you.
- **Safe shutdown:** covered above (SIGTERM → lifespan shutdown); the
  worker's own recovery model (see `worker.py`'s module docstring) is
  designed so a hard kill mid-cycle still leaves consistent state,
  since every position/account mutation is already committed to
  SQLite before the in-memory loop moves on, not batched.

---

## 10. Cost — what's actually free, and what could cost money

- **Oracle Cloud Free Tier VM:** free under Oracle's current Always
  Free program terms. This guide cannot guarantee Oracle keeps this
  program unchanged indefinitely, or that your account won't be
  affected by an Oracle-side policy change, inactivity reclamation, or
  region capacity limits — those are Oracle's decisions, not something
  this codebase controls. Check your Oracle billing dashboard
  periodically regardless.
- **Caddy, ufw, systemd:** free, open-source.
- **Let's Encrypt certificates (via Caddy):** free, auto-renewing.
- **DuckDNS/No-IP (if used for DNS):** free tier is sufficient for one
  subdomain.
- **Binance API:** free to read public market data (what this backend
  uses).
- **News/sentiment/AI provider API keys** (`NEWS_API_KEY`,
  `SENTIMENT_MODEL_API_KEY`, `AI_PROVIDER_API_KEY` in `.env.example`):
  whether these cost money depends entirely on which provider you
  choose and its own pricing — this phase does not select or require
  any specific one.
- **Nothing in this phase requires a paid service.** If you later
  choose a paid domain, a paid monitoring service, or a larger Oracle
  shape, that's a choice you make outside what this guide requires.

---

## 11. Known limitations of this phase

- Oracle deployment was **not** actually performed or tested against a
  real server by anything that produced this guide — see the honesty
  notice at the top. You are the one who runs and verifies this.
- The offline-phone / credential-locality tradeoff in section 6 is
  **documented, not solved** — by design, per the Phase 5 prompt.
- Multi-process horizontal scaling of the backend is not supported
  (see section 8) — this is a single-process, single-VM deployment,
  appropriate for personal use at the scale this project targets.
- No automated backup scheduling is included (manual steps only, see
  section 9).
