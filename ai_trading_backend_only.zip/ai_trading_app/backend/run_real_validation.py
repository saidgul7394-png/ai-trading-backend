#!/usr/bin/env python3
"""Phase 4.1 — Real environment validation runner.

RUN THIS ON A MACHINE WITH REAL INTERNET ACCESS. It will not produce
real results in a sandboxed/offline environment — see the honest
"BLOCKED" output it prints in that case.

What this script does, end to end, using the UNMODIFIED Phase 4 engine
(nothing here re-implements signal/risk/execution logic — it only
calls into `app.backtesting.orchestrator.run_backtest`, which itself
calls the unmodified Phase 1-3 Signal Fusion + Risk Engine + Position
Management code):

  1. Verifies/installs the Python dependencies listed in requirements.txt.
  2. Downloads REAL Binance historical klines for the requested symbols
     and timeframes (default: the app's own DEFAULT_SYMBOLS, 1h primary
     + 15m/4h confirmation, trailing 180 days) via
     `app.backtesting.historical_data`, with on-disk CSV caching so
     re-runs don't re-download.
  3. Runs the full backtest replay, chronological walk-forward
     validation, and the untouched final OOS test via
     `app.backtesting.orchestrator.run_backtest` — NEVER with
     `allow_synthetic_fallback=True`, so if real data can't be fetched
     the run honestly reports BLOCKED rather than substituting
     anything synthetic.
  4. Writes reproducible reports to `validation_results/<run_id>/`:
     - `run_manifest.json` — exact parameters, data provenance, timestamp
     - `overall_report.json` — full performance/signal-quality report
     - `final_oos_report.json` — the untouched OOS result (clearly separate)
     - `trade_journal.csv` — every simulated trade, chronologically
     - `walk_forward_windows.csv` — per-window train/validation/test metrics

Parameters intentionally use the codebase's own shipped defaults
(RiskLimits(), PaperTradingConfig(), SignalEngineConfig() — see
`--help` for how to override) and are NEVER auto-tuned by this script
to improve results, per Phase 4.1 requirement 7. If you pass
`--min-confidence` etc. explicitly, that is YOUR parameter choice, not
this script fitting to the data.

Usage:
    cd backend
    python3 run_real_validation.py --symbols BTCUSDT ETHUSDT --days 180

Exit codes: 0 = ran to completion (see run_manifest.json for whether
real data was actually used); 1 = real data blocked; 2 = other error.
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import json
import subprocess
import sys
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

REQUIRED_PACKAGES = [
    "fastapi==0.115.0",
    "uvicorn[standard]==0.30.6",
    "pydantic==2.9.2",
    "pydantic-settings==2.5.2",
    "sqlalchemy==2.0.35",
    "httpx==0.27.2",
    "websockets==13.1",
    "python-dotenv==1.0.1",
    "numpy==2.1.1",
    "pandas==2.2.3",
    "ta==0.11.0",
]


def verify_or_install_dependencies(skip_install: bool) -> list[str]:
    """Checks each required package is importable; if not and
    `skip_install` is False, attempts `pip install`. Returns the list
    of packages that are still missing after this step (empty = all
    good). Never silently continues past a missing critical dependency
    — the caller decides whether to abort."""
    import importlib

    module_names = {
        "fastapi==0.115.0": "fastapi",
        "uvicorn[standard]==0.30.6": "uvicorn",
        "pydantic==2.9.2": "pydantic",
        "pydantic-settings==2.5.2": "pydantic_settings",
        "sqlalchemy==2.0.35": "sqlalchemy",
        "httpx==0.27.2": "httpx",
        "websockets==13.1": "websockets",
        "python-dotenv==1.0.1": "dotenv",
        "numpy==2.1.1": "numpy",
        "pandas==2.2.3": "pandas",
        "ta==0.11.0": "ta",
    }

    missing = []
    for pkg, module in module_names.items():
        try:
            importlib.import_module(module)
        except ImportError:
            missing.append(pkg)

    if missing and not skip_install:
        print(f"Installing missing packages: {missing}")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--break-system-packages", *missing],
            capture_output=True, text=True,
        )
        print(result.stdout[-2000:])
        if result.returncode != 0:
            print(result.stderr[-2000:], file=sys.stderr)
        # Re-check after install attempt.
        still_missing = []
        for pkg, module in module_names.items():
            try:
                importlib.import_module(module)
            except ImportError:
                still_missing.append(pkg)
        return still_missing

    return missing


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbols", nargs="+", default=["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"])
    parser.add_argument("--primary-timeframe", default="1h")
    parser.add_argument("--days", type=int, default=180, help="Trailing window of real history to fetch, in days.")
    parser.add_argument("--train-candles", type=int, default=400)
    parser.add_argument("--validation-candles", type=int, default=150)
    parser.add_argument("--test-candles", type=int, default=150)
    parser.add_argument("--oos-fraction", type=float, default=0.2)
    parser.add_argument("--min-confidence", type=float, default=0.65, help="Codebase default — not tuned by this script.")
    parser.add_argument("--max-daily-loss-percent", type=float, default=3.0)
    parser.add_argument("--max-risk-per-trade-percent", type=float, default=1.0)
    parser.add_argument("--max-open-trades", type=int, default=3)
    parser.add_argument("--starting-balance-usd", type=float, default=10_000.0)
    parser.add_argument("--trade-amount-usd", type=float, default=500.0)
    parser.add_argument("--no-walk-forward", action="store_true", help="Skip walk-forward/OOS, run only the overall backtest.")
    parser.add_argument("--skip-dependency-install", action="store_true")
    parser.add_argument("--output-dir", default="validation_results")
    parser.add_argument("--cache-dir", default="backtest_data_cache")
    return parser.parse_args()


async def _main_async(args: argparse.Namespace) -> int:
    # Deferred imports: only safe once dependencies are confirmed present.
    from app.backtesting.historical_data import HistoricalDataCache
    from app.backtesting.orchestrator import (
        DATA_PROVENANCE_BLOCKED,
        DATA_PROVENANCE_REAL,
        run_backtest,
    )
    from app.paper_trading.config import PaperTradingConfig
    from app.paper_trading.pipeline import RiskLimits

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path(args.output_dir) / run_id
    out_dir.mkdir(parents=True, exist_ok=True)

    end = datetime.now(timezone.utc)
    start = end - timedelta(days=args.days)

    risk_limits = RiskLimits(
        min_confidence=args.min_confidence,
        max_daily_loss_percent=args.max_daily_loss_percent,
        max_risk_per_trade_percent=args.max_risk_per_trade_percent,
        max_open_trades=args.max_open_trades,
    )
    paper_config = PaperTradingConfig(
        starting_balance_usd=args.starting_balance_usd, trade_amount_usd=args.trade_amount_usd,
    )

    manifest = {
        "run_id": run_id,
        "started_at": end.isoformat(),
        "symbols": args.symbols,
        "primary_timeframe": args.primary_timeframe,
        "date_range": {"start": start.isoformat(), "end": end.isoformat()},
        "run_walk_forward": not args.no_walk_forward,
        "walk_forward_windows": {
            "train_candles": args.train_candles,
            "validation_candles": args.validation_candles,
            "test_candles": args.test_candles,
            "oos_fraction": args.oos_fraction,
        },
        "risk_limits": {
            "min_confidence": args.min_confidence,
            "max_daily_loss_percent": args.max_daily_loss_percent,
            "max_risk_per_trade_percent": args.max_risk_per_trade_percent,
            "max_open_trades": args.max_open_trades,
        },
        "paper_config": {
            "starting_balance_usd": args.starting_balance_usd,
            "trade_amount_usd": args.trade_amount_usd,
        },
        "note": (
            "Parameters above are the codebase's own shipped defaults unless "
            "explicitly overridden via CLI flags. This script never tunes "
            "parameters to improve results (Phase 4.1 requirement 7)."
        ),
    }

    print(f"Run ID: {run_id}")
    print(f"Fetching real Binance data for {args.symbols} ({args.primary_timeframe}, "
          f"{start.date()} -> {end.date()})...")

    outcome = await run_backtest(
        symbols=tuple(args.symbols),
        primary_timeframe=args.primary_timeframe,
        start=start,
        end=end,
        risk_limits=risk_limits,
        paper_config=paper_config,
        run_walk_forward=not args.no_walk_forward,
        train_candles=args.train_candles,
        validation_candles=args.validation_candles,
        test_candles=args.test_candles,
        oos_fraction=args.oos_fraction,
        cache=HistoricalDataCache(args.cache_dir),
        # Deliberately no allow_synthetic_fallback: a real-data request
        # from this script must never silently receive synthetic data.
    )

    manifest["data_provenance"] = outcome.data_provenance
    manifest["real_data_used"] = outcome.real_data_used
    manifest["blocked_reasons"] = outcome.blocked_reasons

    def _default(o):
        if hasattr(o, "isoformat"):
            return o.isoformat()
        if hasattr(o, "value"):  # enums
            return o.value
        raise TypeError(f"Not JSON serializable: {type(o)}")

    (out_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2, default=_default))

    if outcome.data_provenance == DATA_PROVENANCE_BLOCKED:
        print("\n" + "=" * 70)
        print("REAL HISTORICAL VALIDATION BLOCKED")
        print("=" * 70)
        for reason in outcome.blocked_reasons:
            print(f"  - {reason}")
        print(f"\nManifest written to: {out_dir / 'run_manifest.json'}")
        print("No backtest, walk-forward, or OOS results were produced — see")
        print("Phase 4's honest-blocking guarantee (no synthetic substitution).")
        return 1

    assert outcome.data_provenance == DATA_PROVENANCE_REAL
    assert outcome.overall_report is not None

    overall_path = out_dir / "overall_report.json"
    overall_path.write_text(json.dumps(asdict(outcome.overall_report), indent=2, default=_default))
    print(f"Overall report written to: {overall_path}")

    if outcome.final_oos_report is not None:
        oos_path = out_dir / "final_oos_report.json"
        oos_path.write_text(json.dumps(asdict(outcome.final_oos_report), indent=2, default=_default))
        print(f"Final OOS report written to: {oos_path}")

    # Trade journal CSV — every simulated trade, chronologically.
    journal_path = out_dir / "trade_journal.csv"
    with journal_path.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "symbol", "side", "opened_at", "closed_at", "entry_price", "exit_price",
            "quantity", "exit_reason", "realized_pnl", "signal_confidence_at_entry",
            "mfe_percent", "mae_percent", "regimes_at_entry",
        ])
        for row in outcome.overall_report.trade_journal:
            writer.writerow([
                row["symbol"], row["side"], row["opened_at"], row["closed_at"],
                row["entry_price"], row["exit_price"], row["quantity"], row["exit_reason"],
                row["realized_pnl"], row["signal_confidence_at_entry"], row["mfe_percent"],
                row["mae_percent"], "|".join(row["regimes_at_entry"]),
            ])
    print(f"Trade journal written to: {journal_path}")

    # Walk-forward per-window metrics CSV, if walk-forward ran.
    if outcome.walk_forward_report is not None:
        from app.backtesting.metrics import compute_performance_metrics

        wf_path = out_dir / "walk_forward_windows.csv"
        with wf_path.open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "window_index", "segment", "start", "end", "total_trades", "win_rate_percent",
                "profit_factor", "net_pnl", "expectancy", "max_drawdown_percent",
            ])
            for wr in outcome.walk_forward_report.windows:
                for segment_name, segment_result, bounds in [
                    ("train", wr.train_result, wr.window.train),
                    ("validation", wr.validation_result, wr.window.validation),
                    ("test", wr.test_result, wr.window.test),
                ]:
                    if segment_result is None:
                        continue
                    m = compute_performance_metrics(segment_result.trades)
                    writer.writerow([
                        wr.window.index, segment_name, bounds[0].isoformat(), bounds[1].isoformat(),
                        m.total_trades, round(m.win_rate_percent, 2),
                        round(m.profit_factor, 3) if m.profit_factor is not None else "",
                        round(m.net_pnl, 2), round(m.expectancy, 4), round(m.max_drawdown_percent, 2),
                    ])
        print(f"Walk-forward window breakdown written to: {wf_path}")

        from app.backtesting.walk_forward import detect_suspicious_overfitting

        warnings = detect_suspicious_overfitting(outcome.walk_forward_report)
        if warnings:
            print("\nOverfitting warnings (heuristic, not proof):")
            for w in warnings:
                print(f"  - {w}")

    # Print a concise human-readable summary to the console too.
    perf = outcome.overall_report.performance
    print("\n" + "=" * 70)
    print("OVERALL BACKTEST PERFORMANCE (real Binance historical data)")
    print("=" * 70)
    print(f"Total trades:       {perf.total_trades}")
    print(f"Win rate:           {perf.win_rate_percent:.2f}%")
    print(f"Profit factor:      {perf.profit_factor if perf.profit_factor is not None else 'N/A'}")
    print(f"Expectancy:         {perf.expectancy:.4f}")
    print(f"Net P&L:            {perf.net_pnl:.2f}")
    print(f"Max drawdown:       {perf.max_drawdown_percent:.2f}%")
    print(f"Average R multiple: {perf.average_r_multiple if perf.average_r_multiple is not None else 'N/A'}")
    print(f"Total fees:         {perf.total_fees:.2f}")
    print(f"Long / Short:       {perf.long_trades} / {perf.short_trades}")
    print("=" * 70)
    print("\nThis is a BACKTEST of simulated trades, not a live-trading result,")
    print("and is not a claim of future profitability. See disclaimers in")
    print(f"{overall_path} for the full required disclosures.")

    return 0


def main() -> int:
    args = parse_args()

    missing = verify_or_install_dependencies(args.skip_dependency_install)
    if missing:
        print("ERROR: the following required packages are still missing after install attempt:")
        for pkg in missing:
            print(f"  - {pkg}")
        print("\nThis usually means there is no internet/PyPI access in this environment.")
        print("Real validation cannot proceed without these dependencies.")
        return 2

    return asyncio.run(_main_async(args))


if __name__ == "__main__":
    sys.exit(main())
