# AI Trading — Secure Backend (Phase 1 scaffold)

This service is the **only** component that ever holds Binance API
secrets, signs Binance requests, runs the AI signal engine, or enforces
risk limits. The Flutter app is a thin client: it authenticates with
this backend and only ever sees derived data (signals, trades, balances,
risk status) — never raw Binance credentials or unrestricted trading
authority.

## Why a backend at all?

- **Secrets never ship in the APK.** An Android APK can be decompiled.
  Binance secret keys, AI provider keys, and news API keys must never be
  embedded client-side.
- **Risk limits must be un-bypassable.** If risk enforcement lived on
  the device, a rooted phone, a modified APK, or a bug in the UI layer
  could place unlimited-risk trades. Enforcement has to live somewhere
  the client cannot patch around.
- **The AI signal engine needs server-grade compute** (multi-timeframe
  technical analysis + news sentiment + continuous position monitoring)
  running 24/7, independent of whether the user's phone is on screen.

## Stack (proposed)

- **Python 3.12 + FastAPI** — async, strong typing, good fit for the
  numerical/ML-adjacent signal engine.
- **PostgreSQL** — trades, signals, users, audit log.
- **Redis** — rate limiting, cooldown/circuit-breaker state, pub/sub for
  the WebSocket signal stream.
- **A task runner** (Celery or an async worker loop) for the position
  monitoring loop and scheduled market-data polling.
- **A secrets manager** (e.g. cloud KMS / Vault) for encrypting stored
  Binance API secrets at rest — never plain-text in the DB.

## Directory layout

```
backend/
  app/
    main.py                 # FastAPI app entrypoint
    core/                   # config, security (JWT), settings
    api/routers/            # HTTP + WebSocket route handlers
    services/                # Binance client, market data, orchestration
    signal_engine/           # technical indicators + composite scoring
    news_engine/              # news ingestion + sentiment classification
    risk_engine/              # hard limits, circuit breaker, emergency stop
    models/                  # ORM models (DB tables)
    schemas/                 # Pydantic request/response schemas
    db/                       # session/engine setup, migrations
  requirements.txt
  .env.example
```

## Non-negotiable rules encoded in this scaffold

1. Binance API keys are **write-restricted to trading only**. On link,
   the backend calls Binance's account/permissions endpoint and
   **rejects** any key that has withdrawal or transfer permission
   enabled (see `services/binance_service.py` stub).
2. Every automatic trade must pass through `risk_engine/` before an
   order is placed. There is no code path from `signal_engine/` straight
   to `services/binance_service.py`.
3. All trading actions are written to an append-only audit log
   (`models/audit_log.py`) — every order, every risk-block, every
   emergency stop is traceable.
4. Emergency Stop is a privileged, idempotent operation that can be
   triggered by the client but whose effects (halting the trading loop,
   optionally flattening positions) execute entirely server-side.

This is a Phase 1 scaffold: signatures, docstrings, and structure are in
place; indicator math, Binance signing, and the AI model integration are
intentionally left as `NotImplementedError` stubs for Phase 2+.
